#include "module4_randomized.h"
#include <stdlib.h>
#include <string.h>

static TreapNode* treap_new_node(int key, int priority, const char* value) {
    TreapNode* node = (TreapNode*)calloc(1, sizeof(TreapNode));
    if (!node) {
        return NULL;
    }
    node->key = key;
    node->priority = priority;
    if (value) {
        strncpy(node->value, value, sizeof(node->value) - 1);
    }
    return node;
}

static TreapNode* rotate_left(TreapNode* root) {
    TreapNode* pivot = root->right;
    root->right = pivot->left;
    pivot->left = root;
    return pivot;
}

static TreapNode* rotate_right(TreapNode* root) {
    TreapNode* pivot = root->left;
    root->left = pivot->right;
    pivot->right = root;
    return pivot;
}

TreapNode* treap_insert(TreapNode* root, int key, int priority, const char* value) {
    if (!root) {
        return treap_new_node(key, priority, value);
    }
    if (key < root->key) {
        root->left = treap_insert(root->left, key, priority, value);
        if (root->left && root->left->priority > root->priority) {
            root = rotate_right(root);
        }
    } else if (key > root->key) {
        root->right = treap_insert(root->right, key, priority, value);
        if (root->right && root->right->priority > root->priority) {
            root = rotate_left(root);
        }
    } else if (value) {
        strncpy(root->value, value, sizeof(root->value) - 1);
    }
    return root;
}

void treap_split(TreapNode* root, int key, TreapNode** left, TreapNode** right) {
    if (!root) {
        *left = NULL;
        *right = NULL;
    } else if (key < root->key) {
        treap_split(root->left, key, left, &root->left);
        *right = root;
    } else {
        treap_split(root->right, key, &root->right, right);
        *left = root;
    }
}

TreapNode* treap_merge(TreapNode* left, TreapNode* right) {
    if (!left) {
        return right;
    }
    if (!right) {
        return left;
    }
    if (left->priority > right->priority) {
        left->right = treap_merge(left->right, right);
        return left;
    }
    right->left = treap_merge(left, right->left);
    return right;
}

TreapNode* treap_delete(TreapNode* root, int key) {
    if (!root) {
        return NULL;
    }
    if (key < root->key) {
        root->left = treap_delete(root->left, key);
        return root;
    }
    if (key > root->key) {
        root->right = treap_delete(root->right, key);
        return root;
    }
    TreapNode* merged = treap_merge(root->left, root->right);
    free(root);
    return merged;
}

TreapNode* treap_search(TreapNode* root, int key) {
    while (root) {
        if (key == root->key) {
            return root;
        }
        root = key < root->key ? root->left : root->right;
    }
    return NULL;
}

void treap_free(TreapNode* root) {
    if (!root) {
        return;
    }
    treap_free(root->left);
    treap_free(root->right);
    free(root);
}
