#include "module4_randomized.h"
#include <stdlib.h>
#include <string.h>

static int random_level(SkipList* list) {
    int level = 0;
    while (((float)rand() / (float)RAND_MAX) < list->probability && level < list->max_level) {
        ++level;
    }
    return level;
}

static SkipNode* skip_node_new(int level, int key, const char* value) {
    SkipNode* node = (SkipNode*)calloc(1, sizeof(SkipNode));
    if (!node) {
        return NULL;
    }
    node->level = level;
    node->key = key;
    if (value) {
        strncpy(node->value, value, sizeof(node->value) - 1);
    }
    node->forward = (SkipNode**)calloc((size_t)(level + 1), sizeof(SkipNode*));
    return node;
}

/**
 * Create an empty Skip List.
 * Parameters: max_level - highest express lane, probability - promotion probability
 * Return: skip list
 * Complexity: O(1)
 */
SkipList* skip_create(int max_level, float probability) {
    SkipList* list = (SkipList*)calloc(1, sizeof(SkipList));
    if (!list) {
        return NULL;
    }
    list->max_level = max_level;
    list->probability = probability;
    list->header = skip_node_new(max_level, -1, "");
    return list;
}

/**
 * Insert or update a key in the Skip List.
 * Parameters: list - skip list, key - key, value - payload
 * Return: void
 * Complexity: O(log n) expected
 */
void skip_insert(SkipList* list, int key, const char* value) {
    if (!list) {
        return;
    }
    SkipNode** update = (SkipNode**)calloc((size_t)(list->max_level + 1), sizeof(SkipNode*));
    SkipNode* curr = list->header;
    for (int i = list->level; i >= 0; --i) {
        while (curr->forward[i] && curr->forward[i]->key < key) {
            curr = curr->forward[i];
        }
        update[i] = curr;
    }
    curr = curr->forward[0];
    if (curr && curr->key == key) {
        if (value) {
            strncpy(curr->value, value, sizeof(curr->value) - 1);
        }
        free(update);
        return;
    }
    int level = random_level(list);
    if (level > list->level) {
        for (int i = list->level + 1; i <= level; ++i) {
            update[i] = list->header;
        }
        list->level = level;
    }
    SkipNode* node = skip_node_new(level, key, value);
    for (int i = 0; i <= level; ++i) {
        node->forward[i] = update[i]->forward[i];
        update[i]->forward[i] = node;
    }
    free(update);
}

/**
 * Search for a key in the Skip List.
 * Parameters: list - skip list, key - query key
 * Return: matching node or NULL
 * Complexity: O(log n) expected
 */
SkipNode* skip_search(SkipList* list, int key) {
    if (!list) {
        return NULL;
    }
    SkipNode* curr = list->header;
    for (int i = list->level; i >= 0; --i) {
        while (curr->forward[i] && curr->forward[i]->key < key) {
            curr = curr->forward[i];
        }
    }
    curr = curr->forward[0];
    return (curr && curr->key == key) ? curr : NULL;
}

/**
 * Delete a key from the Skip List.
 * Parameters: list - skip list, key - target key
 * Return: void
 * Complexity: O(log n) expected
 */
void skip_delete(SkipList* list, int key) {
    if (!list) {
        return;
    }
    SkipNode** update = (SkipNode**)calloc((size_t)(list->max_level + 1), sizeof(SkipNode*));
    SkipNode* curr = list->header;
    for (int i = list->level; i >= 0; --i) {
        while (curr->forward[i] && curr->forward[i]->key < key) {
            curr = curr->forward[i];
        }
        update[i] = curr;
    }
    curr = curr->forward[0];
    if (curr && curr->key == key) {
        for (int i = 0; i <= list->level; ++i) {
            if (update[i]->forward[i] != curr) {
                break;
            }
            update[i]->forward[i] = curr->forward[i];
        }
        free(curr->forward);
        free(curr);
        while (list->level > 0 && !list->header->forward[list->level]) {
            --list->level;
        }
    }
    free(update);
}

/**
 * Free the entire Skip List.
 * Parameters: list - skip list
 * Return: void
 * Complexity: O(n)
 */
void skip_free(SkipList* list) {
    if (!list) {
        return;
    }
    SkipNode* curr = list->header;
    while (curr) {
        SkipNode* next = curr->forward ? curr->forward[0] : NULL;
        free(curr->forward);
        free(curr);
        curr = next;
    }
    free(list);
}
