#include "module4_randomized.h"
#include <stdlib.h>
#include <string.h>

static unsigned long bloom_hash(const char* str, unsigned long seed) {
    unsigned long hash = seed;
    while (*str) {
        hash = ((hash << 5) + hash) + (unsigned char)(*str++);
    }
    return hash;
}

/**
 * Create a Bloom filter.
 * Parameters: size - bit array size, hash_count - number of hash functions
 * Return: allocated bloom filter
 * Complexity: O(size)
 */
BloomFilter* bloom_create(int size, int hash_count) {
    BloomFilter* filter = (BloomFilter*)calloc(1, sizeof(BloomFilter));
    if (!filter) {
        return NULL;
    }
    filter->size = size;
    filter->hash_count = hash_count;
    filter->bits = (unsigned char*)calloc((size_t)size, sizeof(unsigned char));
    return filter;
}

/**
 * Add an item to the Bloom filter.
 * Parameters: filter - bloom filter, item - item string
 * Return: void
 * Complexity: O(k)
 */
void bloom_add(BloomFilter* filter, const char* item) {
    if (!filter || !item) {
        return;
    }
    for (int i = 0; i < filter->hash_count; ++i) {
        unsigned long hash = bloom_hash(item, 5381u + (unsigned long)(i * 97));
        filter->bits[hash % (unsigned long)filter->size] = 1;
    }
}

/**
 * Check whether an item may exist in the Bloom filter.
 * Parameters: filter - bloom filter, item - item string
 * Return: true if all bits are set
 * Complexity: O(k)
 */
bool bloom_check(BloomFilter* filter, const char* item) {
    if (!filter || !item) {
        return false;
    }
    for (int i = 0; i < filter->hash_count; ++i) {
        unsigned long hash = bloom_hash(item, 5381u + (unsigned long)(i * 97));
        if (!filter->bits[hash % (unsigned long)filter->size]) {
            return false;
        }
    }
    return true;
}

/**
 * Free the Bloom filter.
 * Parameters: filter - bloom filter
 * Return: void
 * Complexity: O(1)
 */
void bloom_free(BloomFilter* filter) {
    if (!filter) {
        return;
    }
    free(filter->bits);
    free(filter);
}
