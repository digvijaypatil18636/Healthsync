#include "globals.h"

// Patient database
Patient** g_patients = NULL;
int g_patient_count = 0;
int g_patient_capacity = 0;
int g_next_patient_id = 1;

// Module 1
AVLNode* g_avl_root = NULL;
BPlusTree* g_bplus_tree = NULL;
HuffmanNode* g_huffman_tree = NULL;
SplayNode* g_splay_root = NULL;

// Module 2
FibHeap* g_fib_heap = NULL;
BinomialHeap* g_binom_heap = NULL;
LeftistHeap* g_leftist_heap = NULL;
PairingHeap* g_pairing_heap = NULL;

/* auxiliary array to keep track of triage entries (for queue listing) */
TriageEntry* g_triage_entries = NULL;
int g_triage_count = 0;
int g_triage_capacity = 0;