#include "patient.h"

/**
 * Creates a new Patient struct with the given details.
 * Parameters: id - unique patient ID, firstName, lastName, dob (YYYY-MM-DD), gender ('M','F','O'), phone, email, address.
 * Return: Pointer to the new Patient, or NULL on failure.
 * Time: O(1), Space: O(1)
 */
Patient* patient_create(int id, const char* firstName, const char* lastName,
                        const char* dob, char gender,
                        const char* phone, const char* email, const char* address) {
    Patient* p = (Patient*)malloc(sizeof(Patient));
    if (!p) return NULL;
    p->id = id;
    strncpy(p->firstName, firstName, MAX_NAME_LEN - 1);
    p->firstName[MAX_NAME_LEN - 1] = '\0';
    strncpy(p->lastName, lastName, MAX_NAME_LEN - 1);
    p->lastName[MAX_NAME_LEN - 1] = '\0';
    strncpy(p->dob, dob, MAX_DOB_LEN - 1);
    p->dob[MAX_DOB_LEN - 1] = '\0';
    p->gender = gender;
    if (phone) {
        strncpy(p->phone, phone, MAX_PHONE_LEN - 1);
        p->phone[MAX_PHONE_LEN - 1] = '\0';
    } else {
        p->phone[0] = '\0';
    }
    if (email) {
        strncpy(p->email, email, MAX_EMAIL_LEN - 1);
        p->email[MAX_EMAIL_LEN - 1] = '\0';
    } else {
        p->email[0] = '\0';
    }
    if (address) {
        strncpy(p->address, address, MAX_ADDRESS_LEN - 1);
        p->address[MAX_ADDRESS_LEN - 1] = '\0';
    } else {
        p->address[0] = '\0';
    }
    /* initialize triage/vitals defaults */
    p->heartRate = 0;
    p->bloodPressure[0] = '\0';
    p->temperature = 0.0f;
    p->oxygenSaturation = 0;
    p->painLevel = 0;
    p->chiefComplaint[0] = '\0';
    return p;
}

/**
 * Frees the memory allocated for a Patient.
 * Parameters: p - pointer to Patient to free.
 * Return: void
 * Time: O(1), Space: O(1)
 */
void patient_free(Patient* p) {
    if (p) free(p);
}

/**
 * Prints the details of a Patient to stdout.
 * Parameters: p - pointer to Patient to print.
 * Return: void
 * Time: O(1), Space: O(1)
 */
void patient_print(const Patient* p) {
    if (!p) return;
    printf("ID: %d\n", p->id);
    printf("Name: %s %s\n", p->firstName, p->lastName);
    printf("DOB: %s\n", p->dob);
    printf("Gender: %c\n", p->gender);
    printf("Phone: %s\n", p->phone);
    printf("Email: %s\n", p->email);
    printf("Address: %s\n", p->address);
    printf("HeartRate: %d\n", p->heartRate);
    printf("BloodPressure: %s\n", p->bloodPressure);
    printf("Temp: %.1f\n", p->temperature);
    printf("O2: %d\n", p->oxygenSaturation);
    printf("Pain: %d\n", p->painLevel);
    printf("Complaint: %s\n", p->chiefComplaint);
}

void patient_set_triage(Patient* p,
                        int heartRate,
                        const char* bloodPressure,
                        float temperature,
                        int oxygenSaturation,
                        int painLevel,
                        const char* chiefComplaint) {
    if (!p) return;
    p->heartRate = heartRate;
    if (bloodPressure) {
        strncpy(p->bloodPressure, bloodPressure, sizeof(p->bloodPressure) - 1);
        p->bloodPressure[sizeof(p->bloodPressure) - 1] = '\0';
    }
    p->temperature = temperature;
    p->oxygenSaturation = oxygenSaturation;
    p->painLevel = painLevel;
    if (chiefComplaint) {
        strncpy(p->chiefComplaint, chiefComplaint, sizeof(p->chiefComplaint) - 1);
        p->chiefComplaint[sizeof(p->chiefComplaint) - 1] = '\0';
    }
}

/**
 * Saves a Patient to a file.
 * Parameters: fp - file pointer, p - patient to save.
 * Return: OK on success, ERROR on failure.
 * Time: O(1), Space: O(1)
 */
int patient_save(FILE* fp, const Patient* p) {
    if (!fp || !p) return ERROR;
    fprintf(fp, "%d\n%s\n%s\n%s\n%c\n%s\n%s\n%s\n",
            p->id, p->firstName, p->lastName, p->dob, p->gender,
            p->phone, p->email, p->address);
    /* triage data not persisted yet */
    return OK;
}

/**
 * Loads a Patient from a file.
 * Parameters: fp - file pointer.
 * Return: Pointer to loaded Patient, or NULL on failure.
 * Time: O(1), Space: O(1)
 */
Patient* patient_load(FILE* fp) {
    if (!fp) return NULL;
    Patient* p = (Patient*)malloc(sizeof(Patient));
    if (!p) return NULL;
    if (fscanf(fp, "%d\n", &p->id) != 1) {
        free(p);
        return NULL;
    }
    fgets(p->firstName, MAX_NAME_LEN, fp);
    p->firstName[strcspn(p->firstName, "\n")] = '\0';
    fgets(p->lastName, MAX_NAME_LEN, fp);
    p->lastName[strcspn(p->lastName, "\n")] = '\0';
    fgets(p->dob, MAX_DOB_LEN, fp);
    p->dob[strcspn(p->dob, "\n")] = '\0';
    fscanf(fp, "%c\n", &p->gender);
    fgets(p->phone, MAX_PHONE_LEN, fp);
    p->phone[strcspn(p->phone, "\n")] = '\0';
    fgets(p->email, MAX_EMAIL_LEN, fp);
    p->email[strcspn(p->email, "\n")] = '\0';
    fgets(p->address, MAX_ADDRESS_LEN, fp);
    p->address[strcspn(p->address, "\n")] = '\0';
    return p;
}