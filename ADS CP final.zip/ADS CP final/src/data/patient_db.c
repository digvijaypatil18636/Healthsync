#include "patient_db.h"
#include "module1_trees.h"
#include "globals.h"
#include <stdio.h>

/**
 * Initializes the patient database.
 * Parameters: none
 * Return: void
 * Time: O(1), Space: O(1) initially
 */
void db_init() {
    g_patient_capacity = 10;
    g_patients = (Patient**)malloc(sizeof(Patient*) * g_patient_capacity);
    if (!g_patients) {
        fprintf(stderr, "Failed to allocate patient database\n");
        exit(1);
    }
    g_patient_count = 0;
    g_next_patient_id = 1;
}

/**
 * Adds a patient to the database.
 * Parameters: p - patient to add
 * Return: the assigned ID
 * Time: O(1) amortized, Space: O(1) amortized
 */
int db_add_patient(Patient* p) {
    if (g_patient_count >= g_patient_capacity) {
        g_patient_capacity *= 2;
        g_patients = (Patient**)realloc(g_patients, sizeof(Patient*) * g_patient_capacity);
        if (!g_patients) {
            fprintf(stderr, "Failed to realloc patient database\n");
            exit(1);
        }
    }
    p->id = g_next_patient_id++;
    g_patients[g_patient_count++] = p;
    return p->id;
}

/**
 * Gets a patient by ID.
 * Parameters: id - patient ID
 * Return: pointer to patient or NULL if not found
 * Time: O(n), Space: O(1)
 */
Patient* db_get_patient(int id) {
    for (int i = 0; i < g_patient_count; i++) {
        if (g_patients[i]->id == id) {
            return g_patients[i];
        }
    }
    return NULL;
}

/**
 * Gets all patients.
 * Parameters: none
 * Return: array of patients
 * Time: O(1), Space: O(1)
 */
Patient** db_get_all() {
    return g_patients;
}

/**
 * Gets the count of patients.
 * Parameters: none
 * Return: number of patients
 * Time: O(1), Space: O(1)
 */
int db_get_count() {
    return g_patient_count;
}

/**
 * Frees the patient database.
 * Parameters: none
 * Return: void
 * Time: O(n), Space: O(1)
 */
void db_free() {
    for (int i = 0; i < g_patient_count; i++) {
        patient_free(g_patients[i]);
    }
    free(g_patients);
    g_patients = NULL;
    g_patient_count = 0;
    g_patient_capacity = 0;
}
