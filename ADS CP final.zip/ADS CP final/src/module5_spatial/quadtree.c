#include "module5_spatial.h"
#include <stdlib.h>

static bool point_in_rect(Rect rect, float x, float y) {
    return x >= rect.x1 && x <= rect.x2 && y >= rect.y1 && y <= rect.y2;
}

/**
 * Create a simplified Quadtree container.
 * Parameters: bounds - spatial bounds
 * Return: allocated Quadtree
 * Complexity: O(1)
 */
QuadTree* qt_create(Rect bounds) {
    QuadTree* tree = (QuadTree*)calloc(1, sizeof(QuadTree));
    if (!tree) {
        return NULL;
    }
    tree->bounds = bounds;
    tree->capacity = 32;
    tree->points = (QPoint*)calloc((size_t)tree->capacity, sizeof(QPoint));
    return tree;
}

/**
 * Insert a point payload into the Quadtree.
 * Parameters: tree - Quadtree, x/y - coordinates, data_id - payload id
 * Return: void
 * Complexity: O(1) amortized
 */
void qt_insert(QuadTree* tree, float x, float y, int data_id) {
    if (!tree || !point_in_rect(tree->bounds, x, y)) {
        return;
    }
    if (tree->count >= tree->capacity) {
        tree->capacity *= 2;
        tree->points = (QPoint*)realloc(tree->points, sizeof(QPoint) * (size_t)tree->capacity);
        if (!tree->points) {
            tree->count = 0;
            tree->capacity = 0;
            return;
        }
    }
    tree->points[tree->count].x = x;
    tree->points[tree->count].y = y;
    tree->points[tree->count].data_id = data_id;
    tree->count++;
}

/**
 * Query all points inside a rectangle.
 * Parameters: tree - Quadtree, query - query rectangle, out_ids - output buffer, max_results - cap
 * Return: number of matches
 * Complexity: O(n)
 */
int qt_query_range(QuadTree* tree, Rect query, int* out_ids, int max_results) {
    if (!tree || !out_ids || max_results <= 0) {
        return 0;
    }
    int count = 0;
    for (int i = 0; i < tree->count && count < max_results; ++i) {
        if (point_in_rect(query, tree->points[i].x, tree->points[i].y)) {
            out_ids[count++] = tree->points[i].data_id;
        }
    }
    return count;
}

/**
 * Free the Quadtree.
 * Parameters: tree - Quadtree
 * Return: void
 * Complexity: O(1)
 */
void qt_free(QuadTree* tree) {
    if (!tree) {
        return;
    }
    free(tree->points);
    free(tree);
}
