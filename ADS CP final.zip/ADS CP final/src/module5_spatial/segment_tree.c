#include "module5_spatial.h"
#include <stdlib.h>

static void build_internal(SegmentTree* tree, int node, int left, int right) {
    if (left == right) {
        tree->tree[node] = tree->values[left];
        return;
    }
    int mid = (left + right) / 2;
    build_internal(tree, node * 2, left, mid);
    build_internal(tree, node * 2 + 1, mid + 1, right);
    tree->tree[node] = tree->tree[node * 2] + tree->tree[node * 2 + 1];
}

static void update_internal(SegmentTree* tree, int node, int left, int right, int index, int value) {
    if (left == right) {
        tree->tree[node] = value;
        tree->values[index] = value;
        return;
    }
    int mid = (left + right) / 2;
    if (index <= mid) {
        update_internal(tree, node * 2, left, mid, index, value);
    } else {
        update_internal(tree, node * 2 + 1, mid + 1, right, index, value);
    }
    tree->tree[node] = tree->tree[node * 2] + tree->tree[node * 2 + 1];
}

static int query_internal(SegmentTree* tree, int node, int left, int right, int ql, int qr) {
    if (ql <= left && right <= qr) {
        return tree->tree[node];
    }
    int mid = (left + right) / 2;
    int sum = 0;
    if (ql <= mid) {
        sum += query_internal(tree, node * 2, left, mid, ql, qr);
    }
    if (qr > mid) {
        sum += query_internal(tree, node * 2 + 1, mid + 1, right, ql, qr);
    }
    return sum;
}

/**
 * Build a segment tree over an integer array.
 * Parameters: arr - input values, n - length
 * Return: allocated segment tree
 * Complexity: O(n)
 */
SegmentTree* st_build_segment(int* arr, int n) {
    if (!arr || n <= 0) {
        return NULL;
    }
    SegmentTree* tree = (SegmentTree*)calloc(1, sizeof(SegmentTree));
    if (!tree) {
        return NULL;
    }
    tree->n = n;
    tree->values = (int*)malloc(sizeof(int) * (size_t)n);
    tree->tree = (int*)calloc((size_t)(4 * n), sizeof(int));
    if (!tree->values || !tree->tree) {
        st_free_segment(tree);
        return NULL;
    }
    for (int i = 0; i < n; ++i) {
        tree->values[i] = arr[i];
    }
    build_internal(tree, 1, 0, n - 1);
    return tree;
}

/**
 * Point-update a segment tree value.
 * Parameters: tree - segment tree, index - value index, value - new value
 * Return: void
 * Complexity: O(log n)
 */
void st_update(SegmentTree* tree, int index, int value) {
    if (!tree || index < 0 || index >= tree->n) {
        return;
    }
    update_internal(tree, 1, 0, tree->n - 1, index, value);
}

/**
 * Query a range sum over the segment tree.
 * Parameters: tree - segment tree, left/right - inclusive range
 * Return: range sum
 * Complexity: O(log n)
 */
int st_query(SegmentTree* tree, int left, int right) {
    if (!tree || left < 0 || right >= tree->n || left > right) {
        return 0;
    }
    return query_internal(tree, 1, 0, tree->n - 1, left, right);
}

/**
 * Free the segment tree.
 * Parameters: tree - segment tree
 * Return: void
 * Complexity: O(1)
 */
void st_free_segment(SegmentTree* tree) {
    if (!tree) {
        return;
    }
    free(tree->tree);
    free(tree->values);
    free(tree);
}
