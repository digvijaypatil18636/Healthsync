#include "module5_spatial.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>

static bool rect_intersects(Rect a, Rect b) {
    return !(a.x2 < b.x1 || b.x2 < a.x1 || a.y2 < b.y1 || b.y2 < a.y1);
}

/**
 * Create a simplified R-tree container backed by a dynamic entry list.
 * Parameters: none
 * Return: allocated RTree
 * Complexity: O(1)
 */
RTree* rtree_create() {
    RTree* tree = (RTree*)calloc(1, sizeof(RTree));
    if (!tree) {
        return NULL;
    }
    tree->capacity = 16;
    tree->entries = (RTreeEntry*)calloc((size_t)tree->capacity, sizeof(RTreeEntry));
    return tree;
}

/**
 * Insert a rectangle payload into the R-tree.
 * Parameters: tree - RTree, rect - bounding box, data_id - payload id, label - payload label
 * Return: void
 * Complexity: O(1) amortized
 */
void rtree_insert(RTree* tree, Rect rect, int data_id, const char* label) {
    if (!tree) {
        return;
    }
    if (tree->count >= tree->capacity) {
        tree->capacity *= 2;
        tree->entries = (RTreeEntry*)realloc(tree->entries, sizeof(RTreeEntry) * (size_t)tree->capacity);
        if (!tree->entries) {
            tree->count = 0;
            tree->capacity = 0;
            return;
        }
    }
    tree->entries[tree->count].rect = rect;
    tree->entries[tree->count].data_id = data_id;
    if (label) {
        strncpy(tree->entries[tree->count].label, label, sizeof(tree->entries[tree->count].label) - 1);
    }
    tree->count++;
}

/**
 * Search for rectangles intersecting a query rectangle.
 * Parameters: tree - RTree, query - query rectangle, out_ids - output buffer, max_results - cap
 * Return: number of matches
 * Complexity: O(n)
 */
int rtree_search(RTree* tree, Rect query, int* out_ids, int max_results) {
    if (!tree || !out_ids || max_results <= 0) {
        return 0;
    }
    int count = 0;
    for (int i = 0; i < tree->count && count < max_results; ++i) {
        if (rect_intersects(tree->entries[i].rect, query)) {
            out_ids[count++] = tree->entries[i].data_id;
        }
    }
    return count;
}

/**
 * Find the nearest rectangle center to a query point.
 * Parameters: tree - RTree, x/y - query point
 * Return: payload id of the nearest entry or -1
 * Complexity: O(n)
 */
int rtree_nearest(RTree* tree, float x, float y) {
    if (!tree || tree->count == 0) {
        return -1;
    }
    float best_distance = FLT_MAX;
    int best_id = -1;
    for (int i = 0; i < tree->count; ++i) {
        Rect rect = tree->entries[i].rect;
        float cx = (rect.x1 + rect.x2) / 2.0f;
        float cy = (rect.y1 + rect.y2) / 2.0f;
        float dx = cx - x;
        float dy = cy - y;
        float distance = dx * dx + dy * dy;
        if (distance < best_distance) {
            best_distance = distance;
            best_id = tree->entries[i].data_id;
        }
    }
    return best_id;
}

/**
 * Free the R-tree.
 * Parameters: tree - RTree
 * Return: void
 * Complexity: O(1)
 */
void rtree_free(RTree* tree) {
    if (!tree) {
        return;
    }
    free(tree->entries);
    free(tree);
}
