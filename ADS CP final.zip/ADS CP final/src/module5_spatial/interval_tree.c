#include "module5_spatial.h"
#include <stdlib.h>

static IntervalNode* interval_new_node(int low, int high, int value) {
    IntervalNode* node = (IntervalNode*)calloc(1, sizeof(IntervalNode));
    if (!node) {
        return NULL;
    }
    node->low = low;
    node->high = high;
    node->max = high;
    node->value = value;
    return node;
}

/**
 * Create an empty interval tree root.
 * Parameters: none
 * Return: NULL root
 * Complexity: O(1)
 */
IntervalNode* it_create() {
    return NULL;
}

/**
 * Insert an interval into the interval tree.
 * Parameters: root - root node, low/high - interval, value - payload
 * Return: new root
 * Complexity: O(log n) average
 */
IntervalNode* it_insert(IntervalNode* root, int low, int high, int value) {
    if (!root) {
        return interval_new_node(low, high, value);
    }
    if (low < root->low) {
        root->left = it_insert(root->left, low, high, value);
    } else {
        root->right = it_insert(root->right, low, high, value);
    }
    if (high > root->max) {
        root->max = high;
    }
    return root;
}

/**
 * Query for an overlapping interval.
 * Parameters: root - root node, low/high - query interval
 * Return: payload value of the first overlap or -1
 * Complexity: O(log n) average
 */
int it_overlap_query(IntervalNode* root, int low, int high) {
    if (!root) {
        return -1;
    }
    if (root->low <= high && low <= root->high) {
        return root->value;
    }
    if (root->left && root->left->max >= low) {
        return it_overlap_query(root->left, low, high);
    }
    return it_overlap_query(root->right, low, high);
}

/**
 * Free the interval tree.
 * Parameters: root - root node
 * Return: void
 * Complexity: O(n)
 */
void it_free(IntervalNode* root) {
    if (!root) {
        return;
    }
    it_free(root->left);
    it_free(root->right);
    free(root);
}
