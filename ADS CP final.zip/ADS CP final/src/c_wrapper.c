#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "patient.h"
#include "patient_db.h"
#include "module1_trees.h"
#include "module2_heaps.h"

static char* wrapper_dup_string(const char* value) {
    size_t len = strlen(value);
    char* copy = (char*)malloc(len + 1);
    if (!copy) {
        return NULL;
    }
    memcpy(copy, value, len + 1);
    return copy;
}

static char* wrapper_next_line(char* input, char** context) {
    char* start = input ? input : *context;
    if (!start) {
        return NULL;
    }
    while (*start == '\n' || *start == '\r') {
        ++start;
    }
    if (*start == '\0') {
        *context = NULL;
        return NULL;
    }
    char* end = start;
    while (*end && *end != '\n' && *end != '\r') {
        ++end;
    }
    if (*end) {
        *end = '\0';
        *context = end + 1;
    } else {
        *context = NULL;
    }
    return start;
}

static AVLNode* g_avl_tree = NULL;
static BPlusTree* g_bplus_tree = NULL;
static SplayNode* g_splay_cache = NULL;
static BinomialHeap* g_triage_queue = NULL;
static LeftistHeap* g_leftist_staff_heap = NULL;
static PairingHeap* g_pairing_appt_heap = NULL;
static FibHeap* g_fib_queue = NULL;

static BPlusNode* bplus_leftmost_leaf(BPlusTree* tree) {
    if (!tree || !tree->root) {
        return NULL;
    }

    BPlusNode* node = tree->root;
    while (node && !node->is_leaf) {
        node = node->children[0];
    }
    return node;
}

void wrapper_init() {
    db_init();
}

int wrapper_add_patient(
    const char* firstName,
    const char* lastName,
    const char* dob,
    char gender,
    const char* phone,
    const char* email,
    const char* address,
    int heartRate,
    const char* bloodPressure,
    float temperature,
    int oxygenSaturation,
    int painLevel,
    const char* chiefComplaint
) {
    Patient* p = patient_create(
        0,
        firstName,
        lastName,
        dob,
        gender,
        phone,
        email,
        address
    );

    if (!p) {
        return -1;
    }

    patient_set_triage(
        p,
        heartRate,
        bloodPressure,
        temperature,
        oxygenSaturation,
        painLevel,
        chiefComplaint
    );

    int id = db_add_patient(p);
    return id;
}

int wrapper_get_patient_count() {
    return db_get_count();
}

int wrapper_get_patient_by_index(
    int index,
    int* out_id,
    char* out_firstName,
    char* out_lastName,
    char* out_dob,
    char* out_gender,
    char* out_phone,
    char* out_email,
    char* out_address,
    int* out_heartRate,
    char* out_bloodPressure,
    float* out_temperature,
    int* out_oxygenSaturation,
    int* out_painLevel,
    char* out_chiefComplaint
) {
    if (index < 0 || index >= db_get_count()) {
        return -1;
    }

    Patient** patients = db_get_all();
    Patient* p = patients[index];

    if (!p) {
        return -1;
    }

    *out_id = p->id;
    strncpy(out_firstName, p->firstName, MAX_NAME_LEN - 1);
    strncpy(out_lastName, p->lastName, MAX_NAME_LEN - 1);
    strncpy(out_dob, p->dob, MAX_DOB_LEN - 1);
    *out_gender = p->gender;
    strncpy(out_phone, p->phone, MAX_PHONE_LEN - 1);
    strncpy(out_email, p->email, MAX_EMAIL_LEN - 1);
    strncpy(out_address, p->address, MAX_ADDRESS_LEN - 1);
    *out_heartRate = p->heartRate;
    strncpy(out_bloodPressure, p->bloodPressure, 15);
    *out_temperature = p->temperature;
    *out_oxygenSaturation = p->oxygenSaturation;
    *out_painLevel = p->painLevel;
    strncpy(out_chiefComplaint, p->chiefComplaint, 127);

    return 0;
}

int wrapper_get_patient_by_id(
    int id,
    char* out_firstName,
    char* out_lastName,
    char* out_dob,
    char* out_gender,
    char* out_phone,
    char* out_email,
    char* out_address,
    int* out_heartRate,
    char* out_bloodPressure,
    float* out_temperature,
    int* out_oxygenSaturation,
    int* out_painLevel,
    char* out_chiefComplaint
) {
    Patient* p = db_get_patient(id);

    if (!p) {
        return 0;
    }

    strncpy(out_firstName, p->firstName, MAX_NAME_LEN - 1);
    strncpy(out_lastName, p->lastName, MAX_NAME_LEN - 1);
    strncpy(out_dob, p->dob, MAX_DOB_LEN - 1);
    *out_gender = p->gender;
    strncpy(out_phone, p->phone, MAX_PHONE_LEN - 1);
    strncpy(out_email, p->email, MAX_EMAIL_LEN - 1);
    strncpy(out_address, p->address, MAX_ADDRESS_LEN - 1);
    *out_heartRate = p->heartRate;
    strncpy(out_bloodPressure, p->bloodPressure, 15);
    *out_temperature = p->temperature;
    *out_oxygenSaturation = p->oxygenSaturation;
    *out_painLevel = p->painLevel;
    strncpy(out_chiefComplaint, p->chiefComplaint, 127);

    return 1;
}

int wrapper_calculate_priority(
    int heartRate,
    const char* bloodPressure,
    float temperature,
    int oxygenSaturation,
    int painLevel,
    const char* chiefComplaint
) {
    int priority = 0;

    if (heartRate) {
        int deviation = abs(heartRate - 80);
        priority += (deviation * 20) / 40;
        if (priority > 20) priority = 20;
    }

    if (bloodPressure && strlen(bloodPressure)) {
        int sys = 0;
        if (sscanf(bloodPressure, "%d/", &sys) == 1) {
            int deviation = abs(sys - 120);
            priority += (deviation * 20) / 100;
            if (priority > 40) priority = 40;
        }
    }

    if (oxygenSaturation) {
        if (oxygenSaturation < 95) {
            priority += (95 - oxygenSaturation) * 1.5;
        }
    }

    // Temperature deviation from 37°C
    if (temperature) {
        float dev = (temperature > 37.0f) ? (temperature - 37.0f) : (37.0f - temperature);
        priority += (int)(dev * 10);
        if (priority > 50) priority = 50;
    }

    if (painLevel) {
        priority += (painLevel * 30) / 10;
    }

    if (chiefComplaint && strlen(chiefComplaint)) {
        struct {
            const char *key;
            int value;
        } complaints[] = {
            {"chest pain", 15}, {"stroke", 15}, {"severe bleeding", 15},
            {"difficulty breathing", 12}, {"head injury", 12},
            {"fracture", 10}, {"burn", 10}, {"severe pain", 8},
            {"unconscious", 8}, {"moderate pain", 5}, {"fever", 5},
            {"nausea", 2}, {"mild pain", 2},
            {NULL, 0}
        };

        char lower[256];
        strncpy(lower, chiefComplaint, sizeof(lower) - 1);
        lower[sizeof(lower) - 1] = '\0';
        for (char* c = lower; *c; ++c) {
            *c = (char)tolower((unsigned char)*c);
        }

        for (int i = 0; complaints[i].key != NULL; ++i) {
            if (strstr(lower, complaints[i].key)) {
                priority += complaints[i].value;
                break;
            }
        }
    }

    if (priority > 100) priority = 100;

    return priority;
}

void wrapper_cleanup() {
    db_free();
    if (g_avl_tree) {
        avl_free(g_avl_tree);
        g_avl_tree = NULL;
    }
    if (g_bplus_tree) {
        bplus_free(g_bplus_tree);
        g_bplus_tree = NULL;
    }
    if (g_triage_queue) {
        binom_free(g_triage_queue);
        g_triage_queue = NULL;
    }
    if (g_splay_cache) {
        splay_free(g_splay_cache);
        g_splay_cache = NULL;
    }
    if (g_leftist_staff_heap) {
        leftist_free(g_leftist_staff_heap);
        g_leftist_staff_heap = NULL;
    }
    if (g_pairing_appt_heap) {
        pairing_free(g_pairing_appt_heap);
        g_pairing_appt_heap = NULL;
    }
}

static int serialize_huffman_codes(char* codes[256], char* out_codes, int out_size) {
    int offset = 0;
    if (!out_codes || out_size <= 0) {
        return 0;
    }

    out_codes[0] = '\0';
    for (int i = 0; i < 256; i++) {
        if (!codes[i]) {
            continue;
        }

        int written = snprintf(out_codes + offset, out_size - offset, "%d:%s\n", i, codes[i]);
        if (written < 0 || written >= out_size - offset) {
            return 0;
        }
        offset += written;
    }
    return 1;
}

static HuffmanNode* create_decode_root() {
    HuffmanNode* root = (HuffmanNode*)calloc(1, sizeof(HuffmanNode));
    return root;
}

static int insert_code_into_tree(HuffmanNode* root, int symbol, const char* code) {
    HuffmanNode* node = root;
    if (!root || !code || !*code) {
        return 0;
    }

    for (int i = 0; code[i]; i++) {
        if (code[i] == '0') {
            if (!node->left) {
                node->left = (HuffmanNode*)calloc(1, sizeof(HuffmanNode));
                if (!node->left) return 0;
            }
            node = node->left;
        } else if (code[i] == '1') {
            if (!node->right) {
                node->right = (HuffmanNode*)calloc(1, sizeof(HuffmanNode));
                if (!node->right) return 0;
            }
            node = node->right;
        } else {
            return 0;
        }
    }

    node->ch = (char)symbol;
    return 1;
}

static HuffmanNode* build_tree_from_serialized_codes(const char* codes) {
    if (!codes || !*codes) {
        return NULL;
    }

    HuffmanNode* root = create_decode_root();
    if (!root) {
        return NULL;
    }

    char* copy = wrapper_dup_string(codes);
    if (!copy) {
        huffman_free(root);
        return NULL;
    }

    char* context = NULL;
    char* line = wrapper_next_line(copy, &context);
    while (line) {
        int symbol = 0;
        char bit_code[256] = {0};
        if (sscanf(line, "%d:%255s", &symbol, bit_code) == 2) {
            if (!insert_code_into_tree(root, symbol, bit_code)) {
                free(copy);
                huffman_free(root);
                return NULL;
            }
        }
        line = wrapper_next_line(NULL, &context);
    }

    free(copy);
    return root;
}

int wrapper_huffman_encode(
    const char* text,
    char* out_encoded,
    int encoded_buffer_size,
    char* out_codes,
    int codes_buffer_size
) {
    int freq[256] = {0};
    char* codes[256] = {0};
    char code_buf[256] = {0};
    HuffmanNode* root = NULL;
    char* encoded = NULL;

    if (!text || !out_encoded || encoded_buffer_size <= 0 || !out_codes || codes_buffer_size <= 0) {
        return 0;
    }

    for (const unsigned char* p = (const unsigned char*)text; *p; ++p) {
        freq[*p]++;
    }

    root = huffman_build(freq, 256);
    if (!root) {
        out_encoded[0] = '\0';
        out_codes[0] = '\0';
        return 1;
    }

    huffman_build_codes(root, code_buf, 0, codes);
    encoded = huffman_encode(root, text);

    if (!encoded || (int)strlen(encoded) >= encoded_buffer_size || !serialize_huffman_codes(codes, out_codes, codes_buffer_size)) {
        for (int i = 0; i < 256; i++) if (codes[i]) free(codes[i]);
        if (encoded) free(encoded);
        huffman_free(root);
        return 0;
    }

    strcpy(out_encoded, encoded);

    for (int i = 0; i < 256; i++) if (codes[i]) free(codes[i]);
    free(encoded);
    huffman_free(root);
    return 1;
}

int wrapper_huffman_decode(
    const char* bits,
    const char* codes,
    char* out_decoded,
    int decoded_buffer_size
) {
    HuffmanNode* root = NULL;
    char* decoded = NULL;

    if (!bits || !codes || !out_decoded || decoded_buffer_size <= 0) {
        return 0;
    }

    root = build_tree_from_serialized_codes(codes);
    if (!root) {
        return 0;
    }

    decoded = huffman_decode(root, bits);
    if (!decoded || (int)strlen(decoded) >= decoded_buffer_size) {
        if (decoded) free(decoded);
        huffman_free(root);
        return 0;
    }

    strcpy(out_decoded, decoded);
    free(decoded);
    huffman_free(root);
    return 1;
}

void wrapper_rebuild_avl_tree() {
    if (g_avl_tree) {
        avl_free(g_avl_tree);
        g_avl_tree = NULL;
    }

    Patient** patients = db_get_all();
    int count = db_get_count();

    for (int i = 0; i < count; i++) {
        if (patients[i]) {
            g_avl_tree = avl_insert(g_avl_tree, patients[i]->id, patients[i]);
        }
    }
    printf("[Wrapper] AVL tree rebuilt with %d patients\n", count);
}

int wrapper_avl_search_patient(
    int patient_id,
    char* out_firstName,
    char* out_lastName,
    char* out_dob,
    char* out_gender,
    char* out_phone,
    char* out_email,
    char* out_address,
    int* out_heartRate,
    char* out_bloodPressure,
    float* out_temperature,
    int* out_oxygenSaturation,
    int* out_painLevel,
    char* out_chiefComplaint
) {
    Patient* p = avl_search(g_avl_tree, patient_id);

    if (!p) {
        return 0;
    }

    strncpy(out_firstName, p->firstName, MAX_NAME_LEN - 1);
    strncpy(out_lastName, p->lastName, MAX_NAME_LEN - 1);
    strncpy(out_dob, p->dob, MAX_DOB_LEN - 1);
    *out_gender = p->gender;
    strncpy(out_phone, p->phone, MAX_PHONE_LEN - 1);
    strncpy(out_email, p->email, MAX_EMAIL_LEN - 1);
    strncpy(out_address, p->address, MAX_ADDRESS_LEN - 1);
    *out_heartRate = p->heartRate;
    strncpy(out_bloodPressure, p->bloodPressure, 15);
    *out_temperature = p->temperature;
    *out_oxygenSaturation = p->oxygenSaturation;
    *out_painLevel = p->painLevel;
    strncpy(out_chiefComplaint, p->chiefComplaint, 127);

    return 1;
}

void wrapper_rebuild_bplus_tree() {
    if (g_bplus_tree) {
        bplus_free(g_bplus_tree);
    }

    g_bplus_tree = bplus_create();
    if (!g_bplus_tree) {
        printf("[Wrapper] Failed to create B+ tree\n");
        return;
    }

    Patient** patients = db_get_all();
    int count = db_get_count();

    for (int i = 0; i < count; i++) {
        if (patients[i]) {
            bplus_insert(g_bplus_tree, patients[i]->id, patients[i]);
        }
    }

    printf("[Wrapper] B+ tree rebuilt with %d patients\n", count);
}

int wrapper_bplus_range_query(int min_id, int max_id, int* out_ids, int max_results) {
    if (!g_bplus_tree || !g_bplus_tree->root || !out_ids || max_results <= 0) {
        return 0;
    }

    if (min_id > max_id) {
        int temp = min_id;
        min_id = max_id;
        max_id = temp;
    }

    BPlusNode* node = g_bplus_tree->root;
    while (node && !node->is_leaf) {
        int i = 0;
        while (i < node->num_keys && min_id >= node->keys[i]) {
            i++;
        }
        node = node->children[i];
    }

    int count = 0;
    while (node && count < max_results) {
        for (int i = 0; i < node->num_keys && count < max_results; i++) {
            int key = node->keys[i];
            if (key >= min_id && key <= max_id) {
                out_ids[count++] = key;
            }
        }

        if (node->num_keys > 0 && node->keys[node->num_keys - 1] > max_id) {
            break;
        }
        node = node->next;
    }

    return count;
}

int wrapper_bplus_get_all_sorted(int* out_ids, int max_results) {
    if (!g_bplus_tree || !g_bplus_tree->root || !out_ids || max_results <= 0) {
        return 0;
    }

    BPlusNode* node = bplus_leftmost_leaf(g_bplus_tree);
    int count = 0;

    while (node && count < max_results) {
        for (int i = 0; i < node->num_keys && count < max_results; i++) {
            out_ids[count++] = node->keys[i];
        }
        node = node->next;
    }

    return count;
}

int wrapper_bplus_get_paginated(int page, int per_page, int* out_ids, int max_results) {
    if (!g_bplus_tree || !g_bplus_tree->root || !out_ids || max_results <= 0 || page < 1 || per_page < 1) {
        return 0;
    }

    int offset = (page - 1) * per_page;
    BPlusNode* node = bplus_leftmost_leaf(g_bplus_tree);
    int seen = 0;
    int count = 0;

    while (node && count < max_results) {
        for (int i = 0; i < node->num_keys && count < max_results; i++) {
            if (seen++ < offset) {
                continue;
            }
            if (count >= per_page) {
                return count;
            }
            out_ids[count++] = node->keys[i];
        }
        node = node->next;
    }

    return count;
}

void wrapper_splay_clear() {
    if (g_splay_cache) {
        splay_free(g_splay_cache);
        g_splay_cache = NULL;
    }
}

void wrapper_splay_insert_patient(int patient_id) {
    Patient* p = db_get_patient(patient_id);
    if (!p) {
        return;
    }
    g_splay_cache = splay_insert(g_splay_cache, patient_id, p);
}

int wrapper_splay_search_patient(
    int patient_id,
    char* out_firstName,
    char* out_lastName,
    char* out_dob,
    char* out_gender,
    char* out_phone,
    char* out_email,
    char* out_address,
    int* out_heartRate,
    char* out_bloodPressure,
    float* out_temperature,
    int* out_oxygenSaturation,
    int* out_painLevel,
    char* out_chiefComplaint
) {
    if (!g_splay_cache) {
        return 0;
    }

    g_splay_cache = splay_search(g_splay_cache, patient_id);
    if (!g_splay_cache || g_splay_cache->key != patient_id || !g_splay_cache->data) {
        return 0;
    }

    Patient* p = g_splay_cache->data;
    strncpy(out_firstName, p->firstName, MAX_NAME_LEN - 1);
    strncpy(out_lastName, p->lastName, MAX_NAME_LEN - 1);
    strncpy(out_dob, p->dob, MAX_DOB_LEN - 1);
    *out_gender = p->gender;
    strncpy(out_phone, p->phone, MAX_PHONE_LEN - 1);
    strncpy(out_email, p->email, MAX_EMAIL_LEN - 1);
    strncpy(out_address, p->address, MAX_ADDRESS_LEN - 1);
    *out_heartRate = p->heartRate;
    strncpy(out_bloodPressure, p->bloodPressure, 15);
    *out_temperature = p->temperature;
    *out_oxygenSaturation = p->oxygenSaturation;
    *out_painLevel = p->painLevel;
    strncpy(out_chiefComplaint, p->chiefComplaint, 127);
    return 1;
}

void wrapper_leftist_init() {
    if (g_leftist_staff_heap) {
        leftist_free(g_leftist_staff_heap);
    }
    g_leftist_staff_heap = leftist_create();
}

int wrapper_leftist_insert(int workload, int staff_id) {
    if (!g_leftist_staff_heap) {
        wrapper_leftist_init();
    }
    if (!g_leftist_staff_heap) {
        return 0;
    }
    leftist_insert(&g_leftist_staff_heap, workload, staff_id);
    return 1;
}

int wrapper_leftist_extract_min(int* out_staff_id) {
    if (!g_leftist_staff_heap || !out_staff_id) {
        return -1;
    }
    return leftist_extract_min(&g_leftist_staff_heap, out_staff_id);
}

void wrapper_leftist_clear() {
    if (g_leftist_staff_heap) {
        leftist_free(g_leftist_staff_heap);
        g_leftist_staff_heap = NULL;
    }
}

void wrapper_pairing_init() {
    if (g_pairing_appt_heap) {
        pairing_free(g_pairing_appt_heap);
    }
    g_pairing_appt_heap = pairing_create();
}

int wrapper_pairing_insert(int priority, int appointment_id) {
    if (!g_pairing_appt_heap) {
        wrapper_pairing_init();
    }
    if (!g_pairing_appt_heap) {
        return 0;
    }
    pairing_insert(&g_pairing_appt_heap, priority, appointment_id);
    return 1;
}

int wrapper_pairing_extract_min(int* out_appointment_id) {
    if (!g_pairing_appt_heap || !out_appointment_id) {
        return -1;
    }
    return pairing_extract_min(&g_pairing_appt_heap, out_appointment_id);
}

void wrapper_pairing_clear() {
    if (g_pairing_appt_heap) {
        pairing_free(g_pairing_appt_heap);
        g_pairing_appt_heap = NULL;
    }
}

void wrapper_init_triage_queue() {
    if (g_triage_queue) {
        binom_free(g_triage_queue);
    }
    g_triage_queue = binom_create();
    printf("[Wrapper] Triage queue initialized (Binomial Heap)\n");
}

int wrapper_queue_add_patient(int priority, int patient_id) {
    if (!g_triage_queue) {
        return -1;
    }
    binom_insert(g_triage_queue, priority, patient_id);
    printf("[Wrapper] Patient %d added to triage queue with priority %d\n", patient_id, priority);
    return 0;
}

int wrapper_queue_extract_next(int* out_patient_id) {
    if (!g_triage_queue) {
        return -1;
    }
    int priority = binom_extract_min(g_triage_queue, out_patient_id);
    if (priority >= 0) {
        printf("[Wrapper] Extracted patient %d from queue (priority: %d)\n", *out_patient_id, priority);
    }
    return priority;
}

int wrapper_queue_get_size() {
    if (!g_triage_queue) {
        return 0;
    }
    int count = 0;
    if (g_triage_queue->head) {
        count = g_triage_queue->head->key;
    }
    return count;
}

void wrapper_fib_init_queue() {
    if (g_fib_queue) fib_free(g_fib_queue);
    g_fib_queue = fib_create();
    printf("[Fibonacci Heap] Queue initialized\n");
}

int wrapper_fib_insert(int priority, int patient_id) {
    if (!g_fib_queue) wrapper_fib_init_queue();
    if (g_fib_queue && priority >= 0 && priority <= 100) {
        fib_insert(g_fib_queue, priority, patient_id);
        return 1;
    }
    return 0;
}

int wrapper_fib_extract_min() {
    if (!g_fib_queue || !g_fib_queue->min) return -1;
    int patient_id = -1;
    fib_extract_min(g_fib_queue, &patient_id);
    return patient_id;
}

int wrapper_fib_peek_min() {
    if (!g_fib_queue || !g_fib_queue->min) return -1;
    return g_fib_queue->min->patient_id;
}

void wrapper_fib_decrease_key(int patient_id, int new_priority) {
    if (!g_fib_queue || !g_fib_queue->min) return;
    if (g_fib_queue->min->patient_id == patient_id && new_priority < g_fib_queue->min->key) {
        g_fib_queue->min->key = new_priority;
    }
}

int wrapper_fib_queue_size() {
    return g_fib_queue ? g_fib_queue->n : 0;
}

void wrapper_fib_clear_queue() {
    if (g_fib_queue) {
        fib_free(g_fib_queue);
        g_fib_queue = NULL;
        wrapper_fib_init_queue();
    }
}
