#include "module3_strings.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

static char* trie_dup_string(const char* value) {
    size_t len = strlen(value);
    char* copy = (char*)malloc(len + 1);
    if (!copy) {
        return NULL;
    }
    memcpy(copy, value, len + 1);
    return copy;
}

static TrieNode* trie_node_new(void) {
    TrieNode* node = (TrieNode*)calloc(1, sizeof(TrieNode));
    return node;
}

static void trie_collect(TrieNode* node, char* out_buffer, int buffer_size, int* used, int* count, int max_suggestions) {
    if (!node || *count >= max_suggestions || *used >= buffer_size - 1) {
        return;
    }
    if (node->is_end && node->word) {
        int written = snprintf(out_buffer + *used, (size_t)(buffer_size - *used), "%s\n", node->word);
        if (written > 0 && *used + written < buffer_size) {
            *used += written;
            (*count)++;
        }
    }
    for (int i = 0; i < 128; ++i) {
        trie_collect(node->children[i], out_buffer, buffer_size, used, count, max_suggestions);
        if (*count >= max_suggestions) {
            return;
        }
    }
}

/**
 * Create an empty Trie root.
 * Parameters: none
 * Return: root node pointer
 * Complexity: O(1)
 */
TrieNode* trie_create() {
    return trie_node_new();
}

/**
 * Insert a word into the Trie.
 * Parameters: root - trie root, word - null terminated string
 * Return: void
 * Complexity: O(m)
 */
void trie_insert(TrieNode* root, const char* word) {
    if (!root || !word) {
        return;
    }
    TrieNode* curr = root;
    for (const unsigned char* c = (const unsigned char*)word; *c; ++c) {
        if (!curr->children[*c]) {
            curr->children[*c] = trie_node_new();
        }
        curr = curr->children[*c];
    }
    curr->is_end = true;
    if (!curr->word) {
        curr->word = trie_dup_string(word);
    }
}

/**
 * Search for an exact word in the Trie.
 * Parameters: root - trie root, word - query string
 * Return: true if present else false
 * Complexity: O(m)
 */
bool trie_search(TrieNode* root, const char* word) {
    if (!root || !word) {
        return false;
    }
    TrieNode* curr = root;
    for (const unsigned char* c = (const unsigned char*)word; *c; ++c) {
        if (!curr->children[*c]) {
            return false;
        }
        curr = curr->children[*c];
    }
    return curr->is_end;
}

/**
 * Check whether a prefix exists in the Trie.
 * Parameters: root - trie root, prefix - query prefix
 * Return: true if the prefix path exists
 * Complexity: O(m)
 */
bool trie_starts_with(TrieNode* root, const char* prefix) {
    if (!root || !prefix) {
        return false;
    }
    TrieNode* curr = root;
    for (const unsigned char* c = (const unsigned char*)prefix; *c; ++c) {
        if (!curr->children[*c]) {
            return false;
        }
        curr = curr->children[*c];
    }
    return true;
}

/**
 * Serialize suggestions for a prefix into a newline-separated output buffer.
 * Parameters: root - trie root, prefix - search prefix, out_buffer - destination buffer,
 *             buffer_size - destination size, max_suggestions - suggestion cap
 * Return: number of suggestions written
 * Complexity: O(m + k)
 */
int trie_get_suggestions(TrieNode* root, const char* prefix, char* out_buffer, int buffer_size, int max_suggestions) {
    if (!root || !prefix || !out_buffer || buffer_size <= 0) {
        return 0;
    }
    TrieNode* curr = root;
    for (const unsigned char* c = (const unsigned char*)prefix; *c; ++c) {
        if (!curr->children[*c]) {
            out_buffer[0] = '\0';
            return 0;
        }
        curr = curr->children[*c];
    }

    int used = 0;
    int count = 0;
    out_buffer[0] = '\0';
    trie_collect(curr, out_buffer, buffer_size, &used, &count, max_suggestions);
    return count;
}

/**
 * Free every node in the Trie.
 * Parameters: root - trie root
 * Return: void
 * Complexity: O(n)
 */
void trie_free(TrieNode* root) {
    if (!root) {
        return;
    }
    for (int i = 0; i < 128; ++i) {
        trie_free(root->children[i]);
    }
    free(root->word);
    free(root);
}
