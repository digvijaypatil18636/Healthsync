#include "module3_strings.h"
#include <stdlib.h>
#include <string.h>

static char* sa_dup_string(const char* value) {
    size_t len = strlen(value);
    char* copy = (char*)malloc(len + 1);
    if (!copy) {
        return NULL;
    }
    memcpy(copy, value, len + 1);
    return copy;
}

static const char* g_sa_text = NULL;

static int compare_suffixes(const void* left, const void* right) {
    int i = *(const int*)left;
    int j = *(const int*)right;
    return strcmp(g_sa_text + i, g_sa_text + j);
}

/**
 * Build a suffix array for the given text.
 * Parameters: text - source string
 * Return: allocated suffix array structure
 * Complexity: O(n log n)
 */
SuffixArray* sa_build(const char* text) {
    if (!text) {
        return NULL;
    }
    SuffixArray* sa = (SuffixArray*)calloc(1, sizeof(SuffixArray));
    if (!sa) {
        return NULL;
    }
    sa->length = (int)strlen(text);
    sa->text = sa_dup_string(text);
    sa->suffixes = (int*)malloc(sizeof(int) * (size_t)sa->length);
    if (!sa->text || !sa->suffixes) {
        sa_free(sa);
        return NULL;
    }
    for (int i = 0; i < sa->length; ++i) {
        sa->suffixes[i] = i;
    }
    g_sa_text = sa->text;
    qsort(sa->suffixes, (size_t)sa->length, sizeof(int), compare_suffixes);
    g_sa_text = NULL;
    return sa;
}

/**
 * Search for all suffix positions that start with the requested pattern.
 * Parameters: sa - suffix array, pattern - query, out_indices - result buffer,
 *             max_results - maximum written entries
 * Return: number of matches found
 * Complexity: O(n log n) in this simplified implementation
 */
int sa_search(SuffixArray* sa, const char* pattern, int* out_indices, int max_results) {
    if (!sa || !pattern || !out_indices || max_results <= 0) {
        return 0;
    }
    int matches = 0;
    size_t pattern_len = strlen(pattern);
    for (int i = 0; i < sa->length && matches < max_results; ++i) {
        int index = sa->suffixes[i];
        if (strncmp(sa->text + index, pattern, pattern_len) == 0) {
            out_indices[matches++] = index;
        }
    }
    return matches;
}

/**
 * Test whether the text contains the pattern.
 * Parameters: sa - suffix array, pattern - query string
 * Return: true if present
 * Complexity: O(n log n) simplified
 */
bool sa_contains(SuffixArray* sa, const char* pattern) {
    int out_index = 0;
    return sa_search(sa, pattern, &out_index, 1) > 0;
}

/**
 * Free all memory associated with the suffix array.
 * Parameters: sa - suffix array
 * Return: void
 * Complexity: O(1)
 */
void sa_free(SuffixArray* sa) {
    if (!sa) {
        return;
    }
    free(sa->text);
    free(sa->suffixes);
    free(sa);
}
