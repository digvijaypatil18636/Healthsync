#include "module3_strings.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

static char* bk_dup_string(const char* value) {
    size_t len = strlen(value);
    char* copy = (char*)malloc(len + 1);
    if (!copy) {
        return NULL;
    }
    memcpy(copy, value, len + 1);
    return copy;
}

static int min3(int a, int b, int c) {
    return a < b ? (a < c ? a : c) : (b < c ? b : c);
}

static int bk_distance(const char* left, const char* right) {
    int m = (int)strlen(left);
    int n = (int)strlen(right);
    int* prev = (int*)malloc(sizeof(int) * (size_t)(n + 1));
    int* curr = (int*)malloc(sizeof(int) * (size_t)(n + 1));
    if (!prev || !curr) {
        free(prev);
        free(curr);
        return m > n ? m : n;
    }
    for (int j = 0; j <= n; ++j) {
        prev[j] = j;
    }
    for (int i = 1; i <= m; ++i) {
        curr[0] = i;
        for (int j = 1; j <= n; ++j) {
            int cost = left[i - 1] == right[j - 1] ? 0 : 1;
            curr[j] = min3(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
        }
        memcpy(prev, curr, sizeof(int) * (size_t)(n + 1));
    }
    int result = prev[n];
    free(prev);
    free(curr);
    return result;
}

static BKNode* bk_node_new(const char* word) {
    BKNode* node = (BKNode*)calloc(1, sizeof(BKNode));
    if (!node) {
        return NULL;
    }
    node->word = bk_dup_string(word ? word : "");
    return node;
}

/**
 * Create a BK-tree root node from the first word.
 * Parameters: word - initial word
 * Return: root node
 * Complexity: O(1)
 */
BKNode* bk_create(const char* word) {
    return bk_node_new(word);
}

/**
 * Insert a word into the BK-tree.
 * Parameters: root - address of tree root, word - word to insert
 * Return: void
 * Complexity: O(h * d)
 */
void bk_insert(BKNode** root, const char* word) {
    if (!root || !word) {
        return;
    }
    if (!*root) {
        *root = bk_node_new(word);
        return;
    }
    BKNode* curr = *root;
    int distance = bk_distance(curr->word, word);
    BKChild* child = curr->children;
    while (child) {
        if (child->distance == distance) {
            bk_insert(&child->node, word);
            return;
        }
        child = child->next;
    }
    BKChild* new_child = (BKChild*)calloc(1, sizeof(BKChild));
    if (!new_child) {
        return;
    }
    new_child->distance = distance;
    new_child->node = bk_node_new(word);
    new_child->next = curr->children;
    curr->children = new_child;
}

static void bk_search_internal(BKNode* root, const char* target, int max_distance, char* out_buffer, int buffer_size, int* used, int* count, int max_results) {
    if (!root || *count >= max_results || *used >= buffer_size - 1) {
        return;
    }
    int distance = bk_distance(root->word, target);
    if (distance <= max_distance) {
        int written = snprintf(out_buffer + *used, (size_t)(buffer_size - *used), "%s:%d\n", root->word, distance);
        if (written > 0 && *used + written < buffer_size) {
            *used += written;
            (*count)++;
        }
    }
    for (BKChild* child = root->children; child; child = child->next) {
        if (child->distance >= distance - max_distance && child->distance <= distance + max_distance) {
            bk_search_internal(child->node, target, max_distance, out_buffer, buffer_size, used, count, max_results);
        }
    }
}

/**
 * Search for close matches inside the BK-tree.
 * Parameters: root - tree root, target - query term, max_distance - edit distance cap,
 *             out_buffer - newline-separated matches, buffer_size - output size, max_results - result cap
 * Return: number of matches written
 * Complexity: O(v * d) average
 */
int bk_search(BKNode* root, const char* target, int max_distance, char* out_buffer, int buffer_size, int max_results) {
    if (!out_buffer || buffer_size <= 0) {
        return 0;
    }
    out_buffer[0] = '\0';
    int used = 0;
    int count = 0;
    bk_search_internal(root, target ? target : "", max_distance, out_buffer, buffer_size, &used, &count, max_results);
    return count;
}

/**
 * Free the entire BK-tree.
 * Parameters: root - tree root
 * Return: void
 * Complexity: O(n)
 */
void bk_free(BKNode* root) {
    if (!root) {
        return;
    }
    BKChild* child = root->children;
    while (child) {
        BKChild* next = child->next;
        bk_free(child->node);
        free(child);
        child = next;
    }
    free(root->word);
    free(root);
}
