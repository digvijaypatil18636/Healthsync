#include "module3_strings.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

static char* st_dup_string(const char* value) {
    size_t len = strlen(value);
    char* copy = (char*)malloc(len + 1);
    if (!copy) {
        return NULL;
    }
    memcpy(copy, value, len + 1);
    return copy;
}

/**
 * Build a simplified suffix tree wrapper that stores the source text.
 * Parameters: text - source string
 * Return: allocated suffix tree structure
 * Complexity: O(n)
 */
SuffixTree* st_build(const char* text) {
    if (!text) {
        return NULL;
    }
    SuffixTree* tree = (SuffixTree*)calloc(1, sizeof(SuffixTree));
    if (!tree) {
        return NULL;
    }
    tree->text = st_dup_string(text);
    return tree;
}

/**
 * Check whether a pattern exists in the simplified suffix tree.
 * Parameters: tree - suffix tree, pattern - query string
 * Return: true if found
 * Complexity: O(nm)
 */
bool st_find_pattern(SuffixTree* tree, const char* pattern) {
    if (!tree || !tree->text || !pattern) {
        return false;
    }
    return strstr(tree->text, pattern) != NULL;
}

/**
 * Emit repeated substrings meeting the minimum length into the output buffer.
 * Parameters: tree - suffix tree, out_buffer - destination, buffer_size - destination size,
 *             min_length - shortest pattern length to include
 * Return: number of patterns written
 * Complexity: O(n^2)
 */
int st_find_common_patterns(SuffixTree* tree, char* out_buffer, int buffer_size, int min_length) {
    if (!tree || !tree->text || !out_buffer || buffer_size <= 0) {
        return 0;
    }
    int count = 0;
    int used = 0;
    size_t n = strlen(tree->text);
    out_buffer[0] = '\0';

    for (size_t i = 0; i < n; ++i) {
        for (size_t len = (size_t)min_length; i + len <= n; ++len) {
            char candidate[64];
            if (len >= sizeof(candidate)) {
                break;
            }
            memcpy(candidate, tree->text + i, len);
            candidate[len] = '\0';
            if (strstr(tree->text + i + 1, candidate)) {
                int written = snprintf(out_buffer + used, (size_t)(buffer_size - used), "%s\n", candidate);
                if (written > 0 && used + written < buffer_size) {
                    used += written;
                    ++count;
                }
                break;
            }
        }
    }
    return count;
}

/**
 * Free the suffix tree.
 * Parameters: tree - suffix tree
 * Return: void
 * Complexity: O(1)
 */
void st_free(SuffixTree* tree) {
    if (!tree) {
        return;
    }
    free(tree->text);
    free(tree);
}
