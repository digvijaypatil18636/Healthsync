#include "module6_misc.h"
#include <stdlib.h>
#include <string.h>

static char* chm_dup_string(const char* value) {
    if (!value) {
        return NULL;
    }
    size_t len = strlen(value);
    char* copy = (char*)malloc(len + 1);
    if (!copy) {
        return NULL;
    }
    memcpy(copy, value, len + 1);
    return copy;
}

static unsigned long chm_hash(const char* key) {
    unsigned long hash = 5381u;
    while (*key) {
        hash = ((hash << 5) + hash) + (unsigned char)(*key++);
    }
    return hash;
}

/**
 * Create a concurrent-hashmap style container.
 * Parameters: bucket_count - number of buckets
 * Return: allocated map
 * Complexity: O(b)
 */
ConcurrentHashMap* chm_create(int bucket_count) {
    ConcurrentHashMap* map = (ConcurrentHashMap*)calloc(1, sizeof(ConcurrentHashMap));
    if (!map) {
        return NULL;
    }
    map->bucket_count = bucket_count > 0 ? bucket_count : 32;
    map->buckets = (CHMEntry**)calloc((size_t)map->bucket_count, sizeof(CHMEntry*));
    return map;
}

/**
 * Put or update a key/value entry.
 * Parameters: map - hashmap, key/value - strings
 * Return: void
 * Complexity: O(1) average
 */
void chm_put(ConcurrentHashMap* map, const char* key, const char* value) {
    if (!map || !key) {
        return;
    }
    unsigned long index = chm_hash(key) % (unsigned long)map->bucket_count;
    for (CHMEntry* entry = map->buckets[index]; entry; entry = entry->next) {
        if (strcmp(entry->key, key) == 0) {
            free(entry->value);
            entry->value = chm_dup_string(value ? value : "");
            return;
        }
    }
    CHMEntry* entry = (CHMEntry*)calloc(1, sizeof(CHMEntry));
    if (!entry) {
        return;
    }
    entry->key = chm_dup_string(key);
    entry->value = chm_dup_string(value ? value : "");
    entry->next = map->buckets[index];
    map->buckets[index] = entry;
}

/**
 * Get a value by key.
 * Parameters: map - hashmap, key - lookup key
 * Return: stored value or NULL
 * Complexity: O(1) average
 */
const char* chm_get(ConcurrentHashMap* map, const char* key) {
    if (!map || !key) {
        return NULL;
    }
    unsigned long index = chm_hash(key) % (unsigned long)map->bucket_count;
    for (CHMEntry* entry = map->buckets[index]; entry; entry = entry->next) {
        if (strcmp(entry->key, key) == 0) {
            return entry->value;
        }
    }
    return NULL;
}

/**
 * Remove a key from the hashmap.
 * Parameters: map - hashmap, key - lookup key
 * Return: void
 * Complexity: O(1) average
 */
void chm_remove(ConcurrentHashMap* map, const char* key) {
    if (!map || !key) {
        return;
    }
    unsigned long index = chm_hash(key) % (unsigned long)map->bucket_count;
    CHMEntry* prev = NULL;
    CHMEntry* curr = map->buckets[index];
    while (curr) {
        if (strcmp(curr->key, key) == 0) {
            if (prev) {
                prev->next = curr->next;
            } else {
                map->buckets[index] = curr->next;
            }
            free(curr->key);
            free(curr->value);
            free(curr);
            return;
        }
        prev = curr;
        curr = curr->next;
    }
}

/**
 * Free the hashmap.
 * Parameters: map - hashmap
 * Return: void
 * Complexity: O(n)
 */
void chm_free(ConcurrentHashMap* map) {
    if (!map) {
        return;
    }
    for (int i = 0; i < map->bucket_count; ++i) {
        CHMEntry* entry = map->buckets[i];
        while (entry) {
            CHMEntry* next = entry->next;
            free(entry->key);
            free(entry->value);
            free(entry);
            entry = next;
        }
    }
    free(map->buckets);
    free(map);
}
