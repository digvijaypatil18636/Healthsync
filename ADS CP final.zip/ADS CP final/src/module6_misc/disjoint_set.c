#include "module6_misc.h"
#include <stdlib.h>

/**
 * Create a disjoint-set union structure.
 * Parameters: size - number of elements
 * Return: allocated DSU
 * Complexity: O(n)
 */
DisjointSet* dsu_create(int size) {
    if (size <= 0) {
        return NULL;
    }
    DisjointSet* dsu = (DisjointSet*)calloc(1, sizeof(DisjointSet));
    if (!dsu) {
        return NULL;
    }
    dsu->size = size;
    dsu->parent = (int*)malloc(sizeof(int) * (size_t)size);
    dsu->rank = (int*)calloc((size_t)size, sizeof(int));
    if (!dsu->parent || !dsu->rank) {
        dsu_free(dsu);
        return NULL;
    }
    for (int i = 0; i < size; ++i) {
        dsu->parent[i] = i;
    }
    return dsu;
}

/**
 * Find the representative of an element with path compression.
 * Parameters: dsu - DSU structure, x - element index
 * Return: representative index
 * Complexity: O(alpha(n))
 */
int dsu_find(DisjointSet* dsu, int x) {
    if (!dsu || x < 0 || x >= dsu->size) {
        return -1;
    }
    if (dsu->parent[x] != x) {
        dsu->parent[x] = dsu_find(dsu, dsu->parent[x]);
    }
    return dsu->parent[x];
}

/**
 * Union two DSU sets using rank heuristic.
 * Parameters: dsu - DSU structure, a/b - element indices
 * Return: void
 * Complexity: O(alpha(n))
 */
void dsu_union(DisjointSet* dsu, int a, int b) {
    if (!dsu) {
        return;
    }
    int root_a = dsu_find(dsu, a);
    int root_b = dsu_find(dsu, b);
    if (root_a < 0 || root_b < 0 || root_a == root_b) {
        return;
    }
    if (dsu->rank[root_a] < dsu->rank[root_b]) {
        dsu->parent[root_a] = root_b;
    } else if (dsu->rank[root_a] > dsu->rank[root_b]) {
        dsu->parent[root_b] = root_a;
    } else {
        dsu->parent[root_b] = root_a;
        dsu->rank[root_a]++;
    }
}

/**
 * Free the DSU.
 * Parameters: dsu - DSU structure
 * Return: void
 * Complexity: O(1)
 */
void dsu_free(DisjointSet* dsu) {
    if (!dsu) {
        return;
    }
    free(dsu->parent);
    free(dsu->rank);
    free(dsu);
}
