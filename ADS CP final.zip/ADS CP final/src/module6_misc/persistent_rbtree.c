#include "module6_misc.h"
#include <stdlib.h>
#include <string.h>

static PersistentRBNode* clone_node(PersistentRBNode* node) {
    if (!node) {
        return NULL;
    }
    PersistentRBNode* copy = (PersistentRBNode*)calloc(1, sizeof(PersistentRBNode));
    if (!copy) {
        return NULL;
    }
    *copy = *node;
    return copy;
}

static PersistentRBNode* persistent_insert_node(PersistentRBNode* root, int key, const char* value) {
    if (!root) {
        PersistentRBNode* node = (PersistentRBNode*)calloc(1, sizeof(PersistentRBNode));
        if (!node) {
            return NULL;
        }
        node->key = key;
        node->red = true;
        if (value) {
            strncpy(node->value, value, sizeof(node->value) - 1);
        }
        return node;
    }
    PersistentRBNode* copy = clone_node(root);
    if (!copy) {
        return NULL;
    }
    if (key < copy->key) {
        copy->left = persistent_insert_node(copy->left, key, value);
    } else if (key > copy->key) {
        copy->right = persistent_insert_node(copy->right, key, value);
    } else if (value) {
        strncpy(copy->value, value, sizeof(copy->value) - 1);
    }
    copy->red = false;
    return copy;
}

static void free_version(PersistentRBNode* root) {
    if (!root) {
        return;
    }
    free_version(root->left);
    free_version(root->right);
    free(root);
}

/**
 * Create a persistent RB-tree version container.
 * Parameters: none
 * Return: allocated persistent tree
 * Complexity: O(1)
 */
PersistentRBTree* pst_create() {
    PersistentRBTree* tree = (PersistentRBTree*)calloc(1, sizeof(PersistentRBTree));
    if (!tree) {
        return NULL;
    }
    tree->capacity = 8;
    tree->versions = (PersistentRBNode**)calloc((size_t)tree->capacity, sizeof(PersistentRBNode*));
    return tree;
}

/**
 * Insert a value and append a new version root.
 * Parameters: tree - version container, key - node key, value - payload string
 * Return: root of the new version
 * Complexity: O(log n) average
 */
PersistentRBNode* pst_insert(PersistentRBTree* tree, int key, const char* value) {
    if (!tree) {
        return NULL;
    }
    if (tree->version_count >= tree->capacity) {
        tree->capacity *= 2;
        tree->versions = (PersistentRBNode**)realloc(tree->versions, sizeof(PersistentRBNode*) * (size_t)tree->capacity);
        if (!tree->versions) {
            tree->version_count = 0;
            tree->capacity = 0;
            return NULL;
        }
    }
    PersistentRBNode* base = tree->version_count ? tree->versions[tree->version_count - 1] : NULL;
    PersistentRBNode* root = persistent_insert_node(base, key, value);
    tree->versions[tree->version_count++] = root;
    return root;
}

/**
 * Search a version root for a key.
 * Parameters: root - version root, key - query key
 * Return: payload string or NULL
 * Complexity: O(log n) average
 */
const char* pst_search(PersistentRBNode* root, int key) {
    while (root) {
        if (key == root->key) {
            return root->value;
        }
        root = key < root->key ? root->left : root->right;
    }
    return NULL;
}

/**
 * Free every version in the persistent tree container.
 * Parameters: tree - version container
 * Return: void
 * Complexity: O(vn)
 */
void pst_free(PersistentRBTree* tree) {
    if (!tree) {
        return;
    }
    for (int i = 0; i < tree->version_count; ++i) {
        free_version(tree->versions[i]);
    }
    free(tree->versions);
    free(tree);
}
