#include "globals.h"
#include "patient_db.h"
#include <stdio.h>

// Save database to file
int save_database(const char* filename) {
    FILE* fp = fopen(filename, "w");
    if (!fp) return ERROR;
    fprintf(fp, "%d\n", g_patient_count);
    for (int i = 0; i < g_patient_count; i++) {
        patient_save(fp, g_patients[i]);
    }
    fclose(fp);
    return OK;
}

// Load database from file
int load_database(const char* filename) {
    FILE* fp = fopen(filename, "r");
    if (!fp) return ERROR;
    int count;
    if (fscanf(fp, "%d\n", &count) != 1) {
        fclose(fp);
        return ERROR;
    }
    for (int i = 0; i < count; i++) {
        Patient* p = patient_load(fp);
        if (p) {
            db_add_patient(p);
            g_avl_root = avl_insert(g_avl_root, p->id, p);
            bplus_insert(g_bplus_tree, p->id, p);
        }
    }
    fclose(fp);
    return OK;
}
