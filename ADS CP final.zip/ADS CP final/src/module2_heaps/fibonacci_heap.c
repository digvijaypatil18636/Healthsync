#include "module2_heaps.h"
#include <stdlib.h>
#include <string.h>

static FibNode* create_fib_node(int key, int patient_id) {
    FibNode* node = (FibNode*)malloc(sizeof(FibNode));
    if (!node) return NULL;
    node->key = key;
    node->patient_id = patient_id;
    node->degree = 0;
    node->marked = false;
    node->parent = node->child = NULL;
    node->left = node->right = node;
    return node;
}

static void fib_link(FibNode* y, FibNode* x) {
    y->left->right = y->right;
    y->right->left = y->left;
    if (x->child) {
        y->right = x->child;
        y->left = x->child->left;
        x->child->left->right = y;
        x->child->left = y;
    } else {
        x->child = y;
        y->right = y->left = y;
    }
    y->parent = x;
    x->degree++;
    y->marked = false;
}

static void consolidate(FibHeap* heap) {
    int max_degree = 32; // sufficient
    FibNode* A[max_degree];
    memset(A, 0, sizeof(A));
    FibNode* w = heap->min;
    if (!w) return;
    FibNode* start = w;
    do {
        FibNode* x = w;
        int d = x->degree;
        while (A[d]) {
            FibNode* y = A[d];
            if (x->key > y->key) {
                FibNode* temp = x;
                x = y;
                y = temp;
            }
            fib_link(y, x);
            A[d] = NULL;
            d++;
        }
        A[d] = x;
        w = w->right;
    } while (w != start);
    heap->min = NULL;
    for (int i = 0; i < max_degree; i++) {
        if (A[i]) {
            if (!heap->min) {
                heap->min = A[i];
                A[i]->left = A[i]->right = A[i];
            } else {
                A[i]->right = heap->min;
                A[i]->left = heap->min->left;
                heap->min->left->right = A[i];
                heap->min->left = A[i];
                if (A[i]->key < heap->min->key) heap->min = A[i];
            }
        }
    }
}

/**
 * Creates a new Fibonacci heap.
 * Parameters: none
 * Return: new heap
 * Time: O(1), Space: O(1)
 */
FibHeap* fib_create() {
    FibHeap* heap = (FibHeap*)malloc(sizeof(FibHeap));
    if (!heap) return NULL;
    heap->min = NULL;
    heap->n = 0;
    return heap;
}

/**
 * Inserts a node into the Fibonacci heap.
 * Parameters: heap - the heap, priority - key, patient_id - id
 * Return: void
 * Time: O(1), Space: O(1)
 */
void fib_insert(FibHeap* heap, int priority, int patient_id) {
    FibNode* node = create_fib_node(priority, patient_id);
    if (!heap->min) {
        heap->min = node;
    } else {
        node->right = heap->min;
        node->left = heap->min->left;
        heap->min->left->right = node;
        heap->min->left = node;
        if (node->key < heap->min->key) heap->min = node;
    }
    heap->n++;
}

/**
 * Extracts the minimum node from the heap.
 * Parameters: heap - the heap, out_patient_id - output patient id
 * Return: the key of extracted node, or -1 if empty
 * Time: O(log n), Space: O(log n)
 */
int fib_extract_min(FibHeap* heap, int* out_patient_id) {
    if (!heap->min) return -1;
    FibNode* z = heap->min;
    if (z->child) {
        FibNode* child = z->child;
        do {
            FibNode* next = child->right;
            child->right = heap->min;
            child->left = heap->min->left;
            heap->min->left->right = child;
            heap->min->left = child;
            child->parent = NULL;
            child = next;
        } while (child != z->child);
    }
    z->left->right = z->right;
    z->right->left = z->left;
    if (z == z->right) {
        heap->min = NULL;
    } else {
        heap->min = z->right;
        consolidate(heap);
    }
    heap->n--;
    int key = z->key;
    *out_patient_id = z->patient_id;
    free(z);
    return key;
}

/**
 * Decreases the key of a node.
 * Parameters: heap - the heap, node - the node, new_priority - new key
 * Return: void
 * Time: O(1) amortized, Space: O(1)
 */
void fib_decrease_key(FibHeap* heap, FibNode* node, int new_priority) {
    if (new_priority > node->key) return;
    node->key = new_priority;
    FibNode* y = node->parent;
    if (y && node->key < y->key) {
        // cut and cascading cut
        node->right->left = node->left;
        node->left->right = node->right;
        y->degree--;
        if (y->child == node) y->child = (node->right == node) ? NULL : node->right;
        node->right = heap->min;
        node->left = heap->min->left;
        heap->min->left->right = node;
        heap->min->left = node;
        node->parent = NULL;
        node->marked = false;
        if (node->key < heap->min->key) heap->min = node;
        if (y->marked) {
            // cascading cut
            // simplified, assume no cascading for demo
        } else {
            y->marked = true;
        }
    }
}

/**
 * Merges two Fibonacci heaps.
 * Parameters: h1, h2 - heaps to merge
 * Return: merged heap
 * Time: O(1), Space: O(1)
 */
FibHeap* fib_merge(FibHeap* h1, FibHeap* h2) {
    if (!h1) return h2;
    if (!h2) return h1;
    FibHeap* heap = fib_create();
    heap->min = h1->min;
    if (h1->min && h2->min) {
        h1->min->left->right = h2->min;
        h2->min->left->right = h1->min;
        FibNode* temp = h1->min->left;
        h1->min->left = h2->min->left;
        h2->min->left = temp;
        if (h2->min->key < h1->min->key) heap->min = h2->min;
    }
    heap->n = h1->n + h2->n;
    free(h1);
    free(h2);
    return heap;
}

/**
 * Frees the Fibonacci heap.
 * Parameters: heap - the heap
 * Return: void
 * Time: O(n), Space: O(n)
 */
void fib_free(FibHeap* heap) {
    // Simplified free
    if (heap) free(heap);
}