#include "module2_heaps.h"
#include <stdlib.h>

static LeftistNode* create_leftist_node(int key, int patient_id) {
    LeftistNode* node = (LeftistNode*)malloc(sizeof(LeftistNode));
    if (!node) return NULL;
    node->key = key;
    node->patient_id = patient_id;
    node->dist = 0;
    node->left = node->right = NULL;
    return node;
}

static int leftist_dist(LeftistNode* node) {
    return node ? node->dist : -1;
}

static LeftistNode* leftist_merge_nodes(LeftistNode* a, LeftistNode* b) {
    if (!a) return b;
    if (!b) return a;
    if (a->key > b->key) {
        LeftistNode* temp = a;
        a = b;
        b = temp;
    }
    a->right = leftist_merge_nodes(a->right, b);
    if (leftist_dist(a->left) < leftist_dist(a->right)) {
        LeftistNode* temp = a->left;
        a->left = a->right;
        a->right = temp;
    }
    a->dist = leftist_dist(a->right) + 1;
    return a;
}

/**
 * Creates a new Leftist heap.
 * Parameters: none
 * Return: new heap
 * Time: O(1), Space: O(1)
 */
LeftistHeap* leftist_create() {
    LeftistHeap* heap = (LeftistHeap*)malloc(sizeof(LeftistHeap));
    if (!heap) return NULL;
    heap->root = NULL;
    return heap;
}

/**
 * Merges two Leftist heaps.
 * Parameters: h1, h2 - heaps to merge
 * Return: merged heap
 * Time: O(log n), Space: O(log n)
 */
LeftistHeap* leftist_merge(LeftistHeap* h1, LeftistHeap* h2) {
    LeftistHeap* heap = leftist_create();
    heap->root = leftist_merge_nodes(h1->root, h2->root);
    free(h1);
    free(h2);
    return heap;
}

/**
 * Inserts a node into the Leftist heap.
 * Parameters: heap - the heap, priority - key, patient_id - id
 * Return: void
 * Time: O(log n), Space: O(log n)
 */
void leftist_insert(LeftistHeap** heap, int priority, int patient_id) {
    LeftistNode* node = create_leftist_node(priority, patient_id);
    (*heap)->root = leftist_merge_nodes((*heap)->root, node);
}

/**
 * Extracts the minimum node from the heap.
 * Parameters: heap - the heap, out_patient_id - output patient id
 * Return: the key of extracted node, or -1 if empty
 * Time: O(log n), Space: O(log n)
 */
int leftist_extract_min(LeftistHeap** heap, int* out_patient_id) {
    if (!(*heap)->root) return -1;
    LeftistNode* min = (*heap)->root;
    (*heap)->root = leftist_merge_nodes(min->left, min->right);
    int key = min->key;
    *out_patient_id = min->patient_id;
    free(min);
    return key;
}

/**
 * Frees the Leftist heap.
 * Parameters: heap - the heap
 * Return: void
 * Time: O(n), Space: O(n)
 */
void leftist_free(LeftistHeap* heap) {
    // Simplified free
    if (heap) free(heap);
}