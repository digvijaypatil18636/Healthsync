#include "module2_heaps.h"
#include <stdlib.h>

static BinomNode* create_binom_node(int key, int patient_id) {
    BinomNode* node = (BinomNode*)malloc(sizeof(BinomNode));
    if (!node) return NULL;
    node->key = key;
    node->patient_id = patient_id;
    node->degree = 0;
    node->parent = node->child = node->sibling = NULL;
    return node;
}

static BinomNode* binom_merge_trees(BinomNode* a, BinomNode* b) {
    if (a->key > b->key) {
        BinomNode* temp = a;
        a = b;
        b = temp;
    }
    b->parent = a;
    b->sibling = a->child;
    a->child = b;
    a->degree++;
    return a;
}

static BinomNode* binom_union(BinomNode* a, BinomNode* b) {
    if (!a) return b;
    if (!b) return a;
    BinomNode* head = NULL;
    BinomNode** pos = &head;
    while (a && b) {
        if (a->degree <= b->degree) {
            *pos = a;
            pos = &a->sibling;
            a = a->sibling;
        } else {
            *pos = b;
            pos = &b->sibling;
            b = b->sibling;
        }
    }
    *pos = a ? a : b;
    return head;
}

static BinomNode* binom_reverse(BinomNode* node) {
    BinomNode* prev = NULL;
    while (node) {
        BinomNode* next = node->sibling;
        node->sibling = prev;
        prev = node;
        node = next;
    }
    return prev;
}

/**
 * Creates a new Binomial heap.
 * Parameters: none
 * Return: new heap
 * Time: O(1), Space: O(1)
 */
BinomialHeap* binom_create() {
    BinomialHeap* heap = (BinomialHeap*)malloc(sizeof(BinomialHeap));
    if (!heap) return NULL;
    heap->head = NULL;
    return heap;
}

/**
 * Inserts a node into the Binomial heap.
 * Parameters: heap - the heap, priority - key, patient_id - id
 * Return: void
 * Time: O(log n), Space: O(1)
 */
void binom_insert(BinomialHeap* heap, int priority, int patient_id) {
    BinomNode* node = create_binom_node(priority, patient_id);
    heap->head = binom_union(heap->head, node);
}

/**
 * Extracts the minimum node from the heap.
 * Parameters: heap - the heap, out_patient_id - output patient id
 * Return: the key of extracted node, or -1 if empty
 * Time: O(log n), Space: O(log n)
 */
int binom_extract_min(BinomialHeap* heap, int* out_patient_id) {
    if (!heap->head) return -1;
    BinomNode* min = heap->head;
    BinomNode* min_prev = NULL;
    BinomNode* curr = heap->head;
    BinomNode* prev = NULL;
    while (curr->sibling) {
        if (curr->sibling->key < min->key) {
            min = curr->sibling;
            min_prev = curr;
        }
        prev = curr;
        curr = curr->sibling;
    }
    if (min_prev) {
        min_prev->sibling = min->sibling;
    } else {
        heap->head = min->sibling;
    }
    BinomNode* child = binom_reverse(min->child);
    heap->head = binom_union(heap->head, child);
    int key = min->key;
    *out_patient_id = min->patient_id;
    free(min);
    return key;
}

/**
 * Merges two Binomial heaps.
 * Parameters: h1, h2 - heaps to merge
 * Return: merged heap
 * Time: O(log n), Space: O(1)
 */
BinomialHeap* binom_merge(BinomialHeap* h1, BinomialHeap* h2) {
    BinomialHeap* heap = binom_create();
    heap->head = binom_union(h1->head, h2->head);
    free(h1);
    free(h2);
    return heap;
}

/**
 * Frees the Binomial heap.
 * Parameters: heap - the heap
 * Return: void
 * Time: O(n), Space: O(n)
 */
void binom_free(BinomialHeap* heap) {
    // Simplified free
    if (heap) free(heap);
}