#include "module2_heaps.h"
#include <stdlib.h>

static PairingNode* create_pairing_node(int key, int patient_id) {
    PairingNode* node = (PairingNode*)malloc(sizeof(PairingNode));
    if (!node) return NULL;
    node->key = key;
    node->patient_id = patient_id;
    node->child = node->next = NULL;
    return node;
}

static PairingNode* pairing_merge_nodes(PairingNode* a, PairingNode* b) {
    if (!a) return b;
    if (!b) return a;
    if (a->key > b->key) {
        PairingNode* temp = a;
        a = b;
        b = temp;
    }
    b->next = a->child;
    a->child = b;
    return a;
}

static PairingNode* merge_pairs(PairingNode* list) {
    if (!list || !list->next) return list;
    PairingNode* a = list;
    PairingNode* b = list->next;
    PairingNode* rest = b->next;
    a->next = b->next = NULL;
    return pairing_merge_nodes(pairing_merge_nodes(a, b), merge_pairs(rest));
}

/**
 * Creates a new Pairing heap.
 * Parameters: none
 * Return: new heap
 * Time: O(1), Space: O(1)
 */
PairingHeap* pairing_create() {
    PairingHeap* heap = (PairingHeap*)malloc(sizeof(PairingHeap));
    if (!heap) return NULL;
    heap->root = NULL;
    return heap;
}

/**
 * Merges two Pairing heaps.
 * Parameters: h1, h2 - heaps to merge
 * Return: merged heap
 * Time: O(1), Space: O(1)
 */
PairingHeap* pairing_merge(PairingHeap* h1, PairingHeap* h2) {
    PairingHeap* heap = pairing_create();
    heap->root = pairing_merge_nodes(h1->root, h2->root);
    free(h1);
    free(h2);
    return heap;
}

/**
 * Inserts a node into the Pairing heap.
 * Parameters: heap - the heap, priority - key, patient_id - id
 * Return: void
 * Time: O(1), Space: O(1)
 */
void pairing_insert(PairingHeap** heap, int priority, int patient_id) {
    PairingNode* node = create_pairing_node(priority, patient_id);
    (*heap)->root = pairing_merge_nodes((*heap)->root, node);
}

/**
 * Extracts the minimum node from the heap.
 * Parameters: heap - the heap, out_patient_id - output patient id
 * Return: the key of extracted node, or -1 if empty
 * Time: O(log n), Space: O(log n)
 */
int pairing_extract_min(PairingHeap** heap, int* out_patient_id) {
    if (!(*heap)->root) return -1;
    PairingNode* min = (*heap)->root;
    (*heap)->root = merge_pairs(min->child);
    int key = min->key;
    *out_patient_id = min->patient_id;
    free(min);
    return key;
}

/**
 * Decreases the key of a node (stub).
 * Parameters: heap - the heap, node - the node, new_priority - new key
 * Return: void
 * Time: O(1), Space: O(1)
 */
void pairing_decrease_key(PairingHeap** heap, PairingNode* node, int new_priority) {
    // Stub: not implemented
    node->key = new_priority;
}

/**
 * Frees the Pairing heap.
 * Parameters: heap - the heap
 * Return: void
 * Time: O(n), Space: O(n)
 */
void pairing_free(PairingHeap* heap) {
    // Simplified free
    if (heap) free(heap);
}