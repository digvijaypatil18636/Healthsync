#include "module1_trees.h"
#include <stdlib.h>
#include <stdio.h>

static BPlusNode* create_node(bool is_leaf) {
    BPlusNode* node = (BPlusNode*)calloc(1, sizeof(BPlusNode));
    if (!node) return NULL;
    node->is_leaf = is_leaf;
    for (int i = 0; i < BPLUS_ORDER + 1; i++) {
        node->children[i] = NULL;
    }
    if (is_leaf) {
        for (int i = 0; i < MAX_KEYS + 1; i++) {
            node->data[i] = NULL;
        }
    }
    return node;
}

static void insert_into_leaf(BPlusNode* leaf, int key, Patient* data) {
    int i = leaf->num_keys - 1;
    while (i >= 0 && leaf->keys[i] > key) {
        leaf->keys[i + 1] = leaf->keys[i];
        leaf->data[i + 1] = leaf->data[i];
        i--;
    }
    leaf->keys[i + 1] = key;
    leaf->data[i + 1] = data;
    leaf->num_keys++;
}

static void insert_into_internal(BPlusNode* node, int key, BPlusNode* child) {
    int i = node->num_keys - 1;
    while (i >= 0 && node->keys[i] > key) {
        node->keys[i + 1] = node->keys[i];
        node->children[i + 2] = node->children[i + 1];
        i--;
    }
    node->keys[i + 1] = key;
    node->children[i + 2] = child;
    node->num_keys++;
}

static BPlusNode* split_leaf(BPlusNode* leaf) {
    BPlusNode* new_leaf = create_node(true);
    int mid = leaf->num_keys / 2;
    for (int i = mid; i < leaf->num_keys; i++) {
        new_leaf->keys[i - mid] = leaf->keys[i];
        new_leaf->data[i - mid] = leaf->data[i];
        new_leaf->num_keys++;
    }
    leaf->num_keys = mid;
    new_leaf->next = leaf->next;
    leaf->next = new_leaf;
    return new_leaf;
}

static BPlusNode* split_internal(BPlusNode* node, int* promote_key) {
    BPlusNode* new_node = create_node(false);
    int mid = node->num_keys / 2;
    int original_num_keys = node->num_keys;

    *promote_key = node->keys[mid];

    for (int i = mid + 1; i < original_num_keys; i++) {
        new_node->keys[i - mid - 1] = node->keys[i];
        new_node->num_keys++;
    }

    for (int i = mid + 1; i <= original_num_keys; i++) {
        new_node->children[i - mid - 1] = node->children[i];
    }

    node->num_keys = mid;
    return new_node;
}

static void insert_helper(BPlusTree* tree, BPlusNode* node, int key, Patient* data, int* promote_key, BPlusNode** new_child) {
    if (node->is_leaf) {
        insert_into_leaf(node, key, data);
        if (node->num_keys == MAX_KEYS + 1) {
            *new_child = split_leaf(node);
            *promote_key = (*new_child)->keys[0];
        }
    } else {
        int i = 0;
        while (i < node->num_keys && key > node->keys[i]) i++;
        insert_helper(tree, node->children[i], key, data, promote_key, new_child);
        if (*new_child) {
            insert_into_internal(node, *promote_key, *new_child);
            *new_child = NULL;
            if (node->num_keys == MAX_KEYS + 1) {
                BPlusNode* split_node = split_internal(node, promote_key);
                *new_child = split_node;
            }
        }
    }
}

BPlusTree* bplus_create() {
    BPlusTree* tree = (BPlusTree*)malloc(sizeof(BPlusTree));
    if (!tree) return NULL;
    tree->root = NULL;
    return tree;
}

void bplus_insert(BPlusTree* tree, int key, Patient* data) {
    if (!tree->root) {
        tree->root = create_node(true);
        insert_into_leaf(tree->root, key, data);
        return;
    }
    int promote_key = 0;
    BPlusNode* new_child = NULL;
    insert_helper(tree, tree->root, key, data, &promote_key, &new_child);
    if (new_child) {
        BPlusNode* new_root = create_node(false);
        new_root->keys[0] = promote_key;
        new_root->children[0] = tree->root;
        new_root->children[1] = new_child;
        new_root->num_keys = 1;
        tree->root = new_root;
    }
}

Patient* bplus_search(BPlusTree* tree, int key) {
    if (!tree->root) return NULL;
    BPlusNode* node = tree->root;
    while (!node->is_leaf) {
        int i = 0;
        while (i < node->num_keys && key >= node->keys[i]) i++;
        node = node->children[i];
    }
    for (int i = 0; i < node->num_keys; i++) {
        if (node->keys[i] == key) return node->data[i];
    }
    return NULL;
}

void bplus_range_query(BPlusTree* tree, int low, int high) {
    if (!tree->root) return;
    BPlusNode* node = tree->root;
    while (!node->is_leaf) {
        int i = 0;
        while (i < node->num_keys && low >= node->keys[i]) i++;
        node = node->children[i];
    }
    while (node) {
        for (int i = 0; i < node->num_keys; i++) {
            if (node->keys[i] >= low && node->keys[i] <= high) {
                printf("Key: %d, Patient: %s %s\n", node->keys[i], node->data[i]->firstName, node->data[i]->lastName);
            }
        }
        if (node->keys[node->num_keys - 1] > high) break;
        node = node->next;
    }
}

void bplus_print(BPlusTree* tree) {
    if (!tree->root) return;
    BPlusNode* node = tree->root;
    while (!node->is_leaf) node = node->children[0];
    while (node) {
        for (int i = 0; i < node->num_keys; i++) {
            printf("%d ", node->keys[i]);
        }
        node = node->next;
    }
    printf("\n");
}

void bplus_free(BPlusTree* tree) {
    if (!tree) return;

    if (tree->root) {
        BPlusNode* stack[256];
        int top = 0;
        stack[top++] = tree->root;

        while (top > 0) {
            BPlusNode* node = stack[--top];
            if (!node->is_leaf) {
                for (int i = 0; i <= node->num_keys; i++) {
                    if (node->children[i] && top < 256) {
                        stack[top++] = node->children[i];
                    }
                }
            }
            free(node);
        }
    }

    free(tree);
}
