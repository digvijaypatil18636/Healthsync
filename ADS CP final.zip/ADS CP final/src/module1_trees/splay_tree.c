#include "module1_trees.h"

static SplayNode* new_splay_node(int key, Patient* data) {
    SplayNode* node = (SplayNode*)malloc(sizeof(SplayNode));
    if (!node) return NULL;
    node->key = key;
    node->data = data;
    node->left = node->right = NULL;
    return node;
}

static SplayNode* right_rotate_splay(SplayNode* x) {
    SplayNode* y = x->left;
    x->left = y->right;
    y->right = x;
    return y;
}

static SplayNode* left_rotate_splay(SplayNode* x) {
    SplayNode* y = x->right;
    x->right = y->left;
    y->left = x;
    return y;
}

static SplayNode* splay(SplayNode* root, int key) {
    if (!root || root->key == key) return root;
    if (key < root->key) {
        if (!root->left) return root;
        if (key < root->left->key) {
            root->left->left = splay(root->left->left, key);
            root = right_rotate_splay(root);
        } else if (key > root->left->key) {
            root->left->right = splay(root->left->right, key);
            if (root->left->right) root->left = left_rotate_splay(root->left);
        }
        return root->left ? right_rotate_splay(root) : root;
    } else {
        if (!root->right) return root;
        if (key > root->right->key) {
            root->right->right = splay(root->right->right, key);
            root = left_rotate_splay(root);
        } else if (key < root->right->key) {
            root->right->left = splay(root->right->left, key);
            if (root->right->left) root->right = right_rotate_splay(root->right);
        }
        return root->right ? left_rotate_splay(root) : root;
    }
}

SplayNode* splay_insert(SplayNode* root, int key, Patient* data) {
    if (!root) return new_splay_node(key, data);
    root = splay(root, key);
    if (root->key == key) return root;
    SplayNode* newnode = new_splay_node(key, data);
    if (key < root->key) {
        newnode->right = root;
        newnode->left = root->left;
        root->left = NULL;
    } else {
        newnode->left = root;
        newnode->right = root->right;
        root->right = NULL;
    }
    return newnode;
}

SplayNode* splay_search(SplayNode* root, int key) {
    return splay(root, key);
}

SplayNode* splay_delete(SplayNode* root, int key) {
    if (!root) return NULL;
    root = splay(root, key);
    if (root->key != key) return root;
    SplayNode* temp;
    if (!root->left) {
        temp = root;
        root = root->right;
    } else {
        temp = root;
        root = splay(root->left, key);
        root->right = temp->right;
    }
    free(temp);
    return root;
}

void splay_inorder(SplayNode* root) {
    if (root) {
        splay_inorder(root->left);
        printf("%d ", root->key);
        splay_inorder(root->right);
    }
}

void splay_free(SplayNode* root) {
    if (root) {
        splay_free(root->left);
        splay_free(root->right);
        free(root);
    }
}
