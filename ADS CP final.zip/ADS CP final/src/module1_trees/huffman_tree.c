#include "module1_trees.h"
#include <string.h>

#define HUFF_HEAP_SIZE 256

typedef struct HuffHeap {
    HuffmanNode* nodes[HUFF_HEAP_SIZE];
    int size;
} HuffHeap;

static HuffHeap* create_huff_heap() {
    HuffHeap* heap = (HuffHeap*)malloc(sizeof(HuffHeap));
    heap->size = 0;
    return heap;
}

static void huff_heap_insert(HuffHeap* heap, HuffmanNode* node) {
    heap->nodes[heap->size++] = node;
    int i = heap->size - 1;
    while (i > 0 && heap->nodes[i]->freq < heap->nodes[(i-1)/2]->freq) {
        HuffmanNode* temp = heap->nodes[i];
        heap->nodes[i] = heap->nodes[(i-1)/2];
        heap->nodes[(i-1)/2] = temp;
        i = (i-1)/2;
    }
}

static HuffmanNode* huff_heap_extract_min(HuffHeap* heap) {
    if (heap->size == 0) return NULL;
    HuffmanNode* min = heap->nodes[0];
    heap->nodes[0] = heap->nodes[--heap->size];
    int i = 0;
    while (1) {
        int left = 2*i + 1, right = 2*i + 2, smallest = i;
        if (left < heap->size && heap->nodes[left]->freq < heap->nodes[smallest]->freq) smallest = left;
        if (right < heap->size && heap->nodes[right]->freq < heap->nodes[smallest]->freq) smallest = right;
        if (smallest == i) break;
        HuffmanNode* temp = heap->nodes[i];
        heap->nodes[i] = heap->nodes[smallest];
        heap->nodes[smallest] = temp;
        i = smallest;
    }
    return min;
}

static HuffmanNode* create_huff_node(char ch, int freq) {
    HuffmanNode* node = (HuffmanNode*)malloc(sizeof(HuffmanNode));
    node->ch = ch;
    node->freq = freq;
    node->left = node->right = NULL;
    return node;
}

HuffmanNode* huffman_build(int* freq, int n) {
    HuffHeap* heap = create_huff_heap();
    for (int i = 0; i < n; i++) {
        if (freq[i] > 0) {
            huff_heap_insert(heap, create_huff_node((char)i, freq[i]));
        }
    }
    if (heap->size == 0) {
        free(heap);
        return NULL;
    }
    while (heap->size > 1) {
        HuffmanNode* left = huff_heap_extract_min(heap);
        HuffmanNode* right = huff_heap_extract_min(heap);
        HuffmanNode* top = create_huff_node('\0', left->freq + right->freq);
        top->left = left;
        top->right = right;
        huff_heap_insert(heap, top);
    }
    HuffmanNode* root = huff_heap_extract_min(heap);
    free(heap);
    return root;
}

void huffman_build_codes(HuffmanNode* node, char* code, int len, char* codes[256]) {
    if (!node) return;
    if (!node->left && !node->right) {
        if (len == 0) {
            code[len++] = '0';
        }
        code[len] = '\0';
        codes[(unsigned char)node->ch] = strdup(code);
        return;
    }
    code[len] = '0';
    huffman_build_codes(node->left, code, len+1, codes);
    code[len] = '1';
    huffman_build_codes(node->right, code, len+1, codes);
}

char* huffman_encode(HuffmanNode* root, const char* text) {
    char* codes[256] = {0};
    char code[256];
    int code_len = 0;
    huffman_build_codes(root, code, 0, codes);

    size_t len = strlen(text);
    char* encoded = (char*)malloc(len * 8 + 1);
    encoded[0] = '\0';
    for (size_t i = 0; i < len; i++) {
        char* c = codes[(unsigned char)text[i]];
        if (c) strcat(encoded, c);
    }
    for (int i = 0; i < 256; i++) if (codes[i]) free(codes[i]);
    return encoded;
}

char* huffman_decode(HuffmanNode* root, const char* bits) {
    if (!root) {
        char* empty = (char*)malloc(1);
        if (empty) empty[0] = '\0';
        return empty;
    }

    if (!root->left && !root->right) {
        size_t bit_len = strlen(bits);
        char* decoded = (char*)malloc(bit_len + 1);
        if (!decoded) return NULL;
        for (size_t i = 0; i < bit_len; i++) {
            decoded[i] = root->ch;
        }
        decoded[bit_len] = '\0';
        return decoded;
    }

    char* decoded = (char*)malloc(strlen(bits) + 1);
    int idx = 0;
    HuffmanNode* node = root;
    for (size_t i = 0; bits[i]; i++) {
        if (bits[i] == '0') node = node->left;
        else node = node->right;
        if (!node->left && !node->right) {
            decoded[idx++] = node->ch;
            node = root;
        }
    }
    decoded[idx] = '\0';
    return decoded;
}

void huffman_free(HuffmanNode* root) {
    if (root) {
        huffman_free(root->left);
        huffman_free(root->right);
        free(root);
    }
}
