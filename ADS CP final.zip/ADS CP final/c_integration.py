"""
C Integration Module for HealthSync
Provides Python interface to call C library functions via ctypes
"""

import ctypes
import os
import sys
from ctypes import c_char_p, c_int, c_float, POINTER, c_void_p

# Find and load the DLL
def load_c_library():
    """Load the healthsync_c.dll library"""
    library_names = ["healthsync_c.dll", "libhealthsync_c.so"]
    
    # Try to find the DLL in the current directory or workspace
    for library_name in library_names:
        possible_paths = [
            library_name,
            os.path.join(os.path.dirname(__file__), library_name),
            os.path.join(os.getcwd(), library_name),
        ]

        for path in possible_paths:
            if os.path.exists(path):
                try:
                    print(f"[C Integration] Loading library: {path}")
                    return ctypes.CDLL(path)
                except OSError as e:
                    print(f"[C Integration] Failed to load {path}: {e}")
                    continue
    
    raise FileNotFoundError(
        "Could not find healthsync_c.dll or libhealthsync_c.so. Please build the C code first."
    )

try:
    c_lib = load_c_library()
    LIBRARY_LOADED = True
    print("[C Integration] Library loaded successfully")
except Exception as e:
    print(f"[C Integration] WARNING: Could not load C library: {e}")
    print(f"[C Integration] NOTE: Data structures are DESIGNED to be mandatory but fallback is enabled for now")
    print(f"[C Integration] For production deployment, recompile with matching architecture")
    c_lib = None
    LIBRARY_LOADED = False

# Define function signatures if library is loaded
if LIBRARY_LOADED:
    # Initialize
    c_lib.wrapper_init.argtypes = []
    c_lib.wrapper_init.restype = None

    # Add patient
    c_lib.wrapper_add_patient.argtypes = [
        c_char_p, c_char_p, c_char_p, ctypes.c_char, 
        c_char_p, c_char_p, c_char_p,
        c_int, c_char_p, c_float, c_int, c_int, c_char_p
    ]
    c_lib.wrapper_add_patient.restype = c_int

    # Get count
    c_lib.wrapper_get_patient_count.argtypes = []
    c_lib.wrapper_get_patient_count.restype = c_int

    # Get patient by index
    c_lib.wrapper_get_patient_by_index.argtypes = [
        c_int,  # index
        POINTER(c_int),  # out_id
        ctypes.c_char_p,  # out_firstName (buffer)
        ctypes.c_char_p,  # out_lastName (buffer)
        ctypes.c_char_p,  # out_dob (buffer)
        POINTER(ctypes.c_char),  # out_gender
        ctypes.c_char_p,  # out_phone (buffer)
        ctypes.c_char_p,  # out_email (buffer)
        ctypes.c_char_p,  # out_address (buffer)
        POINTER(c_int),  # out_heartRate
        ctypes.c_char_p,  # out_bloodPressure (buffer)
        POINTER(c_float),  # out_temperature
        POINTER(c_int),  # out_oxygenSaturation
        POINTER(c_int),  # out_painLevel
        ctypes.c_char_p,  # out_chiefComplaint (buffer)
    ]
    c_lib.wrapper_get_patient_by_index.restype = c_int

    # Get patient by ID
    c_lib.wrapper_get_patient_by_id.argtypes = [
        c_int,  # id
        ctypes.c_char_p,  # out_firstName (buffer)
        ctypes.c_char_p,  # out_lastName (buffer)
        ctypes.c_char_p,  # out_dob (buffer)
        POINTER(ctypes.c_char),  # out_gender
        ctypes.c_char_p,  # out_phone (buffer)
        ctypes.c_char_p,  # out_email (buffer)
        ctypes.c_char_p,  # out_address (buffer)
        POINTER(c_int),  # out_heartRate
        ctypes.c_char_p,  # out_bloodPressure (buffer)
        POINTER(c_float),  # out_temperature
        POINTER(c_int),  # out_oxygenSaturation
        POINTER(c_int),  # out_painLevel
        ctypes.c_char_p,  # out_chiefComplaint (buffer)
    ]
    c_lib.wrapper_get_patient_by_id.restype = c_int

    # Calculate priority
    c_lib.wrapper_calculate_priority.argtypes = [
        c_int, c_char_p, c_float, c_int, c_int, c_char_p
    ]
    c_lib.wrapper_calculate_priority.restype = c_int

    # Cleanup
    c_lib.wrapper_cleanup.argtypes = []
    c_lib.wrapper_cleanup.restype = None

    # Huffman compression functions
    c_lib.wrapper_huffman_encode.argtypes = [
        ctypes.c_char_p, ctypes.c_char_p, c_int, ctypes.c_char_p, c_int
    ]
    c_lib.wrapper_huffman_encode.restype = c_int

    c_lib.wrapper_huffman_decode.argtypes = [
        ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, c_int
    ]
    c_lib.wrapper_huffman_decode.restype = c_int

    # AVL Tree functions
    c_lib.wrapper_rebuild_avl_tree.argtypes = []
    c_lib.wrapper_rebuild_avl_tree.restype = None

    c_lib.wrapper_avl_search_patient.argtypes = [
        c_int,  # patient_id
        ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p,
        POINTER(ctypes.c_char), ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p,
        POINTER(c_int), ctypes.c_char_p, POINTER(c_float),
        POINTER(c_int), POINTER(c_int), ctypes.c_char_p
    ]
    c_lib.wrapper_avl_search_patient.restype = c_int

    # B+ Tree functions
    c_lib.wrapper_rebuild_bplus_tree.argtypes = []
    c_lib.wrapper_rebuild_bplus_tree.restype = None

    c_lib.wrapper_bplus_range_query.argtypes = [c_int, c_int, POINTER(c_int), c_int]
    c_lib.wrapper_bplus_range_query.restype = c_int

    c_lib.wrapper_bplus_get_all_sorted.argtypes = [POINTER(c_int), c_int]
    c_lib.wrapper_bplus_get_all_sorted.restype = c_int

    c_lib.wrapper_bplus_get_paginated.argtypes = [c_int, c_int, POINTER(c_int), c_int]
    c_lib.wrapper_bplus_get_paginated.restype = c_int

    # Splay cache functions
    c_lib.wrapper_splay_clear.argtypes = []
    c_lib.wrapper_splay_clear.restype = None

    c_lib.wrapper_splay_insert_patient.argtypes = [c_int]
    c_lib.wrapper_splay_insert_patient.restype = None

    c_lib.wrapper_splay_search_patient.argtypes = [
        c_int,
        ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p,
        POINTER(ctypes.c_char), ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p,
        POINTER(c_int), ctypes.c_char_p, POINTER(c_float),
        POINTER(c_int), POINTER(c_int), ctypes.c_char_p
    ]
    c_lib.wrapper_splay_search_patient.restype = c_int

    # Leftist heap functions
    c_lib.wrapper_leftist_init.argtypes = []
    c_lib.wrapper_leftist_init.restype = None

    c_lib.wrapper_leftist_insert.argtypes = [c_int, c_int]
    c_lib.wrapper_leftist_insert.restype = c_int

    c_lib.wrapper_leftist_extract_min.argtypes = [POINTER(c_int)]
    c_lib.wrapper_leftist_extract_min.restype = c_int

    c_lib.wrapper_leftist_clear.argtypes = []
    c_lib.wrapper_leftist_clear.restype = None

    # Pairing heap functions
    c_lib.wrapper_pairing_init.argtypes = []
    c_lib.wrapper_pairing_init.restype = None

    c_lib.wrapper_pairing_insert.argtypes = [c_int, c_int]
    c_lib.wrapper_pairing_insert.restype = c_int

    c_lib.wrapper_pairing_extract_min.argtypes = [POINTER(c_int)]
    c_lib.wrapper_pairing_extract_min.restype = c_int

    c_lib.wrapper_pairing_clear.argtypes = []
    c_lib.wrapper_pairing_clear.restype = None

    # Triage Queue functions (Binomial Heap)
    c_lib.wrapper_init_triage_queue.argtypes = []
    c_lib.wrapper_init_triage_queue.restype = None

    c_lib.wrapper_queue_add_patient.argtypes = [c_int, c_int]  # priority, patient_id
    c_lib.wrapper_queue_add_patient.restype = c_int

    c_lib.wrapper_queue_extract_next.argtypes = [POINTER(c_int)]  # out_patient_id
    c_lib.wrapper_queue_extract_next.restype = c_int

    c_lib.wrapper_queue_get_size.argtypes = []
    c_lib.wrapper_queue_get_size.restype = c_int

    # Fibonacci Heap functions (Real-time priority queue)
    c_lib.wrapper_fib_init_queue.argtypes = []
    c_lib.wrapper_fib_init_queue.restype = None

    c_lib.wrapper_fib_insert.argtypes = [c_int, c_int]  # priority, patient_id
    c_lib.wrapper_fib_insert.restype = c_int

    c_lib.wrapper_fib_extract_min.argtypes = []
    c_lib.wrapper_fib_extract_min.restype = c_int

    c_lib.wrapper_fib_peek_min.argtypes = []
    c_lib.wrapper_fib_peek_min.restype = c_int

    c_lib.wrapper_fib_decrease_key.argtypes = [c_int, c_int]  # patient_id, new_priority
    c_lib.wrapper_fib_decrease_key.restype = None

    c_lib.wrapper_fib_queue_size.argtypes = []
    c_lib.wrapper_fib_queue_size.restype = c_int

    c_lib.wrapper_fib_clear_queue.argtypes = []
    c_lib.wrapper_fib_clear_queue.restype = None


class CHealthSync:
    """Wrapper class for C library functions"""

    @staticmethod
    def initialize():
        """Initialize the C database"""
        if LIBRARY_LOADED:
            c_lib.wrapper_init()
            print("[C Integration] Database initialized")
        else:
            print("[C Integration] C library not loaded - using fallback")

    @staticmethod
    def add_patient(firstname, lastname, dob, gender, phone, email, address,
                   heart_rate, blood_pressure, temperature, oxygen_sat, pain_level, complaint):
        """Add a patient to the C database - returns patient ID"""
        if not LIBRARY_LOADED:
            return None

        try:
            # Encode strings to bytes for C
            fn = firstname.encode('utf-8') if firstname else b''
            ln = lastname.encode('utf-8') if lastname else b''
            d = dob.encode('utf-8') if dob else b''
            g = gender.encode('utf-8')[0] if gender else ord('M')
            ph = phone.encode('utf-8') if phone else b''
            em = email.encode('utf-8') if email else b''
            ad = address.encode('utf-8') if address else b''
            bp = blood_pressure.encode('utf-8') if blood_pressure else b''
            c = complaint.encode('utf-8') if complaint else b''

            patient_id = c_lib.wrapper_add_patient(
                fn, ln, d, g, ph, em, ad,
                heart_rate, bp, temperature, oxygen_sat, pain_level, c
            )

            if patient_id > 0:
                print(f"[C Integration] Patient added with ID {patient_id}")
                return patient_id
            else:
                print("[C Integration] Failed to add patient")
                return None

        except Exception as e:
            print(f"[C Integration] Error adding patient: {e}")
            return None

    @staticmethod
    def huffman_encode_text(text):
        """Encode text using the C Huffman implementation."""
        if not LIBRARY_LOADED:
            return None

        try:
            encoded_buffer = ctypes.create_string_buffer(max(len(text) * 8 + 1, 1))
            codes_buffer = ctypes.create_string_buffer(max(len(text) * 16 + 1024, 1024))
            result = c_lib.wrapper_huffman_encode(
                (text or '').encode('utf-8'),
                encoded_buffer,
                len(encoded_buffer),
                codes_buffer,
                len(codes_buffer)
            )

            if result != 1:
                return None

            codes = {}
            for line in codes_buffer.value.decode('utf-8').splitlines():
                if not line.strip():
                    continue
                symbol, code = line.split(':', 1)
                codes[chr(int(symbol))] = code

            return encoded_buffer.value.decode('utf-8'), codes
        except Exception as e:
            print(f"[C Integration] Error encoding Huffman text: {e}")
            return None

    @staticmethod
    def huffman_decode_text(bits, codes):
        """Decode Huffman-encoded text using the C implementation."""
        if not LIBRARY_LOADED:
            return None

        try:
            serialized_codes = '\n'.join(f"{ord(ch)}:{code}" for ch, code in codes.items())
            decoded_buffer = ctypes.create_string_buffer(max(len(bits) + 1, 1))
            result = c_lib.wrapper_huffman_decode(
                (bits or '').encode('utf-8'),
                serialized_codes.encode('utf-8'),
                decoded_buffer,
                len(decoded_buffer)
            )

            if result != 1:
                return None

            return decoded_buffer.value.decode('utf-8')
        except Exception as e:
            print(f"[C Integration] Error decoding Huffman text: {e}")
            return None

    @staticmethod
    def get_patient_count():
        """Get total number of patients in C database"""
        if not LIBRARY_LOADED:
            return 0
        try:
            count = c_lib.wrapper_get_patient_count()
            return count
        except Exception as e:
            print(f"[C Integration] Error getting patient count: {e}")
            return 0

    @staticmethod
    def get_patient_by_index(index):
        """Get patient data by index (0-based) - returns dict or None"""
        if not LIBRARY_LOADED:
            return None

        try:
            # Allocate output buffers
            out_id = c_int()
            out_firstName = ctypes.create_string_buffer(100)
            out_lastName = ctypes.create_string_buffer(100)
            out_dob = ctypes.create_string_buffer(11)
            out_gender = ctypes.c_char()
            out_phone = ctypes.create_string_buffer(20)
            out_email = ctypes.create_string_buffer(100)
            out_address = ctypes.create_string_buffer(200)
            out_heartRate = c_int()
            out_bloodPressure = ctypes.create_string_buffer(16)
            out_temperature = c_float()
            out_oxygenSaturation = c_int()
            out_painLevel = c_int()
            out_chiefComplaint = ctypes.create_string_buffer(128)

            result = c_lib.wrapper_get_patient_by_index(
                index,
                ctypes.byref(out_id),
                out_firstName,
                out_lastName,
                out_dob,
                ctypes.byref(out_gender),
                out_phone,
                out_email,
                out_address,
                ctypes.byref(out_heartRate),
                out_bloodPressure,
                ctypes.byref(out_temperature),
                ctypes.byref(out_oxygenSaturation),
                ctypes.byref(out_painLevel),
                out_chiefComplaint,
            )

            if result == 0:
                return {
                    'id': out_id.value,
                    'firstName': out_firstName.value.decode('utf-8'),
                    'lastName': out_lastName.value.decode('utf-8'),
                    'dob': out_dob.value.decode('utf-8'),
                    'gender': out_gender.value.decode('utf-8'),
                    'phone': out_phone.value.decode('utf-8'),
                    'email': out_email.value.decode('utf-8'),
                    'address': out_address.value.decode('utf-8'),
                    'heartRate': out_heartRate.value,
                    'bloodPressure': out_bloodPressure.value.decode('utf-8'),
                    'temperature': out_temperature.value,
                    'oxygenSaturation': out_oxygenSaturation.value,
                    'painLevel': out_painLevel.value,
                    'chiefComplaint': out_chiefComplaint.value.decode('utf-8'),
                }
            else:
                return None

        except Exception as e:
            print(f"[C Integration] Error getting patient by index: {e}")
            return None

    @staticmethod
    def get_patient_by_id(patient_id):
        """Get patient data by ID - returns dict or None"""
        if not LIBRARY_LOADED:
            return None

        try:
            out_firstName = ctypes.create_string_buffer(100)
            out_lastName = ctypes.create_string_buffer(100)
            out_dob = ctypes.create_string_buffer(11)
            out_gender = ctypes.c_char()
            out_phone = ctypes.create_string_buffer(20)
            out_email = ctypes.create_string_buffer(100)
            out_address = ctypes.create_string_buffer(200)
            out_heartRate = c_int()
            out_bloodPressure = ctypes.create_string_buffer(16)
            out_temperature = c_float()
            out_oxygenSaturation = c_int()
            out_painLevel = c_int()
            out_chiefComplaint = ctypes.create_string_buffer(128)

            result = c_lib.wrapper_get_patient_by_id(
                patient_id,
                out_firstName,
                out_lastName,
                out_dob,
                ctypes.byref(out_gender),
                out_phone,
                out_email,
                out_address,
                ctypes.byref(out_heartRate),
                out_bloodPressure,
                ctypes.byref(out_temperature),
                ctypes.byref(out_oxygenSaturation),
                ctypes.byref(out_painLevel),
                out_chiefComplaint,
            )

            if result == 1:
                return {
                    'id': patient_id,
                    'firstName': out_firstName.value.decode('utf-8'),
                    'lastName': out_lastName.value.decode('utf-8'),
                    'dob': out_dob.value.decode('utf-8'),
                    'gender': out_gender.value.decode('utf-8'),
                    'phone': out_phone.value.decode('utf-8'),
                    'email': out_email.value.decode('utf-8'),
                    'address': out_address.value.decode('utf-8'),
                    'heartRate': out_heartRate.value,
                    'bloodPressure': out_bloodPressure.value.decode('utf-8'),
                    'temperature': out_temperature.value,
                    'oxygenSaturation': out_oxygenSaturation.value,
                    'painLevel': out_painLevel.value,
                    'chiefComplaint': out_chiefComplaint.value.decode('utf-8'),
                }
            else:
                return None

        except Exception as e:
            print(f"[C Integration] Error getting patient by ID: {e}")
            return None

    @staticmethod
    def calculate_priority(heart_rate, blood_pressure, temperature, oxygen_sat, pain_level, complaint):
        """Calculate triage priority (0-100) using C function"""
        if not LIBRARY_LOADED:
            return None

        try:
            bp = blood_pressure.encode('utf-8') if blood_pressure else b''
            c = complaint.encode('utf-8') if complaint else b''

            priority = c_lib.wrapper_calculate_priority(
                heart_rate, bp, temperature, oxygen_sat, pain_level, c
            )
            return priority

        except Exception as e:
            print(f"[C Integration] Error calculating priority: {e}")
            return None

    @staticmethod
    def cleanup():
        """Clean up C resources"""
        if LIBRARY_LOADED:
            c_lib.wrapper_cleanup()
            print("[C Integration] Cleaned up C library")

    @staticmethod
    def rebuild_avl_tree():
        """Rebuild AVL tree from current database for O(log n) lookups"""
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_rebuild_avl_tree()
            print("[C Integration] AVL tree rebuilt")
            return True
        except Exception as e:
            print(f"[C Integration] Error rebuilding AVL tree: {e}")
            return False

    @staticmethod
    def avl_search_patient(patient_id):
        """Search for patient using AVL tree - O(log n) instead of O(n)"""
        if not LIBRARY_LOADED:
            return None

        try:
            out_firstName = ctypes.create_string_buffer(100)
            out_lastName = ctypes.create_string_buffer(100)
            out_dob = ctypes.create_string_buffer(11)
            out_gender = ctypes.c_char()
            out_phone = ctypes.create_string_buffer(20)
            out_email = ctypes.create_string_buffer(100)
            out_address = ctypes.create_string_buffer(200)
            out_heartRate = c_int()
            out_bloodPressure = ctypes.create_string_buffer(16)
            out_temperature = c_float()
            out_oxygenSaturation = c_int()
            out_painLevel = c_int()
            out_chiefComplaint = ctypes.create_string_buffer(128)

            result = c_lib.wrapper_avl_search_patient(
                patient_id,
                out_firstName,
                out_lastName,
                out_dob,
                ctypes.byref(out_gender),
                out_phone,
                out_email,
                out_address,
                ctypes.byref(out_heartRate),
                out_bloodPressure,
                ctypes.byref(out_temperature),
                ctypes.byref(out_oxygenSaturation),
                ctypes.byref(out_painLevel),
                out_chiefComplaint,
            )

            if result == 1:
                return {
                    'id': patient_id,
                    'firstName': out_firstName.value.decode('utf-8'),
                    'lastName': out_lastName.value.decode('utf-8'),
                    'dob': out_dob.value.decode('utf-8'),
                    'gender': out_gender.value.decode('utf-8'),
                    'phone': out_phone.value.decode('utf-8'),
                    'email': out_email.value.decode('utf-8'),
                    'address': out_address.value.decode('utf-8'),
                    'heartRate': out_heartRate.value,
                    'bloodPressure': out_bloodPressure.value.decode('utf-8'),
                    'temperature': out_temperature.value,
                    'oxygenSaturation': out_oxygenSaturation.value,
                    'painLevel': out_painLevel.value,
                    'chiefComplaint': out_chiefComplaint.value.decode('utf-8'),
                }
            return None
        except Exception as e:
            print(f"[C Integration] Error in AVL search: {e}")
            return None

    @staticmethod
    def rebuild_bplus_tree():
        """Rebuild B+ tree from the current C patient database"""
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_rebuild_bplus_tree()
            print("[C Integration] B+ tree rebuilt")
            return True
        except Exception as e:
            print(f"[C Integration] Error rebuilding B+ tree: {e}")
            return False

    @staticmethod
    def _collect_patients_from_ids(patient_ids):
        patients = []
        for patient_id in patient_ids:
            patient = CHealthSync.get_patient_by_id(patient_id)
            if patient:
                patients.append(patient)
        return patients

    @staticmethod
    def bplus_range_query(min_id, max_id, max_results=512):
        """Return patients whose IDs fall inside the inclusive range"""
        if not LIBRARY_LOADED:
            return []
        try:
            buffer_size = max(1, max_results)
            out_ids = (c_int * buffer_size)()
            count = c_lib.wrapper_bplus_range_query(min_id, max_id, out_ids, buffer_size)
            return CHealthSync._collect_patients_from_ids(out_ids[i] for i in range(count))
        except Exception as e:
            print(f"[C Integration] Error running B+ range query: {e}")
            return []

    @staticmethod
    def bplus_get_all_sorted(max_results=2048):
        """Return all patients ordered by patient ID using leaf traversal"""
        if not LIBRARY_LOADED:
            return []
        try:
            buffer_size = max(1, max_results)
            out_ids = (c_int * buffer_size)()
            count = c_lib.wrapper_bplus_get_all_sorted(out_ids, buffer_size)
            return CHealthSync._collect_patients_from_ids(out_ids[i] for i in range(count))
        except Exception as e:
            print(f"[C Integration] Error getting sorted B+ patients: {e}")
            return []

    @staticmethod
    def bplus_get_paginated(page, per_page, max_results=None):
        """Return a sorted page of patients from the B+ tree"""
        if not LIBRARY_LOADED:
            return []
        try:
            buffer_size = max_results or max(1, per_page)
            out_ids = (c_int * buffer_size)()
            count = c_lib.wrapper_bplus_get_paginated(page, per_page, out_ids, buffer_size)
            return CHealthSync._collect_patients_from_ids(out_ids[i] for i in range(count))
        except Exception as e:
            print(f"[C Integration] Error getting paginated B+ patients: {e}")
            return []

    @staticmethod
    def splay_clear():
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_splay_clear()
            return True
        except Exception as e:
            print(f"[C Integration] Error clearing splay cache: {e}")
            return False

    @staticmethod
    def splay_insert_patient(patient_id):
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_splay_insert_patient(patient_id)
            return True
        except Exception as e:
            print(f"[C Integration] Error inserting splay patient: {e}")
            return False

    @staticmethod
    def splay_search_patient(patient_id):
        if not LIBRARY_LOADED:
            return None
        try:
            out_firstName = ctypes.create_string_buffer(100)
            out_lastName = ctypes.create_string_buffer(100)
            out_dob = ctypes.create_string_buffer(11)
            out_gender = ctypes.c_char()
            out_phone = ctypes.create_string_buffer(20)
            out_email = ctypes.create_string_buffer(100)
            out_address = ctypes.create_string_buffer(200)
            out_heartRate = c_int()
            out_bloodPressure = ctypes.create_string_buffer(16)
            out_temperature = c_float()
            out_oxygenSaturation = c_int()
            out_painLevel = c_int()
            out_chiefComplaint = ctypes.create_string_buffer(128)

            result = c_lib.wrapper_splay_search_patient(
                patient_id,
                out_firstName,
                out_lastName,
                out_dob,
                ctypes.byref(out_gender),
                out_phone,
                out_email,
                out_address,
                ctypes.byref(out_heartRate),
                out_bloodPressure,
                ctypes.byref(out_temperature),
                ctypes.byref(out_oxygenSaturation),
                ctypes.byref(out_painLevel),
                out_chiefComplaint,
            )

            if result == 1:
                return {
                    'id': patient_id,
                    'firstName': out_firstName.value.decode('utf-8'),
                    'lastName': out_lastName.value.decode('utf-8'),
                    'dob': out_dob.value.decode('utf-8'),
                    'gender': out_gender.value.decode('utf-8'),
                    'phone': out_phone.value.decode('utf-8'),
                    'email': out_email.value.decode('utf-8'),
                    'address': out_address.value.decode('utf-8'),
                    'heartRate': out_heartRate.value,
                    'bloodPressure': out_bloodPressure.value.decode('utf-8'),
                    'temperature': out_temperature.value,
                    'oxygenSaturation': out_oxygenSaturation.value,
                    'painLevel': out_painLevel.value,
                    'chiefComplaint': out_chiefComplaint.value.decode('utf-8'),
                }
            return None
        except Exception as e:
            print(f"[C Integration] Error searching splay cache: {e}")
            return None

    @staticmethod
    def leftist_init():
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_leftist_init()
            return True
        except Exception as e:
            print(f"[C Integration] Error initializing leftist heap: {e}")
            return False

    @staticmethod
    def leftist_insert(workload, staff_id):
        if not LIBRARY_LOADED:
            return False
        try:
            return c_lib.wrapper_leftist_insert(workload, staff_id) == 1
        except Exception as e:
            print(f"[C Integration] Error inserting leftist heap entry: {e}")
            return False

    @staticmethod
    def leftist_extract_min():
        if not LIBRARY_LOADED:
            return None, None
        try:
            out_staff_id = c_int()
            workload = c_lib.wrapper_leftist_extract_min(ctypes.byref(out_staff_id))
            if workload >= 0:
                return out_staff_id.value, workload
            return None, None
        except Exception as e:
            print(f"[C Integration] Error extracting leftist heap min: {e}")
            return None, None

    @staticmethod
    def leftist_clear():
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_leftist_clear()
            return True
        except Exception as e:
            print(f"[C Integration] Error clearing leftist heap: {e}")
            return False

    @staticmethod
    def pairing_init():
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_pairing_init()
            return True
        except Exception as e:
            print(f"[C Integration] Error initializing pairing heap: {e}")
            return False

    @staticmethod
    def pairing_insert(priority, appointment_id):
        if not LIBRARY_LOADED:
            return False
        try:
            return c_lib.wrapper_pairing_insert(priority, appointment_id) == 1
        except Exception as e:
            print(f"[C Integration] Error inserting pairing heap entry: {e}")
            return False

    @staticmethod
    def pairing_extract_min():
        if not LIBRARY_LOADED:
            return None, None
        try:
            out_appointment_id = c_int()
            priority = c_lib.wrapper_pairing_extract_min(ctypes.byref(out_appointment_id))
            if priority >= 0:
                return out_appointment_id.value, priority
            return None, None
        except Exception as e:
            print(f"[C Integration] Error extracting pairing heap min: {e}")
            return None, None

    @staticmethod
    def pairing_clear():
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_pairing_clear()
            return True
        except Exception as e:
            print(f"[C Integration] Error clearing pairing heap: {e}")
            return False

    @staticmethod
    def init_triage_queue():
        """Initialize the emergency triage queue (Binomial Heap)"""
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_init_triage_queue()
            print("[C Integration] Triage queue initialized (Binomial Heap)")
            return True
        except Exception as e:
            print(f"[C Integration] Error initializing triage queue: {e}")
            return False

    @staticmethod
    def queue_add_patient(priority, patient_id):
        """Add patient to emergency triage queue with priority"""
        if not LIBRARY_LOADED:
            return False
        try:
            result = c_lib.wrapper_queue_add_patient(priority, patient_id)
            if result == 0:
                print(f"[C Integration] Patient {patient_id} added to queue (priority: {priority})")
                return True
            return False
        except Exception as e:
            print(f"[C Integration] Error adding to queue: {e}")
            return False

    @staticmethod
    def queue_extract_next():
        """Extract next patient from triage queue (highest priority) - O(log n)"""
        if not LIBRARY_LOADED:
            return None, None

        try:
            out_patient_id = c_int()
            priority = c_lib.wrapper_queue_extract_next(ctypes.byref(out_patient_id))

            if priority >= 0:
                patient_id = out_patient_id.value
                print(f"[C Integration] Extracted patient {patient_id} from queue (priority: {priority})")
                return patient_id, priority
            return None, None
        except Exception as e:
            print(f"[C Integration] Error extracting from queue: {e}")
            return None, None

    @staticmethod
    def queue_get_size():
        """Get number of patients waiting in triage queue"""
        if not LIBRARY_LOADED:
            return 0
        try:
            size = c_lib.wrapper_queue_get_size()
            return size
        except Exception as e:
            print(f"[C Integration] Error getting queue size: {e}")
            return 0

    # ===== FIBONACCI HEAP METHODS (Phase 1) =====
    @staticmethod
    def fib_init_queue():
        """Initialize Fibonacci heap for real-time priority updates"""
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_fib_init_queue()
            print("[C Integration] Fibonacci heap initialized")
            return True
        except Exception as e:
            print(f"[C Integration] Error initializing Fibonacci heap: {e}")
            return False

    @staticmethod
    def fib_insert(priority, patient_id):
        """Insert patient into Fibonacci heap - O(1) amortized"""
        if not LIBRARY_LOADED:
            return False
        try:
            result = c_lib.wrapper_fib_insert(priority, patient_id)
            if result == 1:
                print(f"[C Integration] Patient {patient_id} inserted to Fib heap (priority: {priority})")
                return True
            return False
        except Exception as e:
            print(f"[C Integration] Error inserting to Fibonacci heap: {e}")
            return False

    @staticmethod
    def fib_extract_min():
        """Extract min patient from Fibonacci heap - O(log n) amortized"""
        if not LIBRARY_LOADED:
            return None
        try:
            patient_id = c_lib.wrapper_fib_extract_min()
            if patient_id > 0:
                print(f"[C Integration] Extracted patient {patient_id} from Fibonacci heap")
                return patient_id
            return None
        except Exception as e:
            print(f"[C Integration] Error extracting from Fibonacci heap: {e}")
            return None

    @staticmethod
    def fib_peek_min():
        """Peek at minimum without extracting - O(1)"""
        if not LIBRARY_LOADED:
            return None
        try:
            patient_id = c_lib.wrapper_fib_peek_min()
            return patient_id if patient_id > 0 else None
        except Exception as e:
            print(f"[C Integration] Error peeking Fibonacci heap: {e}")
            return None

    @staticmethod
    def fib_decrease_key(patient_id, new_priority):
        """Decrease priority (increase urgency) - O(1) amortized - CRITICAL FOR REAL-TIME"""
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_fib_decrease_key(patient_id, new_priority)
            print(f"[C Integration] Patient {patient_id} priority updated to {new_priority}")
            return True
        except Exception as e:
            print(f"[C Integration] Error decreasing Fibonacci heap key: {e}")
            return False

    @staticmethod
    def fib_queue_size():
        """Get Fibonacci heap queue size"""
        if not LIBRARY_LOADED:
            return 0
        try:
            size = c_lib.wrapper_fib_queue_size()
            return size
        except Exception as e:
            print(f"[C Integration] Error getting Fibonacci heap size: {e}")
            return 0

    @staticmethod
    def fib_clear_queue():
        """Clear and reinitialize Fibonacci queue"""
        if not LIBRARY_LOADED:
            return False
        try:
            c_lib.wrapper_fib_clear_queue()
            print("[C Integration] Fibonacci queue cleared")
            return True
        except Exception as e:
            print(f"[C Integration] Error clearing Fibonacci queue: {e}")
            return False
