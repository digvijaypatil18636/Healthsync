#ifndef MODULE5_SPATIAL_H
#define MODULE5_SPATIAL_H

#include <stdbool.h>

typedef struct Rect {
    float x1;
    float y1;
    float x2;
    float y2;
} Rect;

typedef struct RTreeEntry {
    Rect rect;
    int data_id;
    char label[64];
} RTreeEntry;

typedef struct RTree {
    RTreeEntry* entries;
    int count;
    int capacity;
} RTree;

typedef struct QPoint {
    float x;
    float y;
    int data_id;
} QPoint;

typedef struct QuadTree {
    Rect bounds;
    QPoint* points;
    int count;
    int capacity;
} QuadTree;

typedef struct IntervalNode {
    int low;
    int high;
    int max;
    int value;
    struct IntervalNode* left;
    struct IntervalNode* right;
} IntervalNode;

typedef struct SegmentTree {
    int n;
    int* tree;
    int* values;
} SegmentTree;

RTree* rtree_create();
void rtree_insert(RTree* tree, Rect rect, int data_id, const char* label);
int rtree_search(RTree* tree, Rect query, int* out_ids, int max_results);
int rtree_nearest(RTree* tree, float x, float y);
void rtree_free(RTree* tree);

QuadTree* qt_create(Rect bounds);
void qt_insert(QuadTree* tree, float x, float y, int data_id);
int qt_query_range(QuadTree* tree, Rect query, int* out_ids, int max_results);
void qt_free(QuadTree* tree);

IntervalNode* it_create();
IntervalNode* it_insert(IntervalNode* root, int low, int high, int value);
int it_overlap_query(IntervalNode* root, int low, int high);
void it_free(IntervalNode* root);

SegmentTree* st_build_segment(int* arr, int n);
void st_update(SegmentTree* tree, int index, int value);
int st_query(SegmentTree* tree, int left, int right);
void st_free_segment(SegmentTree* tree);

#endif
