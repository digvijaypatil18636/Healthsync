#ifndef PATIENT_H
#define PATIENT_H

#include "common.h"

typedef struct Patient {
    int id;
    char firstName[MAX_NAME_LEN];
    char lastName[MAX_NAME_LEN];
    char dob[MAX_DOB_LEN];
    char gender;            // 'M','F','O'
    char phone[MAX_PHONE_LEN];
    char email[MAX_EMAIL_LEN];
    char address[MAX_ADDRESS_LEN];

    /* triage/vitals information */
    int heartRate;
    char bloodPressure[16];   /* "SYS/DIA" */
    float temperature;
    int oxygenSaturation;
    int painLevel;            /* 0–10 */
    char chiefComplaint[128];
} Patient;

Patient* patient_create(int id, const char* firstName, const char* lastName,
                        const char* dob, char gender,
                        const char* phone, const char* email, const char* address);

/* set triage/vitals fields after creation */
void patient_set_triage(Patient* p,
                        int heartRate,
                        const char* bloodPressure,
                        float temperature,
                        int oxygenSaturation,
                        int painLevel,
                        const char* chiefComplaint);
void patient_free(Patient* p);
void patient_print(const Patient* p);
int patient_save(FILE* fp, const Patient* p);
Patient* patient_load(FILE* fp);

#endif