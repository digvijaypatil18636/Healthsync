#ifndef MODULE1_TREES_H
#define MODULE1_TREES_H

#include "patient.h"

// AVL Tree
typedef struct AVLNode {
    int key;
    Patient* data;
    struct AVLNode* left;
    struct AVLNode* right;
    int height;
} AVLNode;

AVLNode* avl_insert(AVLNode* root, int key, Patient* data);
AVLNode* avl_delete(AVLNode* root, int key);
Patient* avl_search(AVLNode* root, int key);
void avl_inorder(AVLNode* root);
void avl_print_tree(AVLNode* root, int space);
void avl_free(AVLNode* root);

// B+ Tree (order 4)
#define BPLUS_ORDER 4
#define MAX_KEYS (BPLUS_ORDER - 1)
#define MIN_KEYS (BPLUS_ORDER / 2 - 1)

typedef struct BPlusNode {
    int keys[MAX_KEYS + 1];
    struct BPlusNode* children[BPLUS_ORDER + 1];
    struct BPlusNode* next; // for leaf nodes
    Patient* data[MAX_KEYS + 1]; // for leaf nodes
    int num_keys;
    bool is_leaf;
} BPlusNode;

typedef struct BPlusTree {
    BPlusNode* root;
} BPlusTree;

BPlusTree* bplus_create();
void bplus_insert(BPlusTree* tree, int key, Patient* data);
Patient* bplus_search(BPlusTree* tree, int key);
void bplus_range_query(BPlusTree* tree, int low, int high);
void bplus_print(BPlusTree* tree);
void bplus_free(BPlusTree* tree);

// Huffman Tree
typedef struct HuffmanNode {
    char ch;
    int freq;
    struct HuffmanNode* left;
    struct HuffmanNode* right;
} HuffmanNode;

HuffmanNode* huffman_build(int* freq, int n);
void huffman_build_codes(HuffmanNode* node, char* code, int len, char* codes[256]);
char* huffman_encode(HuffmanNode* root, const char* text);
char* huffman_decode(HuffmanNode* root, const char* bits);
void huffman_free(HuffmanNode* root);

// Splay Tree
typedef struct SplayNode {
    int key;
    Patient* data;
    struct SplayNode* left;
    struct SplayNode* right;
} SplayNode;

SplayNode* splay_insert(SplayNode* root, int key, Patient* data);
SplayNode* splay_search(SplayNode* root, int key);
SplayNode* splay_delete(SplayNode* root, int key);
void splay_inorder(SplayNode* root);
void splay_free(SplayNode* root);

#endif
