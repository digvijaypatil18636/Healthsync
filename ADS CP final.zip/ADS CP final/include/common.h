#ifndef COMMON_H
#define COMMON_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <assert.h>
#include <time.h>
#include <limits.h>

#define MAX_NAME_LEN 100
#define MAX_DOB_LEN 11      // YYYY-MM-DD\0
#define MAX_PHONE_LEN 20
#define MAX_EMAIL_LEN 100
#define MAX_ADDRESS_LEN 200
#define OK 0
#define ERROR -1

#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))

#endif