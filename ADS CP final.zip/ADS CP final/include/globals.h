#ifndef GLOBALS_H
#define GLOBALS_H

#include "patient.h"
#include "module1_trees.h"
#include "module2_heaps.h"

// Patient database
extern Patient** g_patients;
extern int g_patient_count;
extern int g_patient_capacity;
extern int g_next_patient_id;

// Module 1
extern AVLNode* g_avl_root;
extern BPlusTree* g_bplus_tree;
extern HuffmanNode* g_huffman_tree;
extern SplayNode* g_splay_root;

// Module 2 (choose one active heap, e.g., Fibonacci)
extern FibHeap* g_fib_heap;
extern BinomialHeap* g_binom_heap;
extern LeftistHeap* g_leftist_heap;
extern PairingHeap* g_pairing_heap;

/* triage queue tracking (parallel to heap) */

typedef struct {
    int patient_id;
    int priority;
} TriageEntry;

extern TriageEntry* g_triage_entries;
extern int g_triage_count;
extern int g_triage_capacity;

#endif