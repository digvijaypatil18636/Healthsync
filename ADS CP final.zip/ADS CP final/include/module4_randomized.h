#ifndef MODULE4_RANDOMIZED_H
#define MODULE4_RANDOMIZED_H

#include <stdbool.h>

typedef struct TreapNode {
    int key;
    int priority;
    char value[64];
    struct TreapNode* left;
    struct TreapNode* right;
} TreapNode;

typedef struct SkipNode {
    int key;
    char value[64];
    struct SkipNode** forward;
    int level;
} SkipNode;

typedef struct SkipList {
    int level;
    int max_level;
    float probability;
    SkipNode* header;
} SkipList;

typedef struct BloomFilter {
    unsigned char* bits;
    int size;
    int hash_count;
} BloomFilter;

TreapNode* treap_insert(TreapNode* root, int key, int priority, const char* value);
TreapNode* treap_delete(TreapNode* root, int key);
void treap_split(TreapNode* root, int key, TreapNode** left, TreapNode** right);
TreapNode* treap_merge(TreapNode* left, TreapNode* right);
TreapNode* treap_search(TreapNode* root, int key);
void treap_free(TreapNode* root);

SkipList* skip_create(int max_level, float probability);
void skip_insert(SkipList* list, int key, const char* value);
SkipNode* skip_search(SkipList* list, int key);
void skip_delete(SkipList* list, int key);
void skip_free(SkipList* list);

BloomFilter* bloom_create(int size, int hash_count);
void bloom_add(BloomFilter* filter, const char* item);
bool bloom_check(BloomFilter* filter, const char* item);
void bloom_free(BloomFilter* filter);

#endif
