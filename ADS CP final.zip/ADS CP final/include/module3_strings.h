#ifndef MODULE3_STRINGS_H
#define MODULE3_STRINGS_H

#include <stdbool.h>

typedef struct TrieNode {
    bool is_end;
    char* word;
    struct TrieNode* children[128];
} TrieNode;

typedef struct SuffixArray {
    char* text;
    int length;
    int* suffixes;
} SuffixArray;

typedef struct SuffixTree {
    char* text;
} SuffixTree;

typedef struct BKNode BKNode;
typedef struct BKChild BKChild;

struct BKChild {
    int distance;
    BKNode* node;
    BKChild* next;
};

struct BKNode {
    char* word;
    BKChild* children;
};

TrieNode* trie_create();
void trie_insert(TrieNode* root, const char* word);
bool trie_search(TrieNode* root, const char* word);
bool trie_starts_with(TrieNode* root, const char* prefix);
int trie_get_suggestions(TrieNode* root, const char* prefix, char* out_buffer, int buffer_size, int max_suggestions);
void trie_free(TrieNode* root);

SuffixArray* sa_build(const char* text);
int sa_search(SuffixArray* sa, const char* pattern, int* out_indices, int max_results);
bool sa_contains(SuffixArray* sa, const char* pattern);
void sa_free(SuffixArray* sa);

SuffixTree* st_build(const char* text);
bool st_find_pattern(SuffixTree* tree, const char* pattern);
int st_find_common_patterns(SuffixTree* tree, char* out_buffer, int buffer_size, int min_length);
void st_free(SuffixTree* tree);

BKNode* bk_create(const char* word);
void bk_insert(BKNode** root, const char* word);
int bk_search(BKNode* root, const char* target, int max_distance, char* out_buffer, int buffer_size, int max_results);
void bk_free(BKNode* root);

#endif
