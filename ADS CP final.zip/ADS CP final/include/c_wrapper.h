#ifndef C_WRAPPER_H
#define C_WRAPPER_H

/* Initialize database */
void wrapper_init();

/* Add a new patient - returns patient ID */
int wrapper_add_patient(
    const char* firstName,
    const char* lastName,
    const char* dob,
    char gender,
    const char* phone,
    const char* email,
    const char* address,
    int heartRate,
    const char* bloodPressure,
    float temperature,
    int oxygenSaturation,
    int painLevel,
    const char* chiefComplaint
);

/* Get total patient count */
int wrapper_get_patient_count();

/* Get patient data by index (0-based) - returns 0 on success, -1 on error */
int wrapper_get_patient_by_index(
    int index,
    int* out_id,
    char* out_firstName,
    char* out_lastName,
    char* out_dob,
    char* out_gender,
    char* out_phone,
    char* out_email,
    char* out_address,
    int* out_heartRate,
    char* out_bloodPressure,
    float* out_temperature,
    int* out_oxygenSaturation,
    int* out_painLevel,
    char* out_chiefComplaint
);

/* Get patient data by ID - returns 1 if found, 0 if not found */
int wrapper_get_patient_by_id(
    int id,
    char* out_firstName,
    char* out_lastName,
    char* out_dob,
    char* out_gender,
    char* out_phone,
    char* out_email,
    char* out_address,
    int* out_heartRate,
    char* out_bloodPressure,
    float* out_temperature,
    int* out_oxygenSaturation,
    int* out_painLevel,
    char* out_chiefComplaint
);

/* Calculate triage priority (0-100) */
int wrapper_calculate_priority(
    int heartRate,
    const char* bloodPressure,
    float temperature,
    int oxygenSaturation,
    int painLevel,
    const char* chiefComplaint
);

/* Cleanup and free resources */
void wrapper_cleanup();

/* ===== HUFFMAN COMPRESSION ===== */
int wrapper_huffman_encode(
    const char* text,
    char* out_encoded,
    int encoded_buffer_size,
    char* out_codes,
    int codes_buffer_size
);
int wrapper_huffman_decode(
    const char* bits,
    const char* codes,
    char* out_decoded,
    int decoded_buffer_size
);

/* ===== B+ TREE - RANGE QUERIES & PAGINATION ===== */
/* Rebuild B+ tree from current patient database */
void wrapper_rebuild_bplus_tree();

/* Return patient IDs within inclusive range [min_id, max_id] */
int wrapper_bplus_range_query(int min_id, int max_id, int* out_ids, int max_results);

/* Return all patient IDs sorted by ID */
int wrapper_bplus_get_all_sorted(int* out_ids, int max_results);

/* Return a page of sorted patient IDs */
int wrapper_bplus_get_paginated(int page, int per_page, int* out_ids, int max_results);

/* ===== SPLAY TREE - FREQUENT ACCESS CACHE ===== */
void wrapper_splay_clear();
void wrapper_splay_insert_patient(int patient_id);
int wrapper_splay_search_patient(
    int patient_id,
    char* out_firstName,
    char* out_lastName,
    char* out_dob,
    char* out_gender,
    char* out_phone,
    char* out_email,
    char* out_address,
    int* out_heartRate,
    char* out_bloodPressure,
    float* out_temperature,
    int* out_oxygenSaturation,
    int* out_painLevel,
    char* out_chiefComplaint
);

/* ===== LEFTIST HEAP - STAFF WORKLOAD ===== */
void wrapper_leftist_init();
int wrapper_leftist_insert(int workload, int staff_id);
int wrapper_leftist_extract_min(int* out_staff_id);
void wrapper_leftist_clear();

/* ===== PAIRING HEAP - APPOINTMENT QUEUE ===== */
void wrapper_pairing_init();
int wrapper_pairing_insert(int priority, int appointment_id);
int wrapper_pairing_extract_min(int* out_appointment_id);
void wrapper_pairing_clear();

/* ===== FIBONACCI HEAP - REAL-TIME PRIORITY QUEUE ===== */
/* Initialize Fibonacci heap for emergency triage queue */
void wrapper_fib_init_queue();

/* Insert patient into Fibonacci heap with priority */
int wrapper_fib_insert(int priority, int patient_id);

/* Extract minimum priority patient (top of queue) - Returns patient_id */
int wrapper_fib_extract_min();

/* Peek at minimum without extracting - Returns patient_id */
int wrapper_fib_peek_min();

/* Decrease key (update priority) for a patient - Lower = higher priority */
void wrapper_fib_decrease_key(int patient_id, int new_priority);

/* Get current queue size */
int wrapper_fib_queue_size();

/* Clear Fibonacci queue */
void wrapper_fib_clear_queue();

#endif
