#ifndef MODULE6_MISC_H
#define MODULE6_MISC_H

#include <stdbool.h>

typedef struct PersistentRBNode {
    int key;
    char value[256];
    bool red;
    struct PersistentRBNode* left;
    struct PersistentRBNode* right;
} PersistentRBNode;

typedef struct PersistentRBTree {
    PersistentRBNode** versions;
    int version_count;
    int capacity;
} PersistentRBTree;

typedef struct DisjointSet {
    int size;
    int* parent;
    int* rank;
} DisjointSet;

typedef struct CHMEntry {
    char* key;
    char* value;
    struct CHMEntry* next;
} CHMEntry;

typedef struct ConcurrentHashMap {
    int bucket_count;
    CHMEntry** buckets;
} ConcurrentHashMap;

PersistentRBTree* pst_create();
PersistentRBNode* pst_insert(PersistentRBTree* tree, int key, const char* value);
const char* pst_search(PersistentRBNode* root, int key);
void pst_free(PersistentRBTree* tree);

DisjointSet* dsu_create(int size);
int dsu_find(DisjointSet* dsu, int x);
void dsu_union(DisjointSet* dsu, int a, int b);
void dsu_free(DisjointSet* dsu);

ConcurrentHashMap* chm_create(int bucket_count);
void chm_put(ConcurrentHashMap* map, const char* key, const char* value);
const char* chm_get(ConcurrentHashMap* map, const char* key);
void chm_remove(ConcurrentHashMap* map, const char* key);
void chm_free(ConcurrentHashMap* map);

#endif
