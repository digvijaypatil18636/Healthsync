#ifndef PATIENT_DB_H
#define PATIENT_DB_H

#include "patient.h"

// Global database variables
extern Patient** g_patients;
extern int g_patient_count;
extern int g_patient_capacity;
extern int g_next_patient_id;

void db_init();
int db_add_patient(Patient* p);
Patient* db_get_patient(int id);
Patient** db_get_all();
int db_get_count();
void db_free();

#endif