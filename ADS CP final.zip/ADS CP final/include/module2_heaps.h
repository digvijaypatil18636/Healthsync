#ifndef MODULE2_HEAPS_H
#define MODULE2_HEAPS_H

#include <stdbool.h>
typedef struct FibNode {
    int key;
    int patient_id;
    int degree;
    bool marked;
    struct FibNode* parent;
    struct FibNode* child;
    struct FibNode* left;
    struct FibNode* right;
} FibNode;

typedef struct FibHeap {
    FibNode* min;
    int n;
} FibHeap;

FibHeap* fib_create();
void fib_insert(FibHeap* heap, int priority, int patient_id);
int fib_extract_min(FibHeap* heap, int* out_patient_id);
void fib_decrease_key(FibHeap* heap, FibNode* node, int new_priority);
FibHeap* fib_merge(FibHeap* h1, FibHeap* h2);
void fib_free(FibHeap* heap);

// Binomial Heap
typedef struct BinomNode {
    int key;
    int patient_id;
    int degree;
    struct BinomNode* parent;
    struct BinomNode* child;
    struct BinomNode* sibling;
} BinomNode;

typedef struct BinomialHeap {
    BinomNode* head;
} BinomialHeap;

BinomialHeap* binom_create();
void binom_insert(BinomialHeap* heap, int priority, int patient_id);
int binom_extract_min(BinomialHeap* heap, int* out_patient_id);
BinomialHeap* binom_merge(BinomialHeap* h1, BinomialHeap* h2);
void binom_free(BinomialHeap* heap);

// Leftist Heap
typedef struct LeftistNode {
    int key;
    int patient_id;
    int dist;
    struct LeftistNode* left;
    struct LeftistNode* right;
} LeftistNode;

typedef struct LeftistHeap {
    LeftistNode* root;
} LeftistHeap;

LeftistHeap* leftist_create();
LeftistHeap* leftist_merge(LeftistHeap* h1, LeftistHeap* h2);
void leftist_insert(LeftistHeap** heap, int priority, int patient_id);
int leftist_extract_min(LeftistHeap** heap, int* out_patient_id);
void leftist_free(LeftistHeap* heap);

// Pairing Heap
typedef struct PairingNode {
    int key;
    int patient_id;
    struct PairingNode* child;
    struct PairingNode* next;
} PairingNode;

typedef struct PairingHeap {
    PairingNode* root;
} PairingHeap;

PairingHeap* pairing_create();
PairingHeap* pairing_merge(PairingHeap* h1, PairingHeap* h2);
void pairing_insert(PairingHeap** heap, int priority, int patient_id);
int pairing_extract_min(PairingHeap** heap, int* out_patient_id);
void pairing_decrease_key(PairingHeap** heap, PairingNode* node, int new_priority);
void pairing_free(PairingHeap* heap);

#endif