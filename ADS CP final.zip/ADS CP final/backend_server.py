from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import os
import sys
import heapq
from datetime import datetime, timedelta
from collections import Counter

# Import C integration
try:
    from c_integration import CHealthSync, LIBRARY_LOADED
    print("[Backend] C integration module loaded")
except (ImportError, RuntimeError) as e:
    print(f"[Backend] WARNING: Could not import C integration: {e}")
    LIBRARY_LOADED = False
    CHealthSync = None

app = Flask(__name__)
CORS(app)

DATA_FILE = 'patients_data.json'
QUEUE_FILE = 'queue_data.json'
STAFF_FILE = 'staff_data.json'
APPOINTMENTS_FILE = 'appointments_data.json'
TRIAGE_POOLS_FILE = 'triage_pools.json'
TRIALS_FILE = 'trials_data.json'
EQUIPMENT_FILE = 'equipment_data.json'
ROOM_SCHEDULE_FILE = 'room_schedule.json'
PATIENT_HISTORY_FILE = 'patient_history.json'

# Initialize data structures (with fallback)
USE_C_BACKEND = False
DEFER_C_SYNC = False
try:
    if LIBRARY_LOADED and CHealthSync:
        CHealthSync.initialize()
        print("[Backend] INITIALIZED: Using C backend with data structures")
        
        # Rebuild AVL tree for O(log n) patient lookups
        CHealthSync.rebuild_avl_tree()
        print("[Backend] AVL Tree: Loaded for fast patient searches O(log n)")

        # Rebuild B+ tree for sorted traversal and range queries
        CHealthSync.rebuild_bplus_tree()
        print("[Backend] B+ Tree: Loaded for range queries and pagination O(log n + k)")
        
        # Initialize Binomial Heap for emergency triage queue
        CHealthSync.init_triage_queue()
        print("[Backend] Binomial Heap: Loaded for emergency triage queue O(log n) extract")

        # Initialize auxiliary structures for later modules
        CHealthSync.leftist_init()
        CHealthSync.pairing_init()
        CHealthSync.splay_clear()
        
        USE_C_BACKEND = True
        DEFER_C_SYNC = True
        print("[Backend] READY: AVL/B+/Splay Trees + Heap structures ready for operations")
    else:
        print("[Backend] C library not available - using JSON-based storage")
        print("[Backend] Note: Data structures with O(log n) complexity NOT available")
        USE_C_BACKEND = False
except Exception as e:
    print(f"[Backend] Failed to initialize C backend: {e}")
    print("[Backend] Falling back to JSON storage")
    USE_C_BACKEND = False

DATA_FILE = 'patients_data.json'
QUEUE_FILE = 'queue_data.json'
STAFF_FILE = 'staff_data.json'
APPOINTMENTS_FILE = 'appointments_data.json'
TRIAGE_POOLS_FILE = 'triage_pools.json'
TRIALS_FILE = 'trials_data.json'
EQUIPMENT_FILE = 'equipment_data.json'
ROOM_SCHEDULE_FILE = 'room_schedule.json'
PATIENT_HISTORY_FILE = 'patient_history.json'

splay_cache_stats = {
    'hits': 0,
    'misses': 0,
    'access_counts': {},
    'recent_patient_ids': []
}

def load_patients():
    """Load patients from JSON file"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as f:
            return json.load(f)
    return []

def save_patients(patients):
    """Save patients to JSON file"""
    with open(DATA_FILE, 'w') as f:
        json.dump(patients, f, indent=2)

def load_queue():
    """Load emergency queue from JSON file"""
    if os.path.exists(QUEUE_FILE):
        with open(QUEUE_FILE, 'r') as f:
            return json.load(f)
    return []

def save_queue(queue):
    """Save emergency queue to JSON file"""
    with open(QUEUE_FILE, 'w') as f:
        json.dump(queue, f, indent=2)

def load_json_file(path, default):
    if os.path.exists(path):
        with open(path, 'r') as f:
            return json.load(f)
    return default

def save_json_file(path, payload):
    with open(path, 'w') as f:
        json.dump(payload, f, indent=2)

def load_staff():
    return load_json_file(STAFF_FILE, [])

def save_staff(staff):
    save_json_file(STAFF_FILE, staff)

def load_appointments():
    return load_json_file(APPOINTMENTS_FILE, [])

def save_appointments(appointments):
    save_json_file(APPOINTMENTS_FILE, appointments)

def load_triage_pools():
    return load_json_file(TRIAGE_POOLS_FILE, {'er': [], 'icu': [], 'field': []})

def save_triage_pools(pools):
    save_json_file(TRIAGE_POOLS_FILE, pools)

def load_trials():
    return load_json_file(TRIALS_FILE, [])

def save_trials(trials):
    save_json_file(TRIALS_FILE, trials)

def load_equipment():
    default_equipment = [
        {'id': 1, 'name': 'CT Scanner', 'type': 'imaging', 'x': 12, 'y': 6, 'room': 'Radiology-A'},
        {'id': 2, 'name': 'Ventilator', 'type': 'respiratory', 'x': 4, 'y': 15, 'room': 'ICU-2'},
        {'id': 3, 'name': 'Portable Ultrasound', 'type': 'imaging', 'x': 19, 'y': 10, 'room': 'ER-1'},
        {'id': 4, 'name': 'Defibrillator', 'type': 'critical-care', 'x': 7, 'y': 9, 'room': 'ER-3'},
        {'id': 5, 'name': 'Infusion Pump', 'type': 'general', 'x': 15, 'y': 17, 'room': 'Ward-B'}
    ]
    return load_json_file(EQUIPMENT_FILE, default_equipment)

def save_equipment(equipment):
    save_json_file(EQUIPMENT_FILE, equipment)

def load_room_schedule():
    return load_json_file(ROOM_SCHEDULE_FILE, [])

def save_room_schedule(schedule):
    save_json_file(ROOM_SCHEDULE_FILE, schedule)

def load_patient_history():
    return load_json_file(PATIENT_HISTORY_FILE, {})

def save_patient_history(history):
    save_json_file(PATIENT_HISTORY_FILE, history)

def levenshtein_distance(left, right):
    """Return Levenshtein edit distance between two strings."""
    left = (left or '').strip().lower()
    right = (right or '').strip().lower()
    if left == right:
        return 0
    if not left:
        return len(right)
    if not right:
        return len(left)

    prev = list(range(len(right) + 1))
    for i, left_char in enumerate(left, start=1):
        curr = [i]
        for j, right_char in enumerate(right, start=1):
            cost = 0 if left_char == right_char else 1
            curr.append(min(
                prev[j] + 1,
                curr[j - 1] + 1,
                prev[j - 1] + cost
            ))
        prev = curr
    return prev[-1]

def tokenize_text(value):
    """Normalize free text into searchable lowercase tokens."""
    if not value:
        return []
    normalized = ''.join(ch.lower() if ch.isalnum() else ' ' for ch in str(value))
    return [token for token in normalized.split() if len(token) >= 2]

def build_textsync_vocabulary(patients=None):
    """Aggregate the vocabulary used by TextSync features."""
    patients = patients if patients is not None else load_patients()
    vocabulary = set()
    for patient in patients:
        for field in (
            'firstName', 'lastName', 'conditions', 'allergies', 'medications',
            'chiefComplaint', 'symptoms', 'geneticConditions', 'address'
        ):
            vocabulary.update(tokenize_text(patient.get(field, '')))
    return sorted(vocabulary)

def build_patient_search_text(patient):
    """Create a single searchable text blob for a patient record."""
    parts = [
        patient.get('firstName', ''),
        patient.get('lastName', ''),
        patient.get('conditions', ''),
        patient.get('allergies', ''),
        patient.get('medications', ''),
        patient.get('chiefComplaint', ''),
        patient.get('symptoms', ''),
        patient.get('geneticConditions', ''),
        patient.get('address', '')
    ]
    return ' | '.join(str(part or '') for part in parts)

def detect_common_patterns(seed_text, patients=None, limit=8):
    """Find common symptom/complaint tokens related to the submitted phrase."""
    patients = patients if patients is not None else load_patients()
    seed_tokens = set(tokenize_text(seed_text))
    counts = Counter()

    for patient in patients:
        corpus_tokens = tokenize_text(' '.join([
            patient.get('symptoms', ''),
            patient.get('chiefComplaint', ''),
            patient.get('conditions', '')
        ]))
        if seed_tokens and not seed_tokens.intersection(corpus_tokens):
            continue
        counts.update(corpus_tokens)

    if not counts:
        counts.update(seed_tokens)

    return [
        {'pattern': token, 'frequency': freq}
        for token, freq in counts.most_common(limit)
    ]

def suggest_diseases_from_patterns(patterns):
    """Map common symptom tokens to likely disease suggestions."""
    rulebook = {
        'fever': ['Influenza', 'Dengue', 'COVID-19'],
        'cough': ['Influenza', 'COVID-19', 'Bronchitis'],
        'fatigue': ['Viral infection', 'Anemia', 'COVID-19'],
        'breathless': ['Asthma flare', 'Pneumonia'],
        'breathing': ['Asthma flare', 'Pneumonia'],
        'nausea': ['Gastroenteritis', 'Migraine'],
        'vomiting': ['Gastroenteritis', 'Food poisoning'],
        'chest': ['Cardiac event', 'Pneumonia'],
        'headache': ['Migraine', 'Viral fever']
    }
    disease_counter = Counter()
    for pattern in patterns:
        token = pattern.get('pattern', '')
        for disease in rulebook.get(token, []):
            disease_counter[disease] += int(pattern.get('frequency', 1))
    return [
        {'disease': disease, 'score': score}
        for disease, score in disease_counter.most_common(5)
    ]

def build_trial_cache_stats():
    """Return lightweight trial cache-style summary stats."""
    trials = load_trials()
    assignments = [assignment for trial in trials for assignment in trial.get('assignments', [])]
    treatment = sum(1 for item in assignments if item.get('group') == 'treatment')
    control = sum(1 for item in assignments if item.get('group') == 'control')
    return {
        'trialCount': len(trials),
        'assignmentCount': len(assignments),
        'treatmentCount': treatment,
        'controlCount': control,
        'hotTrials': sorted(
            [
                {
                    'id': trial['id'],
                    'name': trial.get('name', trial['id']),
                    'assignmentCount': len(trial.get('assignments', []))
                }
                for trial in trials
            ],
            key=lambda item: (-item['assignmentCount'], item['name'])
        )[:5],
        'source': 'TrialSync skip-list cache fallback'
    }

def simulate_trial_outcomes(trial_id, iterations=120):
    """Generate deterministic Monte Carlo style outcome samples for a trial."""
    trials = load_trials()
    trial = next((item for item in trials if str(item['id']) == str(trial_id)), None)
    assignment_count = len(trial.get('assignments', [])) if trial else 0
    base_rate = 0.48 + min(0.2, assignment_count / 100.0)
    samples = []
    for index in range(iterations):
        fluctuation = ((index * 17) % 9 - 4) / 100.0
        rate = max(0.2, min(0.95, base_rate + fluctuation))
        samples.append(round(rate, 2))
    buckets = {
        '0.20-0.39': sum(1 for value in samples if value < 0.40),
        '0.40-0.59': sum(1 for value in samples if 0.40 <= value < 0.60),
        '0.60-0.79': sum(1 for value in samples if 0.60 <= value < 0.80),
        '0.80-0.95': sum(1 for value in samples if value >= 0.80),
    }
    return {
        'trialId': trial_id,
        'iterations': iterations,
        'meanSuccessRate': round(sum(samples) / len(samples), 3),
        'minRate': min(samples),
        'maxRate': max(samples),
        'distribution': buckets,
        'source': 'TrialSync Monte Carlo simulation'
    }

def build_zone_heatmap():
    """Build a simple hospital zone density heatmap."""
    patients = load_patients()
    equipment = load_equipment()
    zone_template = {
        'North Wing': 0,
        'South Wing': 0,
        'East Wing': 0,
        'West Wing': 0
    }
    for patient in patients:
        zone = list(zone_template.keys())[patient['id'] % 4]
        zone_template[zone] += 1
    for asset in equipment:
        zone = list(zone_template.keys())[asset['id'] % 4]
        zone_template[zone] += 1
    return [
        {
            'zone': zone,
            'density': count,
            'severity': 'high' if count >= 60 else 'medium' if count >= 30 else 'low'
        }
        for zone, count in zone_template.items()
    ]

def build_occupancy_trends(days=7):
    """Build occupancy trend points for the last N days."""
    patients = load_patients()
    total_capacity = max(100, len(patients))
    points = []
    today = datetime.now().date()
    for offset in range(days):
        current = today - timedelta(days=(days - offset - 1))
        value = min(total_capacity, int(total_capacity * 0.45) + (offset * 7 + len(patients)) % 35)
        points.append({
            'label': current.isoformat(),
            'offset': offset,
            'occupiedBeds': value,
            'occupancyPercent': round((value / total_capacity) * 100, 1)
        })
    return points

def flatten_audit_log(patient_id=None):
    """Return version history as a flat audit log."""
    history = load_patient_history()
    items = []
    for key, versions in history.items():
        if patient_id is not None and str(patient_id) != str(key):
            continue
        for version in versions:
            items.append({
                'patientId': int(key),
                'version': version.get('version'),
                'timestamp': version.get('timestamp'),
                'actor': version.get('actor', 'system'),
                'action': version.get('action', 'updated')
            })
    items.sort(key=lambda item: item.get('timestamp', ''), reverse=True)
    return items

def simulate_concurrent_access(patient_id):
    """Generate a safe concurrent-access style activity log."""
    participants = ['Dr. Mehta', 'Dr. Rao', 'Nurse Iyer', 'Dr. Kulkarni']
    actions = [
        'updated medication list',
        'added triage note',
        'reviewed vitals',
        'confirmed allergy status'
    ]
    base_time = datetime.now()
    events = []
    for index in range(4):
        events.append({
            'patientId': patient_id,
            'session': f'SESSION-{index + 1}',
            'user': participants[index],
            'action': actions[index],
            'timestamp': (base_time).isoformat(),
            'status': 'committed'
        })
        base_time = base_time.replace(microsecond=(base_time.microsecond + 150000) % 1000000)
    return events

def get_trial_template(trial_id):
    """Return an existing trial or create a default template."""
    trials = load_trials()
    existing = next((trial for trial in trials if trial['id'] == trial_id), None)
    if existing:
        return existing, trials

    template = {
        'id': trial_id,
        'name': f'Trial-{trial_id}',
        'status': 'active',
        'created_at': datetime.now().isoformat(),
        'assignments': []
    }
    trials.append(template)
    return template, trials

def record_patient_version(patient_id, snapshot, action, actor='system'):
    """Append a new immutable patient version for HistorySync timelines."""
    history = load_patient_history()
    key = str(patient_id)
    versions = history.get(key, [])
    versions.append({
        'version': len(versions) + 1,
        'timestamp': datetime.now().isoformat(),
        'action': action,
        'actor': actor,
        'snapshot': snapshot
    })
    history[key] = versions
    save_patient_history(history)

def seed_patient_history_if_missing():
    """Ensure every existing patient has at least one baseline history entry."""
    patients = load_patients()
    history = load_patient_history()
    updated = False
    for patient in patients:
        key = str(patient['id'])
        if key not in history:
            history[key] = [{
                'version': 1,
                'timestamp': datetime.now().isoformat(),
                'action': 'seed',
                'actor': 'bootstrap',
                'snapshot': patient
            }]
            updated = True
    if updated:
        save_patient_history(history)

def room_booking_overlaps(existing, room_id, start_at, end_at):
    """Check interval overlap for room bookings."""
    for booking in existing:
        if booking.get('roomId') != room_id:
            continue
        if booking.get('status', 'scheduled') == 'cancelled':
            continue
        other_start = booking.get('start')
        other_end = booking.get('end')
        if other_start < end_at and start_at < other_end:
            return booking
    return None

def build_outbreak_clusters(patients=None):
    """Group patients into disease clusters using shared condition tokens."""
    patients = patients if patients is not None else load_patients()
    token_to_patients = {}
    for patient in patients:
        disease_tokens = set(tokenize_text(' '.join([
            patient.get('conditions', ''),
            patient.get('geneticConditions', ''),
            patient.get('symptoms', '')
        ])))
        for token in disease_tokens:
            token_to_patients.setdefault(token, set()).add(patient['id'])

    clusters = []
    seen_ids = set()
    for token, patient_ids in sorted(token_to_patients.items(), key=lambda item: (-len(item[1]), item[0])):
        if len(patient_ids) < 2:
            continue
        if patient_ids.issubset(seen_ids):
            continue
        members = [patient for patient in patients if patient['id'] in patient_ids]
        clusters.append({
            'label': token,
            'size': len(members),
            'patientIds': sorted(patient_ids),
            'patients': [
                {
                    'id': patient['id'],
                    'name': f"{patient.get('firstName', '')} {patient.get('lastName', '')}".strip(),
                    'conditions': patient.get('conditions', ''),
                    'symptoms': patient.get('symptoms', '')
                }
                for patient in members
            ]
        })
        seen_ids.update(patient_ids)
    return clusters

def get_next_id():
    """Get the next patient ID"""
    patients = load_patients()
    if not patients:
        return 1
    return max(p['id'] for p in patients) + 1

def rebuild_c_indexes():
    """Best-effort rebuild of C-side indexes after patient mutations."""
    if not (USE_C_BACKEND and CHealthSync):
        return
    try:
        CHealthSync.rebuild_avl_tree()
        CHealthSync.rebuild_bplus_tree()
    except Exception as e:
        print(f"[Backend] Failed to rebuild C indexes: {e}")

def sync_c_backend_from_json():
    """Fully rebuild the C-side state from the JSON source of truth."""
    if not (USE_C_BACKEND and CHealthSync):
        return False

    try:
        patients = sorted(load_patients(), key=lambda patient: patient.get('id', 0))
        queue = load_queue()
        staff = load_staff()
        appointments = load_appointments()

        CHealthSync.cleanup()
        CHealthSync.initialize()

        for patient in patients:
            CHealthSync.add_patient(
                patient.get('firstName', ''),
                patient.get('lastName', ''),
                patient.get('dob', ''),
                (patient.get('gender') or 'M')[0],
                patient.get('phone', ''),
                patient.get('email', ''),
                patient.get('address', ''),
                int(patient.get('heartRate') or 0),
                patient.get('bloodPressure', '') or '',
                float(patient.get('temperature') or 0),
                int(patient.get('oxygenSaturation') or 0),
                int(patient.get('painLevel') or 0),
                patient.get('chiefComplaint', '') or ''
            )

        CHealthSync.rebuild_avl_tree()
        CHealthSync.rebuild_bplus_tree()
        CHealthSync.init_triage_queue()
        CHealthSync.fib_init_queue()
        CHealthSync.leftist_init()
        CHealthSync.pairing_init()
        CHealthSync.splay_clear()

        for item in queue:
            patient_id = item.get('patientId', item.get('patient_id'))
            priority = int(item.get('priority', 0))
            if patient_id:
                CHealthSync.queue_add_patient(priority, int(patient_id))
                CHealthSync.fib_insert(priority, int(patient_id))

        for member in staff:
            CHealthSync.leftist_insert(int(member.get('current_workload', 0)), int(member['id']))

        for appointment in appointments:
            CHealthSync.pairing_insert(100 - int(appointment.get('priority', 0)), int(appointment['id']))

        print(f"[Backend] Synced C backend from JSON: {len(patients)} patients")
        return True
    except Exception as e:
        print(f"[Backend] Failed to sync C backend from JSON: {e}")
        return False

if DEFER_C_SYNC and USE_C_BACKEND:
    sync_c_backend_from_json()

seed_patient_history_if_missing()

def calculate_age(dob):
    """Calculate age from YYYY-MM-DD date of birth."""
    if not dob:
        return None
    try:
        birth_date = datetime.strptime(dob, "%Y-%m-%d").date()
        today = datetime.now().date()
        return today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
    except ValueError:
        return None

def enrich_patient(patient):
    """Return a copy of the patient with derived fields used by Phase 2 APIs/UI."""
    enriched = dict(patient)
    enriched['age'] = calculate_age(patient.get('dob'))
    return enriched

def get_sorted_patients():
    """Return all patients sorted by patient ID."""
    patients = load_patients()
    patients.sort(key=lambda p: p.get('id', 0))
    return patients

def get_bplus_directory_patients():
    """Return sorted patients from the C B+ tree when available, else Python sorting."""
    if USE_C_BACKEND and CHealthSync:
        c_patients = CHealthSync.bplus_get_all_sorted()
        if c_patients:
            return [enrich_patient(patient) for patient in c_patients], 'C backend', 'B+ Tree'
    return [enrich_patient(patient) for patient in get_sorted_patients()], 'Python fallback', 'Python sorted list'

def paginate_items(items, page, per_page):
    total = len(items)
    total_pages = max(1, (total + per_page - 1) // per_page) if per_page > 0 else 1
    start = (page - 1) * per_page
    end = start + per_page
    return {
        'items': items[start:end],
        'page': page,
        'per_page': per_page,
        'total': total,
        'total_pages': total_pages,
        'has_prev': page > 1,
        'has_next': page < total_pages
    }

def record_splay_access(patient_id):
    counts = splay_cache_stats['access_counts']
    key = str(patient_id)
    counts[key] = counts.get(key, 0) + 1

    recent = splay_cache_stats['recent_patient_ids']
    if patient_id in recent:
        recent.remove(patient_id)
    recent.insert(0, patient_id)
    del recent[10:]

def build_huffman_codebook(text):
    if not text:
        return {}

    frequencies = Counter(text)
    heap = [[freq, idx, char] for idx, (char, freq) in enumerate(frequencies.items())]
    heapq.heapify(heap)

    if len(heap) == 1:
        char = heap[0][2]
        return {char: '0'}

    next_idx = len(heap)
    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        heapq.heappush(heap, [left[0] + right[0], next_idx, [left, right]])
        next_idx += 1

    codes = {}

    def walk(node, prefix):
        value = node[2]
        if isinstance(value, str):
            codes[value] = prefix or '0'
            return
        walk(value[0], prefix + '0')
        walk(value[1], prefix + '1')

    walk(heap[0], '')
    return codes

def huffman_encode_text(text, include_source=False):
    if LIBRARY_LOADED and CHealthSync:
        c_result = CHealthSync.huffman_encode_text(text)
        if c_result is not None:
            if include_source:
                encoded, codes = c_result
                return encoded, codes, 'C backend', 'Huffman Tree'
            return c_result

    codes = build_huffman_codebook(text)
    encoded = ''.join(codes[ch] for ch in text) if text else ''
    if include_source:
        return encoded, codes, 'Python fallback', 'Huffman Tree'
    return encoded, codes

def huffman_decode_text(bits, codes, include_source=False):
    if LIBRARY_LOADED and CHealthSync:
        c_result = CHealthSync.huffman_decode_text(bits, codes)
        if c_result is not None:
            if include_source:
                return c_result, 'C backend', 'Huffman Tree'
            return c_result

    reverse = {value: key for key, value in codes.items()}
    decoded = []
    buffer = ''
    for bit in bits:
        buffer += bit
        if buffer in reverse:
            decoded.append(reverse[buffer])
            buffer = ''
    if buffer:
        raise ValueError('Encoded data does not match supplied codebook')
    decoded_text = ''.join(decoded)
    if include_source:
        return decoded_text, 'Python fallback', 'Huffman Tree'
    return decoded_text

def get_next_resource_id(items):
    if not items:
        return 1
    return max(item.get('id', 0) for item in items) + 1

def calculate_appointment_priority(appointment):
    if appointment.get('priority') is not None:
        return int(appointment['priority'])

    base = 50
    reason = (appointment.get('reason') or '').lower()
    if any(keyword in reason for keyword in ['follow-up', 'routine', 'checkup']):
        base = 25
    if any(keyword in reason for keyword in ['urgent', 'pain', 'review']):
        base = 60
    if any(keyword in reason for keyword in ['critical', 'post-op']):
        base = 75
    return base

def sync_family_relationships(patient_id, updated_data, all_patients):
    """Automatically sync bidirectional family relationships"""
    patient = next((p for p in all_patients if p['id'] == patient_id), None)
    if not patient:
        return
    
    # Initialize family relationship fields if not present
    for field in ['fatherId', 'motherId', 'spouseId', 'siblingIds', 'childrenIds']:
        if field not in patient:
            patient[field] = [] if field in ['siblingIds', 'childrenIds'] else None
    
    # Handle Father relationship
    if 'fatherId' in updated_data and updated_data['fatherId']:
        father_id = updated_data['fatherId']
        father = next((p for p in all_patients if p['id'] == father_id), None)
        if father:
            if 'childrenIds' not in father:
                father['childrenIds'] = []
            if patient_id not in father['childrenIds']:
                father['childrenIds'].append(patient_id)
    
    # Handle Mother relationship
    if 'motherId' in updated_data and updated_data['motherId']:
        mother_id = updated_data['motherId']
        mother = next((p for p in all_patients if p['id'] == mother_id), None)
        if mother:
            if 'childrenIds' not in mother:
                mother['childrenIds'] = []
            if patient_id not in mother['childrenIds']:
                mother['childrenIds'].append(patient_id)
    
    # Handle Spouse relationship
    if 'spouseId' in updated_data and updated_data['spouseId']:
        spouse_id = updated_data['spouseId']
        spouse = next((p for p in all_patients if p['id'] == spouse_id), None)
        if spouse:
            if 'spouseId' not in spouse:
                spouse['spouseId'] = None
            spouse['spouseId'] = patient_id
    
    # Handle Sibling relationships
    if 'siblingIds' in updated_data and updated_data['siblingIds']:
        for sibling_id in updated_data['siblingIds']:
            sibling = next((p for p in all_patients if p['id'] == sibling_id), None)
            if sibling:
                if 'siblingIds' not in sibling:
                    sibling['siblingIds'] = []
                if patient_id not in sibling['siblingIds']:
                    sibling['siblingIds'].append(patient_id)
    
    # Handle Children relationships
    if 'childrenIds' in updated_data and updated_data['childrenIds']:
        for child_id in updated_data['childrenIds']:
            child = next((p for p in all_patients if p['id'] == child_id), None)
            if child:
                if 'fatherId' not in child:
                    child['fatherId'] = None
                if child.get('gender') == 'Male' or not child.get('fatherId'):
                    child['fatherId'] = patient_id
                else:
                    if 'motherId' not in child:
                        child['motherId'] = None
                    child['motherId'] = patient_id

def calculate_triage_priority(patient):
    """Calculate emergency triage priority (0-100) based on vitals
    Uses C implementation if available, falls back to Python
    """
    
    # Try C function first
    if USE_C_BACKEND and CHealthSync:
        try:
            heart_rate = patient.get('heartRate', 0) or 0
            blood_pressure = patient.get('bloodPressure', '') or ''
            temperature = float(patient.get('temperature', 0) or 0)
            oxygen_sat = patient.get('oxygenSaturation', 0) or 0
            pain_level = patient.get('painLevel', 0) or 0
            complaint = patient.get('chiefComplaint', '') or ''
            
            priority = CHealthSync.calculate_priority(
                heart_rate, blood_pressure, temperature, 
                oxygen_sat, pain_level, complaint
            )
            
            if priority is not None:
                print(f"[Triage] Using C function - Priority: {priority}")
                return priority
        except Exception as e:
            print(f"[Triage] C function failed: {e}, falling back to Python")
    
    # Python fallback implementation
    priority = 0
    
    if patient.get('heartRate'):
        hr = patient['heartRate']
        deviation = abs(hr - 80)
        priority += min((deviation / 40) * 20, 20)
    
    if patient.get('bloodPressure'):
        try:
            bp_parts = str(patient['bloodPressure']).split('/')
            systolic = int(bp_parts[0])
            deviation = abs(systolic - 120)
            priority += min((deviation / 100) * 20, 20)
        except:
            pass
    
    if patient.get('oxygenSaturation'):
        o2 = patient['oxygenSaturation']
        if o2 < 95:
            priority += (95 - o2) * 1.5
    
    if patient.get('temperature'):
        temp = float(patient['temperature'])
        temp_dev = abs(temp - 37)
        priority += min(temp_dev * 10, 10)
    
    if patient.get('painLevel'):
        pain = int(patient['painLevel'])
        priority += (pain / 10) * 30
    
    complaint_severity = {
        'chest pain': 15, 'stroke': 15, 'severe bleeding': 15,
        'difficulty breathing': 12, 'head injury': 12,
        'fracture': 10, 'burn': 10, 'severe pain': 8,
        'unconscious': 8, 'moderate pain': 5, 'fever': 5,
        'nausea': 2, 'mild pain': 2
    }
    
    complaint = (patient.get('chiefComplaint') or '').lower()
    for key, value in complaint_severity.items():
        if key in complaint:
            priority += value
            break
    
    print(f"[Triage] Using Python fallback - Priority: {min(int(priority), 100)}")
    return min(int(priority), 100)

@app.route('/api/patients', methods=['GET'])
def get_patients():
    """Get all patients"""
    patients = load_patients()
    return jsonify(patients)

@app.route('/api/patients', methods=['POST'])
def add_patient():
    """Add a new patient - Integrates with AVL Tree and Triage Queue if available"""
    try:
        data = request.get_json()
        print("DEBUG: received POST /api/patients", data)
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['firstName', 'lastName', 'dob', 'gender']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        patients = load_patients()
        
        # Initialize new patient with required fields
        new_patient = {
            'id': get_next_id(),
            **data,
            'doctorName': data.get('doctorName', ''),
            'doctorId': data.get('doctorId', None),
            'fatherId': data.get('fatherId'),
            'motherId': data.get('motherId'),
            'spouseId': data.get('spouseId'),
            'siblingIds': data.get('siblingIds', []),
            'childrenIds': data.get('childrenIds', []),
            'status': data.get('status', 'waiting'),  # Default status
            'admission_date': data.get('admission_date', datetime.now().isoformat()),
            'discharge_date': data.get('discharge_date', None),
            'vitals_history': [{
                'timestamp': datetime.now().isoformat(),
                'heartRate': data.get('heartRate'),
                'bloodPressure': data.get('bloodPressure'),
                'temperature': data.get('temperature'),
                'oxygenSaturation': data.get('oxygenSaturation'),
                'painLevel': data.get('painLevel')
            }]
        }
        
        patients.append(new_patient)
        
        # Sync bidirectional relationships
        sync_family_relationships(new_patient['id'], new_patient, patients)
        
        save_patients(patients)
        record_patient_version(new_patient['id'], new_patient, 'created')
        
        # Update data structures (if available)
        priority = calculate_triage_priority(new_patient)
        
        # Try to use C backend for optimized operations
        if USE_C_BACKEND and CHealthSync:
            try:
                print(f"[Backend] Rebuilding C backend with patient ID {new_patient['id']}")
                sync_c_backend_from_json()
                
                # Add to emergency triage queue
                CHealthSync.queue_add_patient(priority, new_patient['id'])
                print(f"[Backend] Patient {new_patient['id']} added to Binomial Heap triage queue (priority: {priority})")
                
                return jsonify({
                    'id': new_patient['id'],
                    'priority': priority,
                    'backend': 'C (AVL Tree + Binomial Heap)',
                    'status': 'success',
                    'message': 'Patient added with optimized data structures'
                }), 201
            except Exception as e:
                print(f"[Backend] C backend failed, falling back: {e}")
        
        # Fallback: Just save to JSON with priority
        print(f"[Backend] Using JSON storage (no C backend)")
        return jsonify({
            'id': new_patient['id'],
            'priority': priority,
            'backend': 'JSON (fallback)',
            'status': 'success',
            'message': 'Patient added successfully'
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/<int:patient_id>', methods=['GET'])
def get_patient(patient_id):
    """Get a specific patient by ID
    Uses AVL Tree (O(log n)) if C backend available, otherwise O(n) JSON search
    """
    # Try C backend first (O(log n))
    if USE_C_BACKEND and CHealthSync:
        patient = CHealthSync.avl_search_patient(patient_id)
        if patient:
            return jsonify(patient)
    
    # Fallback to JSON search (O(n))
    patients = load_patients()
    patient = next((p for p in patients if p['id'] == patient_id), None)
    
    if not patient:
        return jsonify({'error': 'Patient not found'}), 404
    
    return jsonify(patient)

@app.route('/api/patients/<int:patient_id>', methods=['PUT'])
def update_patient(patient_id):
    """Update a patient"""
    try:
        data = request.get_json()
        patients = load_patients()
        
        patient_index = next((i for i, p in enumerate(patients) if p['id'] == patient_id), None)
        if patient_index is None:
            return jsonify({'error': 'Patient not found'}), 404
        
        # Update patient data
        patients[patient_index].update(data)
        
        # Sync bidirectional relationships
        sync_family_relationships(patient_id, data, patients)
        
        save_patients(patients)
        record_patient_version(patient_id, patients[patient_index], 'updated')
        sync_c_backend_from_json()
        
        return jsonify({
            'status': 'success',
            'message': 'Patient updated successfully',
            'patient': patients[patient_index]
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/<int:patient_id>', methods=['DELETE'])
def delete_patient(patient_id):
    """Delete a patient"""
    try:
        patients = load_patients()
        target_patient = next((p for p in patients if p['id'] == patient_id), None)
        patients = [p for p in patients if p['id'] != patient_id]
        save_patients(patients)
        if target_patient:
            record_patient_version(patient_id, target_patient, 'deleted')
        sync_c_backend_from_json()
        
        return jsonify({
            'status': 'success',
            'message': 'Patient deleted successfully'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/queue', methods=['GET'])
def get_queue():
    """Get emergency queue"""
    queue = load_queue()
    return jsonify(queue)

@app.route('/api/queue', methods=['POST'])
def add_to_queue():
    """Add patient to emergency queue with auto-calculated priority"""
    try:
        data = request.get_json()
        patient_id = data.get('patientId')
        queue_name = (data.get('queueName') or 'er').lower()
        
        if not patient_id:
            return jsonify({'error': 'patientId required'}), 400

        if queue_name not in {'er', 'icu', 'field'}:
            return jsonify({'error': 'queueName must be one of er, icu, field'}), 400
        
        patients = load_patients()
        patient = next((p for p in patients if p['id'] == int(patient_id)), None)
        
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404
        
        priority = calculate_triage_priority(patient)
        queue = load_queue()
        
        new_entry = {
            'patientId': int(patient_id),
            'queueName': queue_name,
            'priority': priority,
            'complaint': data.get('complaint', patient.get('chiefComplaint', '')),
            'timestamp': datetime.now().isoformat(),
            'vitals': {
                'hr': patient.get('heartRate', 0),
                'bp': patient.get('bloodPressure', ''),
                'temp': patient.get('temperature', 0),
                'o2': patient.get('oxygenSaturation', 0)
            }
        }
        
        queue.append(new_entry)
        save_queue(queue)

        pools = load_triage_pools()
        pools[queue_name].append({
            'patient_id': int(patient_id),
            'priority': priority,
            'timestamp': new_entry['timestamp']
        })
        save_triage_pools(pools)

        sync_c_backend_from_json()
        
        return jsonify({
            'status': 'success',
            'message': f'Added to triage queue with priority {priority}',
            'priority': priority,
            'queueName': queue_name
        }), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Comment out old endpoint - using new emergency-queue endpoints instead
# @app.route('/api/queue/<int:patient_id>', methods=['DELETE'])
# def remove_from_queue(patient_id):
#     """Remove patient from queue"""
#     try:
#         queue = load_queue()
#         queue = [q for q in queue if q['patientId'] != patient_id]
#         save_queue(queue)
#         
#         return jsonify({
#             'status': 'success',
#             'message': 'Removed from queue'
#         })
#     
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get backend statistics"""
    patients = load_patients()
    queue = load_queue()
    
    return jsonify({
        'total_patients': len(patients),
        'queue_size': len(queue),
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/patients/<int:patient_id>/family', methods=['GET'])
def get_family(patient_id):
    """Get family relationships for a patient"""
    try:
        patients = load_patients()
        patient = next((p for p in patients if p['id'] == patient_id), None)
        
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404
        
        family = {
            'self': patient,
            'mother': None,
            'father': None,
            'spouse': None,
            'children': []
        }
        
        if patient.get('motherId'):
            family['mother'] = next((p for p in patients if p['id'] == patient['motherId']), None)
        
        if patient.get('fatherId'):
            family['father'] = next((p for p in patients if p['id'] == patient['fatherId']), None)
        
        if patient.get('spouseId'):
            family['spouse'] = next((p for p in patients if p['id'] == patient['spouseId']), None)
        
        if patient.get('childrenIds'):
            for child_id in patient['childrenIds']:
                child = next((p for p in patients if p['id'] == child_id), None)
                if child:
                    family['children'].append(child)
        
        return jsonify(family)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/queue/next', methods=['GET'])
def get_next_in_queue():
    """Get the next patient to be seen (highest priority)"""
    try:
        queue = load_queue()
        
        if not queue:
            return jsonify({'message': 'Queue is empty'}), 200
        
        queue.sort(key=lambda x: x['priority'], reverse=True)
        
        if queue:
            next_patient = queue[0]
            return jsonify({
                'patientId': next_patient['patientId'],
                'priority': next_patient['priority'],
                'complaint': next_patient['complaint'],
                'position': 1
            })
        
        return jsonify({'message': 'Queue is empty'}), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/queue/stats', methods=['GET'])
def get_queue_stats():
    """Get queue statistics"""
    try:
        queue = load_queue()
        
        if not queue:
            return jsonify({
                'total_waiting': 0,
                'critical_count': 0,
                'urgent_count': 0,
                'stable_count': 0
            })
        
        critical = sum(1 for q in queue if q.get('priority', 0) >= 80)
        urgent = sum(1 for q in queue if 60 <= q.get('priority', 0) < 80)
        stable = sum(1 for q in queue if q.get('priority', 0) < 60)
        
        return jsonify({
            'total_waiting': len(queue),
            'critical_count': critical,
            'urgent_count': urgent,
            'stable_count': stable
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/search', methods=['GET'])
def search_patients():
    """Search patients by name"""
    try:
        query = request.args.get('name', '').lower()
        
        if not query:
            return jsonify({'error': 'Search query required'}), 400
        
        patients = load_patients()
        results = [
            p for p in patients 
            if query in f"{p['firstName']} {p['lastName']}".lower()
        ]
        
        return jsonify(results)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# Module 1 Extras - Huffman Compression and Splay Cache
# ============================================================================

@app.route('/api/compression/encode', methods=['POST'])
def encode_text():
    try:
        data = request.get_json() or {}
        text = data.get('text', '')
        encoded, codes, backend, data_structure = huffman_encode_text(text, include_source=True)
        return jsonify({
            'original': text,
            'encoded': encoded,
            'codes': codes,
            'original_length': len(text),
            'encoded_length': len(encoded),
            'backend': backend,
            'data_structure': data_structure
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/compression/decode', methods=['POST'])
def decode_text():
    try:
        data = request.get_json() or {}
        bits = data.get('encoded', '')
        codes = data.get('codes', {})
        decoded, backend, data_structure = huffman_decode_text(bits, codes, include_source=True)
        return jsonify({
            'decoded': decoded,
            'encoded_length': len(bits),
            'decoded_length': len(decoded),
            'backend': backend,
            'data_structure': data_structure
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/<int:patient_id>/genetic-data', methods=['POST'])
def store_genetic_data(patient_id):
    try:
        data = request.get_json() or {}
        sequence = data.get('genetic_sequence', '')
        notes = data.get('notes', '')
        payload = sequence or notes

        patients = load_patients()
        patient = next((p for p in patients if p['id'] == patient_id), None)
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404

        encoded, codes, backend, data_structure = huffman_encode_text(payload, include_source=True)
        patient['geneticData'] = {
            'sequence': sequence,
            'notes': notes,
            'encoded': encoded,
            'codes': codes,
            'stored_at': datetime.now().isoformat(),
            'compression_ratio': round((len(encoded) / max(len(payload) * 8, 1)), 4)
        }
        save_patients(patients)
        sync_c_backend_from_json()
        return jsonify({
            'status': 'success',
            'patient_id': patient_id,
            'compression': patient['geneticData'],
            'backend': backend,
            'data_structure': data_structure
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/<int:patient_id>/genetic-data', methods=['GET'])
def get_genetic_data(patient_id):
    try:
        patients = load_patients()
        patient = next((p for p in patients if p['id'] == patient_id), None)
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404

        genetic = patient.get('geneticData')
        if not genetic:
            return jsonify({'error': 'Genetic data not found'}), 404

        decoded, backend, data_structure = huffman_decode_text(genetic.get('encoded', ''), genetic.get('codes', {}), include_source=True)
        return jsonify({
            'patient_id': patient_id,
            'genetic_data': genetic,
            'decoded_payload': decoded,
            'backend': backend,
            'data_structure': data_structure
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/<int:patient_id>/cached', methods=['GET'])
def get_patient_cached(patient_id):
    try:
        if USE_C_BACKEND and CHealthSync:
            cached = CHealthSync.splay_search_patient(patient_id)
            if cached:
                splay_cache_stats['hits'] += 1
                record_splay_access(patient_id)
                return jsonify({
                    'patient': cached,
                    'cache': 'C splay tree',
                    'cache_hit': True
                }), 200

        patients = load_patients()
        patient = next((p for p in patients if p['id'] == patient_id), None)
        if not patient:
            splay_cache_stats['misses'] += 1
            return jsonify({'error': 'Patient not found'}), 404

        if USE_C_BACKEND and CHealthSync:
            CHealthSync.splay_insert_patient(patient_id)

        splay_cache_stats['misses'] += 1
        record_splay_access(patient_id)
        return jsonify({
            'patient': patient,
            'cache': 'JSON fallback',
            'cache_hit': False
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/cache/stats', methods=['GET'])
def get_cache_stats():
    total = splay_cache_stats['hits'] + splay_cache_stats['misses']
    access_counts = splay_cache_stats['access_counts']
    hottest = sorted(access_counts.items(), key=lambda item: item[1], reverse=True)[:5]
    return jsonify({
        'hits': splay_cache_stats['hits'],
        'misses': splay_cache_stats['misses'],
        'hit_rate': round(splay_cache_stats['hits'] / total, 4) if total else 0,
        'recent_patient_ids': splay_cache_stats['recent_patient_ids'],
        'most_accessed': [{'patient_id': int(pid), 'accesses': count} for pid, count in hottest],
        'backend': 'C backend' if USE_C_BACKEND and CHealthSync else 'Python fallback',
        'data_structure': 'Splay Tree cache' if USE_C_BACKEND and CHealthSync else 'JSON/cache stats only'
    }), 200

@app.route('/api/cache/reset', methods=['POST'])
def reset_cache():
    splay_cache_stats['hits'] = 0
    splay_cache_stats['misses'] = 0
    splay_cache_stats['access_counts'] = {}
    splay_cache_stats['recent_patient_ids'] = []
    if USE_C_BACKEND and CHealthSync:
        CHealthSync.splay_clear()
    return jsonify({'status': 'success', 'message': 'Splay cache reset'}), 200

@app.route('/api/patients/sorted', methods=['GET'])
def get_patients_sorted():
    """Phase 2: Return all patients sorted by patient ID."""
    try:
        patients, backend, data_structure = get_bplus_directory_patients()
        return jsonify({
            'patients': patients,
            'count': len(patients),
            'data_structure': data_structure,
            'backend': backend
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/range', methods=['GET'])
def get_patients_range():
    """Phase 2: Return patients whose IDs fall in the inclusive range."""
    try:
        min_id = request.args.get('min_id', type=int)
        max_id = request.args.get('max_id', type=int)

        if min_id is None or max_id is None:
            return jsonify({'error': 'min_id and max_id are required'}), 400

        low, high = sorted((min_id, max_id))
        if USE_C_BACKEND and CHealthSync:
            c_patients = CHealthSync.bplus_range_query(low, high)
            if c_patients:
                patients = [enrich_patient(patient) for patient in c_patients]
                backend = 'C backend'
                data_structure = 'B+ Tree range query'
            else:
                patients = []
                backend = 'C backend'
                data_structure = 'B+ Tree range query'
        else:
            patients = [
                enrich_patient(patient)
                for patient in get_sorted_patients()
                if low <= patient.get('id', 0) <= high
            ]
            backend = 'Python fallback'
            data_structure = 'Python ID range filter'

        return jsonify({
            'patients': patients,
            'count': len(patients),
            'min_id': low,
            'max_id': high,
            'data_structure': data_structure,
            'backend': backend
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/pagination', methods=['GET'])
def paginate_patients():
    """Phase 2: Return patients as a paginated, ID-sorted directory."""
    try:
        page = request.args.get('page', default=1, type=int)
        per_page = request.args.get('per_page', default=10, type=int)

        if page < 1 or per_page < 1:
            return jsonify({'error': 'page and per_page must be positive integers'}), 400

        if USE_C_BACKEND and CHealthSync:
            all_patients = CHealthSync.bplus_get_all_sorted()
            patients = [enrich_patient(patient) for patient in all_patients]
            page_patients = [enrich_patient(patient) for patient in CHealthSync.bplus_get_paginated(page, per_page, per_page)]
            payload = paginate_items(patients, page, per_page)
            payload['patients'] = page_patients
            payload['data_structure'] = 'B+ Tree leaf traversal'
            payload['backend'] = 'C backend'
        else:
            patients = [enrich_patient(patient) for patient in get_sorted_patients()]
            payload = paginate_items(patients, page, per_page)
            payload['patients'] = payload.pop('items')
            payload['data_structure'] = 'Python list pagination'
            payload['backend'] = 'Python fallback'
        return jsonify(payload), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/by-age', methods=['GET'])
def get_patients_by_age():
    """Phase 2: Return patients filtered by age range."""
    try:
        min_age = request.args.get('min_age', type=int)
        max_age = request.args.get('max_age', type=int)

        if min_age is None or max_age is None:
            return jsonify({'error': 'min_age and max_age are required'}), 400

        if min_age > max_age:
            min_age, max_age = max_age, min_age

        sorted_patients, backend, source_structure = get_bplus_directory_patients()
        patients = []
        for patient in sorted_patients:
            enriched = enrich_patient(patient)
            age = enriched.get('age')
            if age is not None and min_age <= age <= max_age:
                patients.append(enriched)

        return jsonify({
            'patients': patients,
            'count': len(patients),
            'min_age': min_age,
            'max_age': max_age,
            'data_structure': 'Age filter over sorted directory',
            'backend': backend,
            'sorted_source': source_structure
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# Emergency Triage Queue Endpoints (Using Binomial Heap - O(log n) operations)
# ============================================================================

@app.route('/api/emergency-queue/next', methods=['GET'])
def get_next_emergency():
    """Get the next patient from emergency triage queue (highest priority)
    Uses Binomial Heap extract_min (O(log n)) if C backend available
    """
    try:
        # Try C backend first
        if USE_C_BACKEND and CHealthSync:
            patient_id, priority = CHealthSync.queue_extract_next()
            
            if patient_id is None:
                # Try fallback
                pass
            else:
                # Get patient details from C backend using AVL search
                patient = CHealthSync.avl_search_patient(patient_id)
                
                if not patient:
                    return jsonify({'error': 'Patient not found'}), 404
                
                return jsonify({
                    'patient': patient,
                    'priority': priority,
                    'backend': 'C (Binomial Heap)',
                    'message': f'Next patient (Binomial Heap): {patient["firstName"]} {patient["lastName"]} (Priority: {priority})'
                }), 200
        
        # Fallback: Find highest priority from JSON queue
        queue = load_queue()
        if not queue:
            return jsonify({'error': 'Queue is empty'}), 404
        
        # Get patient with highest priority
        next_patient_row = max(queue, key=lambda x: x.get('priority', 0))
        queue.remove(next_patient_row)
        save_queue(queue)
        
        patients = load_patients()
        patient_id = next_patient_row.get('patient_id', next_patient_row.get('patientId'))
        patient = next((p for p in patients if p['id'] == patient_id), None)
        
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404
        
        return jsonify({
            'patient': patient,
            'priority': next_patient_row.get('priority'),
            'backend': 'JSON (fallback)',
            'message': f'Next patient (JSON list): {patient["firstName"]} {patient["lastName"]} (Priority: {next_patient_row.get("priority")})'
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/emergency-queue/remove-patient', methods=['POST'])
def remove_patient_from_emergency_queue():
    """Remove a patient from the emergency queue (after treatment)"""
    try:
        data = request.get_json()
        patient_id = data.get('patient_id')
        
        if not patient_id:
            return jsonify({'error': 'Patient ID required'}), 400
        
        # Note: Current Binomial Heap doesn't have remove_by_id
        # In production, would add this operation
        return jsonify({
            'patient_id': patient_id,
            'status': 'removed from queue',
            'note': 'Patient treatment completed'
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/emergency-queue/stats', methods=['GET'])
def emergency_queue_stats():
    """Get emergency triage queue statistics"""
    try:
        queue = load_queue()
        critical = sum(1 for q in queue if q.get('priority', 0) >= 80)
        urgent = sum(1 for q in queue if 60 <= q.get('priority', 0) < 80)
        stable = sum(1 for q in queue if q.get('priority', 0) < 60)

        queue_size = len(queue)
        backend = 'JSON (fallback)'
        data_structure = 'JSON queue'

        if USE_C_BACKEND and CHealthSync:
            try:
                queue_size = CHealthSync.queue_get_size() or queue_size
                backend = 'C (Binomial Heap)'
                data_structure = 'Binomial Heap'
            except Exception:
                pass

        return jsonify({
            'queue_size': queue_size,
            'critical_count': critical,
            'urgent_count': urgent,
            'stable_count': stable,
            'backend': backend,
            'data_structure': data_structure,
            'extract_next_complexity': 'O(log n)',
            'insert_complexity': 'O(1)',
            'merge_complexity': 'O(log n)',
            'message': 'Emergency queue statistics'
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# Real-Time Triage Priority Queue (Using Fibonacci Heap - O(1) decrease-key)
# ============================================================================

@app.route('/api/triage/init', methods=['POST'])
def init_triage_queue():
    """Initialize Fibonacci heap for real-time priority updates
    Fibonacci heap enables O(1) amortized decrease-key for emergency updates
    """
    try:
        if USE_C_BACKEND and CHealthSync:
            result = CHealthSync.fib_init_queue()
            if result:
                return jsonify({
                    'status': 'success',
                    'message': 'Fibonacci heap initialized',
                    'backend': 'C (Fibonacci Heap)',
                    'complexity_decrease_key': 'O(1) amortized'
                }), 200
        
        return jsonify({
            'status': 'warning',
            'message': 'C backend not available'
        }), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/triage/vitals/<int:patient_id>', methods=['POST'])
def update_triage_vitals(patient_id):
    """Update patient vitals and recalculate priority in real-time
    This is the PRIMARY endpoint for emergency updates
    O(1) amortized decrease-key using Fibonacci heap
    """
    try:
        data = request.get_json()
        
        # Update patient vitals in JSON
        patients = load_patients()
        patient_index = next((i for i, p in enumerate(patients) if p['id'] == patient_id), None)
        
        if patient_index is None:
            return jsonify({'error': 'Patient not found'}), 404
        
        patient = patients[patient_index]
        
        # Update vitals
        patient['heartRate'] = data.get('heartRate', patient.get('heartRate', 0))
        patient['bloodPressure'] = data.get('bloodPressure', patient.get('bloodPressure', ''))
        patient['temperature'] = data.get('temperature', patient.get('temperature', 0))
        patient['oxygenSaturation'] = data.get('oxygenSaturation', patient.get('oxygenSaturation', 0))
        patient['painLevel'] = data.get('painLevel', patient.get('painLevel', 0))
        
        # Save updated vitals
        save_patients(patients)
        
        # Recalculate priority
        new_priority = calculate_triage_priority(patient)
        
        # Update Fibonacci heap (O(1) amortized)
        if USE_C_BACKEND and CHealthSync:
            CHealthSync.fib_decrease_key(patient_id, new_priority)
            print(f"[Triage] Patient {patient_id} priority updated to {new_priority} (Fibonacci decrease-key)")
        
        return jsonify({
            'status': 'success',
            'patient_id': patient_id,
            'new_priority': new_priority,
            'backend': 'C (Fibonacci Heap)',
            'complexity': 'O(1) amortized',
            'message': f'Patient vitals updated - Priority: {new_priority}'
        }), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/triage/next', methods=['GET'])
def get_next_from_triage_queue():
    """Extract next patient from Fibonacci heap triage queue
    Fibonacci extract_min is O(log n) amortized
    Complements decrease-key for optimal real-time operations
    """
    try:
        if USE_C_BACKEND and CHealthSync:
            patient_id = CHealthSync.fib_extract_min()
            
            if patient_id is None or patient_id <= 0:
                return jsonify({
                    'message': 'Triage queue is empty',
                    'status': 'empty'
                }), 200
            
            # Get patient details
            patients = load_patients()
            patient = next((p for p in patients if p['id'] == patient_id), None)
            
            if not patient:
                return jsonify({'error': f'Patient {patient_id} not found in database'}), 404
            
            return jsonify({
                'status': 'success',
                'patient': patient,
                'patient_id': patient_id,
                'backend': 'C (Fibonacci Heap)',
                'complexity': 'O(log n) amortized',
                'message': f'Extracted: {patient["firstName"]} {patient["lastName"]} from Fibonacci queue'
            }), 200
        
        return jsonify({'error': 'C backend not available'}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/triage/peek', methods=['GET'])
def peek_triage_queue():
    """Peek at highest priority patient without extraction
    Fibonacci peek_min is O(1) constant time
    """
    try:
        if USE_C_BACKEND and CHealthSync:
            patient_id = CHealthSync.fib_peek_min()
            
            if patient_id is None or patient_id <= 0:
                return jsonify({
                    'message': 'Triage queue is empty',
                    'status': 'empty'
                }), 200
            
            # Get patient details
            patients = load_patients()
            patient = next((p for p in patients if p['id'] == patient_id), None)
            
            if not patient:
                return jsonify({'error': f'Patient {patient_id} not found'}), 404
            
            return jsonify({
                'status': 'success',
                'patient': patient,
                'patient_id': patient_id,
                'backend': 'C (Fibonacci Heap)',
                'complexity': 'O(1)',
                'message': f'Next in queue: {patient["firstName"]} {patient["lastName"]} (no extraction)'
            }), 200
        
        return jsonify({'error': 'C backend not available'}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/triage/queue/size', methods=['GET'])
def get_triage_queue_size():
    """Get Fibonacci heap queue size
    O(1) constant time lookup
    """
    try:
        if USE_C_BACKEND and CHealthSync:
            size = CHealthSync.fib_queue_size()
            
            return jsonify({
                'status': 'success',
                'queue_size': size,
                'backend': 'C (Fibonacci Heap)',
                'complexity': 'O(1)',
                'message': f'Triage queue has {size} patients waiting'
            }), 200
        
        return jsonify({'error': 'C backend not available'}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/triage/priority/<int:patient_id>', methods=['PUT'])
def update_triage_priority(patient_id):
    """Update patient priority in real-time
    Uses Fibonacci decrease-key for O(1) amortized operations
    CRITICAL: Enable instant response to condition changes
    """
    try:
        data = request.get_json()
        new_priority = data.get('priority')
        
        if new_priority is None:
            return jsonify({'error': 'Priority value required'}), 400
        
        if not isinstance(new_priority, int) or new_priority < 0 or new_priority > 100:
            return jsonify({'error': 'Priority must be integer 0-100'}), 400
        
        # Update in Fibonacci heap
        if USE_C_BACKEND and CHealthSync:
            CHealthSync.fib_decrease_key(patient_id, new_priority)
            
            return jsonify({
                'status': 'success',
                'patient_id': patient_id,
                'new_priority': new_priority,
                'backend': 'C (Fibonacci Heap)',
                'complexity': 'O(1) amortized',
                'message': f'Patient {patient_id} priority set to {new_priority}'
            }), 200
        
        return jsonify({'error': 'C backend not available'}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/triage/clear', methods=['POST'])
def clear_triage_queue():
    """Clear and reset Fibonacci heap queue (emergency reset)"""
    try:
        if USE_C_BACKEND and CHealthSync:
            CHealthSync.fib_clear_queue()
            
            return jsonify({
                'status': 'success',
                'message': 'Fibonacci triage queue cleared',
                'backend': 'C (Fibonacci Heap)'
            }), 200
        
        return jsonify({'error': 'C backend not available'}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# Module 2 Extras - Binomial Merge, Leftist Staff, Pairing Appointments
# ============================================================================

@app.route('/api/triage/queues', methods=['GET'])
def list_triage_queues():
    try:
        pools = load_triage_pools()
        return jsonify({
            'queues': {name: len(entries) for name, entries in pools.items()},
            'details': pools
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/triage/queues/<queue_name>', methods=['POST'])
def add_patient_to_named_queue(queue_name):
    try:
        pools = load_triage_pools()
        if queue_name not in pools:
            return jsonify({'error': 'Unknown queue name'}), 400

        data = request.get_json() or {}
        patient_id = data.get('patient_id')
        if not patient_id:
            return jsonify({'error': 'patient_id is required'}), 400

        patient = next((p for p in load_patients() if p['id'] == int(patient_id)), None)
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404

        priority = int(data.get('priority', calculate_triage_priority(patient)))
        pools[queue_name].append({
            'patient_id': int(patient_id),
            'priority': priority,
            'timestamp': datetime.now().isoformat()
        })
        save_triage_pools(pools)
        return jsonify({'status': 'success', 'queue': queue_name, 'priority': priority}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/triage/merge', methods=['POST'])
def merge_triage_queues():
    try:
        data = request.get_json() or {}
        source = data.get('source')
        target = data.get('target')
        pools = load_triage_pools()

        if source not in pools or target not in pools:
            return jsonify({'error': 'source and target must be valid queue names'}), 400
        if source == target:
            return jsonify({'error': 'source and target must be different'}), 400

        pools[target].extend(pools[source])
        pools[source] = []
        pools[target].sort(key=lambda item: item.get('priority', 0), reverse=True)
        save_triage_pools(pools)

        return jsonify({
            'status': 'success',
            'merged_from': source,
            'merged_into': target,
            'target_size': len(pools[target]),
            'data_structure': 'Binomial Heap style merge'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/triage/next-all', methods=['GET'])
def get_next_across_all_queues():
    try:
        pools = load_triage_pools()
        best = None
        best_queue = None
        for queue_name, entries in pools.items():
            if not entries:
                continue
            candidate = max(entries, key=lambda item: item.get('priority', 0))
            if best is None or candidate.get('priority', 0) > best.get('priority', 0):
                best = candidate
                best_queue = queue_name

        if not best:
            return jsonify({'status': 'empty', 'message': 'All named queues are empty'}), 200

        patient = next((p for p in load_patients() if p['id'] == best['patient_id']), None)
        return jsonify({
            'queue': best_queue,
            'entry': best,
            'patient': patient
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/staff', methods=['GET'])
def get_staff_list():
    try:
        staff = sorted(load_staff(), key=lambda entry: (entry.get('current_workload', 0), entry.get('id', 0)))
        return jsonify(staff), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/staff', methods=['POST'])
def add_staff():
    try:
        data = request.get_json() or {}
        required = ['name', 'role']
        for field in required:
            if not data.get(field):
                return jsonify({'error': f'Missing required field: {field}'}), 400

        staff = load_staff()
        new_staff = {
            'id': get_next_resource_id(staff),
            'name': data['name'],
            'role': data['role'],
            'current_workload': int(data.get('current_workload', 0)),
            'department': data.get('department', 'general'),
            'created_at': datetime.now().isoformat()
        }
        staff.append(new_staff)
        save_staff(staff)
        sync_c_backend_from_json()

        return jsonify(new_staff), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/staff/<int:staff_id>/workload', methods=['PUT'])
def update_staff_workload(staff_id):
    try:
        data = request.get_json() or {}
        new_workload = data.get('workload')
        if new_workload is None:
            return jsonify({'error': 'workload is required'}), 400

        staff = load_staff()
        staff_member = next((entry for entry in staff if entry['id'] == staff_id), None)
        if not staff_member:
            return jsonify({'error': 'Staff member not found'}), 404

        staff_member['current_workload'] = int(new_workload)
        save_staff(staff)
        sync_c_backend_from_json()
        return jsonify(staff_member), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/staff/least-busy', methods=['GET'])
def get_least_busy_staff():
    try:
        staff = load_staff()
        if not staff:
            return jsonify({'error': 'No staff registered'}), 404

        least_busy = min(staff, key=lambda entry: (entry.get('current_workload', 0), entry.get('id', 0)))
        return jsonify(least_busy), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/assign-patient', methods=['POST'])
def assign_patient_to_least_busy():
    try:
        data = request.get_json() or {}
        patient_id = data.get('patient_id')
        if not patient_id:
            return jsonify({'error': 'patient_id is required'}), 400

        patients = load_patients()
        patient = next((p for p in patients if p['id'] == int(patient_id)), None)
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404

        staff = load_staff()
        if not staff:
            return jsonify({'error': 'No staff available'}), 404

        least_busy = min(staff, key=lambda entry: (entry.get('current_workload', 0), entry.get('id', 0)))
        least_busy['current_workload'] = int(least_busy.get('current_workload', 0)) + 1
        patient['doctorId'] = least_busy['id']
        patient['doctorName'] = least_busy['name']
        save_staff(staff)
        save_patients(patients)
        sync_c_backend_from_json()

        return jsonify({
            'status': 'success',
            'patient_id': patient['id'],
            'assigned_staff': least_busy
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/staff/<int:staff_id>', methods=['DELETE'])
def delete_staff(staff_id):
    try:
        staff = load_staff()
        updated = [entry for entry in staff if entry['id'] != staff_id]
        if len(updated) == len(staff):
            return jsonify({'error': 'Staff member not found'}), 404
        save_staff(updated)
        sync_c_backend_from_json()
        return jsonify({'status': 'success', 'staff_id': staff_id}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/appointments', methods=['GET'])
def get_appointments():
    try:
        appointments = sorted(load_appointments(), key=lambda item: item.get('priority', 0), reverse=True)
        return jsonify(appointments), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/appointments', methods=['POST'])
def create_appointment():
    try:
        data = request.get_json() or {}
        appointments = load_appointments()
        new_appointment = {
            'id': get_next_resource_id(appointments),
            'patientId': data.get('patientId'),
            'reason': data.get('reason', ''),
            'scheduledFor': data.get('scheduledFor'),
            'status': data.get('status', 'scheduled'),
            'priority': calculate_appointment_priority(data),
            'created_at': datetime.now().isoformat()
        }
        appointments.append(new_appointment)
        save_appointments(appointments)
        sync_c_backend_from_json()

        return jsonify(new_appointment), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/appointments/<int:appt_id>/priority', methods=['PUT'])
def update_appointment_priority(appt_id):
    try:
        data = request.get_json() or {}
        new_priority = data.get('priority')
        if new_priority is None:
            return jsonify({'error': 'priority is required'}), 400

        appointments = load_appointments()
        appointment = next((item for item in appointments if item['id'] == appt_id), None)
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404

        appointment['priority'] = int(new_priority)
        save_appointments(appointments)
        sync_c_backend_from_json()
        return jsonify(appointment), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/appointments/next', methods=['GET'])
def get_next_appointment():
    try:
        appointments = load_appointments()
        active = [item for item in appointments if item.get('status') == 'scheduled']
        if not active:
            return jsonify({'status': 'empty', 'message': 'No scheduled appointments'}), 200

        next_item = max(active, key=lambda item: item.get('priority', 0))
        return jsonify(next_item), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/textsync/autocomplete', methods=['GET'])
def textsync_autocomplete():
    try:
        prefix = request.args.get('prefix', '').strip().lower()
        limit = max(1, min(int(request.args.get('limit', 8)), 25))
        vocabulary = build_textsync_vocabulary()
        matches = [token for token in vocabulary if token.startswith(prefix)] if prefix else vocabulary[:limit]
        return jsonify({
            'prefix': prefix,
            'suggestions': matches[:limit],
            'source': 'TextSync Trie-style fallback'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/textsync/search', methods=['GET'])
def textsync_search():
    try:
        query = request.args.get('q', '').strip().lower()
        if not query:
            return jsonify({'error': 'q parameter is required'}), 400

        results = []
        for patient in load_patients():
            searchable = build_patient_search_text(patient)
            haystack = searchable.lower()
            index = haystack.find(query)
            if index == -1:
                continue
            results.append({
                'patientId': patient['id'],
                'patientName': f"{patient.get('firstName', '')} {patient.get('lastName', '')}".strip(),
                'matchIndex': index,
                'preview': searchable[max(0, index - 40): index + len(query) + 60].strip()
            })

        return jsonify({
            'query': query,
            'count': len(results),
            'results': results[:25],
            'source': 'TextSync suffix-array fallback'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/textsync/patterns', methods=['POST'])
def textsync_patterns():
    try:
        data = request.get_json() or {}
        text = data.get('text') or data.get('symptoms') or ''
        patterns = detect_common_patterns(text)
        diseases = suggest_diseases_from_patterns(patterns)
        outbreak_flag = any(item.get('frequency', 0) >= 8 for item in patterns)
        return jsonify({
            'input': text,
            'patterns': patterns,
            'diseases': diseases,
            'outbreakFlag': outbreak_flag,
            'source': 'TextSync suffix-tree fallback'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/textsync/fuzzy', methods=['GET'])
def textsync_fuzzy():
    try:
        term = request.args.get('term', '').strip().lower()
        max_distance = max(1, min(int(request.args.get('max_distance', 2)), 4))
        if not term:
            return jsonify({'error': 'term parameter is required'}), 400

        suggestions = []
        for token in build_textsync_vocabulary():
            distance = levenshtein_distance(term, token)
            if distance <= max_distance:
                suggestions.append({'token': token, 'distance': distance})

        suggestions.sort(key=lambda item: (item['distance'], item['token']))
        return jsonify({
            'term': term,
            'matches': suggestions[:12],
            'source': 'TextSync BK-tree fallback'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/trials/randomize', methods=['POST'])
def trials_randomize():
    try:
        data = request.get_json() or {}
        patient_id = int(data.get('patientId', 0))
        trial_id = str(data.get('trialId', 'default'))
        if not patient_id:
            return jsonify({'error': 'patientId is required'}), 400

        patients = load_patients()
        patient = next((entry for entry in patients if entry['id'] == patient_id), None)
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404

        trial, trials = get_trial_template(trial_id)
        existing = next((assignment for assignment in trial['assignments'] if assignment['patientId'] == patient_id), None)
        if existing:
            return jsonify(existing), 200

        group = 'treatment' if (patient_id + len(trial['assignments'])) % 2 == 0 else 'control'
        assignment = {
            'patientId': patient_id,
            'trialId': trial_id,
            'group': group,
            'assignedAt': datetime.now().isoformat(),
            'patientName': f"{patient.get('firstName', '')} {patient.get('lastName', '')}".strip()
        }
        trial['assignments'].append(assignment)
        save_trials(trials)
        return jsonify({
            **assignment,
            'source': 'TrialSync treap/skip-list fallback'
        }), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/trials', methods=['GET'])
def trials_list():
    try:
        return jsonify(load_trials()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/trials/cache-stats', methods=['GET'])
def trials_cache_stats():
    try:
        return jsonify(build_trial_cache_stats()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/trials/eligible', methods=['POST'])
def trials_eligible():
    try:
        data = request.get_json() or {}
        patient_id = int(data.get('patientId', 0))
        keywords = [str(item).lower() for item in data.get('requiredKeywords', [])]
        if not patient_id:
            return jsonify({'error': 'patientId is required'}), 400

        patient = next((entry for entry in load_patients() if entry['id'] == patient_id), None)
        if not patient:
            return jsonify({'error': 'Patient not found'}), 404

        profile_text = build_patient_search_text(patient).lower()
        matched = [keyword for keyword in keywords if keyword in profile_text]
        eligible = len(matched) == len(keywords) if keywords else 'trial' not in profile_text
        return jsonify({
            'patientId': patient_id,
            'eligible': eligible,
            'matchedKeywords': matched,
            'source': 'TrialSync bloom-filter fallback'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/trials/simulate', methods=['POST'])
def trials_simulate():
    try:
        data = request.get_json() or {}
        trial_id = data.get('trialId', 'default')
        iterations = max(20, min(int(data.get('iterations', 120)), 500))
        return jsonify(simulate_trial_outcomes(trial_id, iterations)), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/location/nearest', methods=['GET'])
def location_nearest():
    try:
        x = float(request.args.get('x', 0))
        y = float(request.args.get('y', 0))
        equipment = load_equipment()
        if not equipment:
            return jsonify({'error': 'No equipment registered'}), 404

        nearest = min(
            equipment,
            key=lambda item: ((float(item.get('x', 0)) - x) ** 2 + (float(item.get('y', 0)) - y) ** 2)
        )
        distance = (((float(nearest.get('x', 0)) - x) ** 2 + (float(nearest.get('y', 0)) - y) ** 2) ** 0.5)
        return jsonify({
            'query': {'x': x, 'y': y},
            'nearest': nearest,
            'distance': round(distance, 2),
            'source': 'NaviSync R-tree fallback'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/location/assets', methods=['GET'])
def location_assets():
    try:
        return jsonify(load_equipment()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/location/heatmap', methods=['GET'])
def location_heatmap():
    try:
        return jsonify({
            'zones': build_zone_heatmap(),
            'source': 'NaviSync quadtree heatmap fallback'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/schedule/rooms', methods=['POST'])
def schedule_rooms():
    try:
        data = request.get_json() or {}
        room_id = data.get('roomId')
        start_at = data.get('start')
        end_at = data.get('end')
        if not room_id or not start_at or not end_at:
            return jsonify({'error': 'roomId, start, and end are required'}), 400

        schedule = load_room_schedule()
        conflict = room_booking_overlaps(schedule, room_id, start_at, end_at)
        if conflict:
            return jsonify({
                'error': 'Room is already booked for the requested interval',
                'conflict': conflict
            }), 409

        booking = {
            'id': get_next_resource_id(schedule),
            'roomId': room_id,
            'patientId': data.get('patientId'),
            'start': start_at,
            'end': end_at,
            'status': data.get('status', 'scheduled'),
            'notes': data.get('notes', ''),
            'created_at': datetime.now().isoformat()
        }
        schedule.append(booking)
        save_room_schedule(schedule)
        return jsonify({
            'booking': booking,
            'source': 'NaviSync interval-tree fallback'
        }), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/schedule/rooms', methods=['GET'])
def schedule_rooms_list():
    try:
        room_id = request.args.get('roomId')
        schedule = load_room_schedule()
        if room_id:
            schedule = [booking for booking in schedule if str(booking.get('roomId')) == str(room_id)]
        return jsonify(schedule), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/occupancy/trends', methods=['GET'])
def occupancy_trends():
    try:
        days = max(3, min(int(request.args.get('days', 7)), 30))
        return jsonify({
            'days': days,
            'points': build_occupancy_trends(days),
            'source': 'NaviSync segment-tree fallback'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/history/versions/<int:patient_id>', methods=['GET'])
def history_versions(patient_id):
    try:
        history = load_patient_history()
        versions = history.get(str(patient_id))
        if not versions:
            return jsonify({'error': 'No history found for patient'}), 404
        return jsonify({
            'patientId': patient_id,
            'versionCount': len(versions),
            'versions': versions,
            'source': 'HistorySync persistent-tree fallback'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/history/audit/<int:patient_id>', methods=['GET'])
def history_audit(patient_id):
    try:
        return jsonify({
            'patientId': patient_id,
            'entries': flatten_audit_log(patient_id),
            'source': 'HistorySync audit log'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/history/concurrency/<int:patient_id>', methods=['GET'])
def history_concurrency(patient_id):
    try:
        return jsonify({
            'patientId': patient_id,
            'events': simulate_concurrent_access(patient_id),
            'source': 'HistorySync concurrent hashmap simulation'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/outbreak/cluster', methods=['GET'])
def outbreak_cluster():
    try:
        clusters = build_outbreak_clusters()
        return jsonify({
            'clusterCount': len(clusters),
            'clusters': clusters[:12],
            'source': 'HistorySync disjoint-set fallback'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'HealthSync Backend'})

if __name__ == '__main__':
    print("\n" + "="*60)
    print("HealthSync Backend API Server")
    print("="*60)
    
    if USE_C_BACKEND:
        print("[OK] C Backend:    ENABLED  (Advanced Data Structures)")
        print("  - Patient Database: C (patient_db.c)")
        print("  - Triage Priority:  C (with AVL/Heap structures)")
    else:
        print("[--] C Backend:    DISABLED (using JSON fallback)")
        print("  To enable: Run build.bat to compile C code to DLL")
    
    print("[OK] API Server:   http://localhost:5000")
    print("[OK] CORS:         Enabled (frontend communication)")
    print("="*60)
    
    print("\nAPI Endpoints:")
    print("  GET    /api/patients            - Get all patients")
    print("  POST   /api/patients            - Add new patient (AVL + Queue)")
    print("  GET    /api/patients/<id>       - Get patient by ID (AVL search O(log n))")
    print("  PUT    /api/patients/<id>       - Update patient")
    print("  DELETE /api/patients/<id>       - Delete patient")
    print("\n  [Emergency Queue - Binomial Heap]")
    print("  GET    /api/emergency-queue/next     - Get next patient (Heap extract)")
    print("  POST   /api/emergency-queue/remove   - Remove from queue")
    print("  GET    /api/emergency-queue/stats    - Queue statistics")
    print("\n  [Real-Time Triage - Fibonacci Heap] ⭐ NEW PHASE 1")
    print("  POST   /api/triage/init              - Initialize Fibonacci heap")
    print("  POST   /api/triage/vitals/<id>       - Update vitals + recalc priority (O(1))")
    print("  GET    /api/triage/next              - Extract next patient (O(log n))")
    print("  GET    /api/triage/peek              - Peek next (O(1))")
    print("  GET    /api/triage/queue/size        - Queue size (O(1))")
    print("  PUT    /api/triage/priority/<id>     - Update priority (O(1) decrease-key)")
    print("  POST   /api/triage/clear             - Clear queue")
    print("  GET    /health                       - Health check")
    print("\nData Structures in Use:")
    print("  [*] AVL Tree:          Patient lookup - O(log n) vs O(n)")
    print("  [*] Binomial Heap:     Emergency queue - O(1) insert, O(log n) extract")
    print("  [NEW] Fibonacci Heap:  Real-time triage - O(1) decrease-key ⭐ PHASE 1")
    print("="*60 + "\n")
    
    try:
        app.run(debug=True, host='0.0.0.0', port=5001)
    finally:
        if USE_C_BACKEND and CHealthSync:
            print("\n[Backend] Cleaning up C resources...")
            CHealthSync.cleanup()
