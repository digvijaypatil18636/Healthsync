#include <assert.h>
#include <string.h>

#include "module3_strings.h"
#include "module4_randomized.h"
#include "module5_spatial.h"
#include "module6_misc.h"

int main(void) {
    TrieNode* trie = trie_create();
    trie_insert(trie, "fever");
    assert(trie_search(trie, "fever"));
    trie_free(trie);

    BloomFilter* bloom = bloom_create(128, 3);
    bloom_add(bloom, "diabetes");
    assert(bloom_check(bloom, "diabetes"));
    bloom_free(bloom);

    RTree* rtree = rtree_create();
    Rect rect = {0, 0, 5, 5};
    rtree_insert(rtree, rect, 42, "CT");
    assert(rtree_nearest(rtree, 2, 2) == 42);
    rtree_free(rtree);

    PersistentRBTree* pst = pst_create();
    PersistentRBNode* version = pst_insert(pst, 1, "v1");
    assert(strcmp(pst_search(version, 1), "v1") == 0);
    pst_free(pst);

    return 0;
}
