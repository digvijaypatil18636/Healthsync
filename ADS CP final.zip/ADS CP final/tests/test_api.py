import shutil
import uuid
from pathlib import Path

import pytest

import backend_server


@pytest.fixture()
def client(monkeypatch):
    base_dir = Path('tests') / f'_tmp_{uuid.uuid4().hex}'
    base_dir.mkdir(parents=True, exist_ok=True)
    file_map = {
        'DATA_FILE': base_dir / 'patients.json',
        'QUEUE_FILE': base_dir / 'queue.json',
        'STAFF_FILE': base_dir / 'staff.json',
        'APPOINTMENTS_FILE': base_dir / 'appointments.json',
        'TRIAGE_POOLS_FILE': base_dir / 'triage_pools.json',
        'TRIALS_FILE': base_dir / 'trials.json',
        'EQUIPMENT_FILE': base_dir / 'equipment.json',
        'ROOM_SCHEDULE_FILE': base_dir / 'room_schedule.json',
        'PATIENT_HISTORY_FILE': base_dir / 'patient_history.json',
    }

    for name, path in file_map.items():
        monkeypatch.setattr(backend_server, name, str(path))

    sample_patients = [
        {
            'id': 1,
            'firstName': 'Aarav',
            'lastName': 'Sharma',
            'dob': '1990-01-01',
            'gender': 'Male',
            'conditions': 'diabetes fever',
            'allergies': 'dust',
            'medications': 'insulin',
            'chiefComplaint': 'persistent fever',
            'symptoms': 'cough fatigue',
            'geneticConditions': 'family diabetes',
            'address': 'Delhi',
        },
        {
            'id': 2,
            'firstName': 'Diya',
            'lastName': 'Menon',
            'dob': '1995-02-02',
            'gender': 'Female',
            'conditions': 'asthma',
            'allergies': 'pollen',
            'medications': 'inhaler',
            'chiefComplaint': 'dry cough',
            'symptoms': 'cough breathless',
            'geneticConditions': '',
            'address': 'Chennai',
        },
    ]

    backend_server.save_patients(sample_patients)
    backend_server.save_json_file(backend_server.QUEUE_FILE, [])
    backend_server.save_json_file(backend_server.STAFF_FILE, [])
    backend_server.save_json_file(backend_server.APPOINTMENTS_FILE, [])
    backend_server.save_json_file(backend_server.TRIAGE_POOLS_FILE, {'er': [], 'icu': [], 'field': []})
    backend_server.save_json_file(backend_server.TRIALS_FILE, [])
    backend_server.save_json_file(backend_server.ROOM_SCHEDULE_FILE, [])
    backend_server.save_json_file(backend_server.PATIENT_HISTORY_FILE, {})
    backend_server.seed_patient_history_if_missing()

    backend_server.app.config.update(TESTING=True)
    with backend_server.app.test_client() as test_client:
        yield test_client
    shutil.rmtree(base_dir, ignore_errors=True)


def test_textsync_autocomplete(client):
    response = client.get('/api/textsync/autocomplete?prefix=co')
    payload = response.get_json()
    assert response.status_code == 200
    assert 'cough' in payload['suggestions']


def test_textsync_fuzzy(client):
    response = client.get('/api/textsync/fuzzy?term=diabets')
    payload = response.get_json()
    assert response.status_code == 200
    assert payload['matches'][0]['token'] == 'diabetes'


def test_trials_randomize_and_eligibility(client):
    response = client.post('/api/trials/randomize', json={'patientId': 1, 'trialId': 'alpha'})
    payload = response.get_json()
    assert response.status_code == 201
    assert payload['group'] in {'control', 'treatment'}

    response = client.post('/api/trials/eligible', json={'patientId': 1, 'requiredKeywords': ['diabetes']})
    payload = response.get_json()
    assert response.status_code == 200
    assert payload['eligible'] is True


def test_room_scheduler_conflict_detection(client):
    booking = {
        'roomId': 'OR-1',
        'patientId': 1,
        'start': '2026-04-12T09:00',
        'end': '2026-04-12T10:00',
    }
    first = client.post('/api/schedule/rooms', json=booking)
    second = client.post('/api/schedule/rooms', json={**booking, 'patientId': 2})
    assert first.status_code == 201
    assert second.status_code == 409


def test_history_versions_and_clusters(client):
    update = client.put('/api/patients/1', json={'conditions': 'diabetes cough'})
    assert update.status_code == 200

    history = client.get('/api/history/versions/1')
    history_payload = history.get_json()
    assert history.status_code == 200
    assert history_payload['versionCount'] >= 2

    clusters = client.get('/api/outbreak/cluster')
    cluster_payload = clusters.get_json()
    assert clusters.status_code == 200
    assert cluster_payload['clusterCount'] >= 1
