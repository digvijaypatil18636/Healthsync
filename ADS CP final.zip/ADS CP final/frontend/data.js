const samplePatients = [
    {
        id: 1,
        firstName: 'John',
        lastName: 'Smith',
        dob: '1976-05-15',
        gender: 'Male',
        phone: '555-0101',
        email: 'john.smith@example.com',
        address: '123 Main St, Springfield',
        motherId: null,
        fatherId: null,
        spouseId: 2,
        childrenIds: [3, 4],
        geneticConditions: '',
        conditions: 'Hypertension',
        allergies: 'Penicillin',
        medications: 'Lisinopril 10mg',
        chiefComplaint: 'Chest pain',
        symptoms: 'Severe chest discomfort',
        onsetHours: 1,
        painLevel: 8,
        heartRate: 110,
        bloodPressure: '160/95',
        temperature: 37.2,
        oxygenSaturation: 94
    },
    {
        id: 2,
        firstName: 'Jane',
        lastName: 'Smith',
        dob: '1978-08-22',
        gender: 'Female',
        phone: '555-0102',
        email: 'jane.smith@example.com',
        address: '123 Main St, Springfield',
        motherId: null,
        fatherId: null,
        spouseId: 1,
        childrenIds: [3, 4],
        geneticConditions: 'Cystic Fibrosis Carrier',
        conditions: 'None',
        allergies: 'Shellfish',
        medications: 'Prenatal vitamin',
        chiefComplaint: 'Migraine',
        symptoms: 'Headache and nausea',
        onsetHours: 2,
        painLevel: 6,
        heartRate: 88,
        bloodPressure: '120/80',
        temperature: 36.9,
        oxygenSaturation: 98
    },
    {
        id: 3,
        firstName: 'Michael',
        lastName: 'Smith',
        dob: '2005-03-10',
        gender: 'Male',
        phone: '555-0103',
        email: 'michael.smith@example.com',
        address: '123 Main St, Springfield',
        motherId: 2,
        fatherId: 1,
        spouseId: null,
        childrenIds: [],
        geneticConditions: '',
        conditions: 'Asthma',
        allergies: 'Pollen, Dust',
        medications: 'Albuterol inhaler',
        chiefComplaint: 'Difficulty breathing',
        symptoms: 'Shortness of breath',
        onsetHours: 3,
        painLevel: 2,
        heartRate: 95,
        bloodPressure: '130/85',
        temperature: 37,
        oxygenSaturation: 92
    },
    {
        id: 4,
        firstName: 'Sarah',
        lastName: 'Smith',
        dob: '2008-11-05',
        gender: 'Female',
        phone: '555-0104',
        email: 'sarah.smith@example.com',
        address: '123 Main St, Springfield',
        motherId: 2,
        fatherId: 1,
        spouseId: null,
        childrenIds: [],
        geneticConditions: '',
        conditions: 'None',
        allergies: 'None',
        medications: 'None',
        chiefComplaint: 'Fever',
        symptoms: 'High temperature and chills',
        onsetHours: 5,
        painLevel: 3,
        heartRate: 100,
        bloodPressure: '115/75',
        temperature: 38.5,
        oxygenSaturation: 97
    },
    {
        id: 5,
        firstName: 'Robert',
        lastName: 'Johnson',
        dob: '1950-12-20',
        gender: 'Male',
        phone: '555-0105',
        email: 'robert.johnson@example.com',
        address: '456 Oak Ave, Springfield',
        motherId: null,
        fatherId: null,
        spouseId: null,
        childrenIds: [],
        geneticConditions: 'Type 2 Diabetes',
        conditions: 'Diabetes, High Cholesterol',
        allergies: 'NSAIDs',
        medications: 'Metformin 1000mg, Atorvastatin 20mg',
        chiefComplaint: 'Weakness',
        symptoms: 'General fatigue',
        onsetHours: 24,
        painLevel: 1,
        heartRate: 80,
        bloodPressure: '140/90',
        temperature: 36.7,
        oxygenSaturation: 96
    }
];

const sampleQueue = [
    {
        patientId: 1,
        name: 'John Smith',
        age: 48,
        gender: 'Male',
        priority: 95,
        complaint: 'Chest pain',
        vitals: {
            hr: 110,
            bp: '160/95',
            temp: '37.2',
            o2: 94
        },
        waitTime: '24m'
    },
    {
        patientId: 2,
        name: 'Jane Smith',
        age: 46,
        gender: 'Female',
        priority: 78,
        complaint: 'Migraine',
        vitals: {
            hr: 88,
            bp: '120/80',
            temp: '36.9',
            o2: 98
        },
        waitTime: '34m'
    }
];

function getPatients() {
    try {
        const stored = localStorage.getItem('healthsync_patients');
        if (stored) {
            const patients = JSON.parse(stored);
            let needsSave = false;
            patients.forEach(p => {
                if (p.fatherId || p.motherId || p.spouseId || (p.childrenIds && p.childrenIds.length > 0)) {
                    syncFamilyRelationships(p, patients);
                    needsSave = true;
                }
            });
            if (needsSave) {
                savePatients(patients);
            }
            return patients;
        }
    } catch (e) {
        console.error('Error reading patients from storage:', e);
    }
    
    savePatients(samplePatients);
    return samplePatients;
}

function savePatients(patients) {
    try {
        localStorage.setItem('healthsync_patients', JSON.stringify(patients));
    } catch (e) {
        console.error('Error saving patients to storage:', e);
    }
}

function getQueue() {
    try {
        const stored = localStorage.getItem('healthsync_queue');
        if (stored) {
            return JSON.parse(stored);
        }
    } catch (e) {
        console.error('Error reading queue from storage:', e);
    }
    
    saveQueue(sampleQueue);
    return sampleQueue;
}

function saveQueue(queue) {
    try {
        localStorage.setItem('healthsync_queue', JSON.stringify(queue));
    } catch (e) {
        console.error('Error saving queue to storage:', e);
    }
}

function getPatientById(id) {
    const patients = getPatients();
    return patients.find(p => p.id == id);
}

function syncFamilyRelationships(patient, allPatients) {
    if (!patient.fatherId) patient.fatherId = null;
    if (!patient.motherId) patient.motherId = null;
    if (!patient.spouseId) patient.spouseId = null;
    if (!patient.childrenIds) patient.childrenIds = [];
    if (!patient.siblingIds) patient.siblingIds = [];
    
    if (patient.fatherId) {
        const father = allPatients.find(p => p.id == patient.fatherId);
        if (father) {
            if (!father.childrenIds) father.childrenIds = [];
            if (!father.childrenIds.includes(patient.id)) {
                father.childrenIds.push(patient.id);
            }
        }
    }
    
    if (patient.motherId) {
        const mother = allPatients.find(p => p.id == patient.motherId);
        if (mother) {
            if (!mother.childrenIds) mother.childrenIds = [];
            if (!mother.childrenIds.includes(patient.id)) {
                mother.childrenIds.push(patient.id);
            }
        }
    }
    
    if (patient.spouseId) {
        const spouse = allPatients.find(p => p.id == patient.spouseId);
        if (spouse) {
            spouse.spouseId = patient.id;
        }
    }
    
    if (patient.childrenIds && patient.childrenIds.length > 0) {
        patient.childrenIds.forEach(childId => {
            const child = allPatients.find(p => p.id == childId);
            if (child) {
                if (patient.gender === 'Male') {
                    child.fatherId = patient.id;
                } else if (patient.gender === 'Female') {
                    child.motherId = patient.id;
                }
            }
        });
    }
}

function addPatient(patient) {
    const patients = getPatients();
    patient.id = Math.max(...patients.map(p => p.id)) + 1;
    patients.push(patient);
    
    syncFamilyRelationships(patient, patients);
    
    savePatients(patients);
    return patient;
}

function updatePatient(id, updates) {
    const patients = getPatients();
    const index = patients.findIndex(p => p.id == id);
    if (index !== -1) {
        patients[index] = { ...patients[index], ...updates };
        
        syncFamilyRelationships(patients[index], patients);
        
        savePatients(patients);
        return patients[index];
    }
    return null;
}

function deletePatient(id) {
    const patients = getPatients();
    const filtered = patients.filter(p => p.id != id);
    savePatients(filtered);
}

function addToQueue(queueItem) {
    const queue = getQueue();
    queue.push(queueItem);
    queue.sort((a, b) => b.priority - a.priority);
    saveQueue(queue);
    return queueItem;
}

function removeFromQueue(patientId) {
    const queue = getQueue();
    const filtered = queue.filter(item => item.patientId != patientId);
    saveQueue(filtered);
}

function getQueueItem(patientId) {
    const queue = getQueue();
    return queue.find(item => item.patientId == patientId);
}

function clearAllData() {
    localStorage.removeItem('healthsync_patients');
    localStorage.removeItem('healthsync_queue');
}

function initializeData() {
    if (!localStorage.getItem('healthsync_patients')) {
        savePatients(samplePatients);
    }
    if (!localStorage.getItem('healthsync_queue')) {
        saveQueue(sampleQueue);
    }
}

initializeData();

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        getPatients,
        savePatients,
        getQueue,
        saveQueue,
        getPatientById,
        addPatient,
        updatePatient,
        deletePatient,
        addToQueue,
        removeFromQueue,
        getQueueItem,
        clearAllData,
        initializeData
    };
}
